/* ZBOSS Zigbee software protocol stack
 *
 * Copyright (c) 2012-2020 DSR Corporation, Denver CO, USA.
 * www.dsr-zboss.com
 * www.dsr-corporation.com
 * All rights reserved.
 *
 * This is unpublished proprietary source code of DSR Corporation
 * The copyright notice does not evidence any actual or intended
 * publication of such source code.
 *
 * ZBOSS is a registered trademark of Data Storage Research LLC d/b/a DSR
 * Corporation
 *
 * Commercial Usage
 * Licensees holding valid DSR Commercial licenses may use
 * this file in accordance with the DSR Commercial License
 * Agreement provided with the Software or, alternatively, in accordance
 * with the terms contained in a written agreement between you and
 * DSR.
 */
/* PURPOSE: ZBOSS stack basic configuration file
*/

#ifndef ZB_VENDOR_CFG_BASE_H
#define ZB_VENDOR_CFG_BASE_H 1

/* do we really need it for all builds? I guess, we need it for tests only */
#define ZB_LIMIT_VISIBILITY


/* Features enabled for all builds */
#define ZB_USE_SLEEP
#define APS_FRAGMENTATION
#define ZB_ALL_DEVICE_SUPPORT
#define ZB_PRODUCTION_CONFIG
#define ZB_SECURITY_INSTALLCODES
#define ZB_MAC_CONFIGURABLE_TX_POWER
#define ZB_APS_USER_PAYLOAD
#define ZB_USE_OSIF_OTA_ROUTINES
#define ZB_R22_MULTIMAC


/* configuration common for all builds */
#define ZB_RESET_AUTORESTART
#define ZB_REDUCE_NWK_LOAD_ON_LOW_MEMORY

#ifdef ZB_CONFIG_DEFAULT_KERNEL_DEFINITION

/* Default memory storage configuration - to be used if user does not include any of zb_mem_config_xxx.h */

#ifndef ZB_ED_ROLE
#define ZB_CONFIG_ROLE_ZC
#else
#define ZB_CONFIG_ROLE_ZED
#endif

#define ZB_CONFIG_OVERALL_NETWORK_SIZE 128

#define ZB_CONFIG_HIGH_TRAFFIC

#define ZB_CONFIG_APPLICATION_COMPLEX

#endif  /*  ZB_CONFIG_DEFAULT_KERNEL_DEFINITION */

/* Compile-time memory configuration: hard-coded parameters */
/* FIXME: 32 seems too big for zb_mlme_scan_confirm() - stack is allocating 5 + (5 *
 * ZB_PANID_TABLE_SIZE) in buf. So maximum possible ZB_PANID_TABLE_SIZE is 28 */
#define ZB_SCHEDULER_Q_SIZE 64
#define ZB_MAX_EP_NUMBER 6
#define ZB_IOBUF_POOL_SIZE 40
#define ZB_PANID_TABLE_SIZE 28
#define ZB_DEV_MANUFACTURER_TABLE_SIZE 32
#define ZB_BUF_Q_SIZE 8
#define ZDO_TRAN_TABLE_SIZE 16
#define ZB_APS_ENDPOINTS_IN_GROUP_TABLE 8
#define ZB_NWK_BTR_TABLE_SIZE 16
#define ZB_NWK_BRR_TABLE_SIZE 16
#ifndef ZB_ED_ROLE
#define ZB_APS_SRC_BINDING_TABLE_SIZE 16
#define ZB_APS_DST_BINDING_TABLE_SIZE 32
#define ZB_APS_GROUP_TABLE_SIZE 16
#else
#define ZB_APS_SRC_BINDING_TABLE_SIZE 8
#define ZB_APS_DST_BINDING_TABLE_SIZE 16
#define ZB_APS_GROUP_TABLE_SIZE 8
#endif  /* ZB_ED_ROLE */
#define ZB_ZGP_SINK_TBL_SIZE 24
#define ZB_ZGP_PROXY_TBL_SIZE 5
#define ZB_ZGP_TRANSL_CMD_PLD_MAX_SIZE 3

#ifdef DEBUG
#define ZB_DEBUG_BUFFERS
#define ZB_TRAFFIC_DUMP_ON
#define ZB_CHECK_OOM_STATUS

#if !defined(USE_ASSERT)
#define USE_ASSERT
#endif /* !USE_ASSERT */
#endif /* DEBUG */

#endif /* ZB_VENDOR_CFG_BASE_H */
