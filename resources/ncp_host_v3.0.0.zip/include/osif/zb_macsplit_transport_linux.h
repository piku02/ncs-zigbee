/* ZBOSS Zigbee software protocol stack
 *
 * Copyright (c) 2012-2021 DSR Corporation, Denver CO, USA.
 * www.dsr-zboss.com
 * www.dsr-corporation.com
 * All rights reserved.
 *
 * This is unpublished proprietary source code of DSR Corporation
 * The copyright notice does not evidence any actual or intended
 * publication of such source code.
 *
 * ZBOSS is a registered trademark of Data Storage Research LLC d/b/a DSR
 * Corporation
 *
 * Commercial Usage
 * Licensees holding valid DSR Commercial licenses may use
 * this file in accordance with the DSR Commercial License
 * Agreement provided with the Software or, alternatively, in accordance
 * with the terms contained in a written agreement between you and
 * DSR.
 */
/* PURPOSE: Linux transports for the split MAC implementations
*/

#ifndef ZB_MAC_TRANSPORT_LINUX_H
#define ZB_MAC_TRANSPORT_LINUX_H

#include "zb_vendor.h"
#include "zb_osif.h"

void zb_mac_transport_init(void);

//#define ZB_GO_IDLE()                      zb_linux_io_iteration(ZB_TRUE)

/**
   I/o without blocking
 */
//#define ZB_TRANSPORT_NONBLOCK_ITERATION() zb_linux_io_iteration(ZB_FALSE)
//#define ZB_TRANSPORT_BLOCK() zb_linux_io_iteration(ZB_TRUE)

/* Timer is combined with i/o, so nothing to do with it */
//#define ZB_TIMER_INIT() /*!< nothing to do here */

#if defined ZB_MACSPLIT_USE_SPI
/**
 * SPI context
 */
typedef struct zb_linux_spi_context_s
{
  zb_bool_t              is_inited;
  osif_ipc_handle_t      spi_fd;
  osif_ipc_handle_t      gpio_fd;       /* used for interrupt */
  osif_ipc_handle_t      reset_gpio_fd; /* used for reset */
} zb_linux_spi_context_t;
#endif /* defined ZB_MACSPLIT_USE_SPI */

#ifndef ZB_APP_TRANSPORT_WAIT_CONTROL
#define ZB_APP_TRANSPORT_WAIT_CONTROL (0) /* by default */
#endif /* ZB_APP_TRANSPORT_WAIT_CONTROL */

#define ZB_MAC_TRANSPORT_WAIT_CONTROL (1)
#define ZB_INTERNAL_TRANSPORT_WAIT_CONTROL (ZB_MAC_TRANSPORT_WAIT_CONTROL)
#define ZB_TRANSPORT_WAIT_CONTROL (ZB_INTERNAL_TRANSPORT_WAIT_CONTROL + ZB_APP_TRANSPORT_WAIT_CONTROL)

OSIF_DECLARE_IPC_WAIT_CONTROL_T(zb_transport_wait_t, ZB_TRANSPORT_WAIT_CONTROL);
/**
   I/O context

   Linux-specific data
 */
typedef struct zb_macsplit_io_ctx_s
{
  int   uart_fd;      /*!< com port file descriptor  */
  FILE* dump_file;  /*!< dump file descriptor for dump got from device */
#if defined ZB_MAC_TRANSPORT_DUMP
  FILE* host_dump;  /*!< dump file for data sent to MCU */
  FILE* mcu_dump; /*!< dump file for data got from MCU */
#endif
#ifdef ZB_MAC_TRANSPORT_UART_USE_RST_LINE
  int uart_rst_fd;
#endif
  zb_transport_buffer_t  in_buffer; /*!< buffer for incoming data storing by lower layer */
  zb_uint64_t            prev_time_us;       /*!< previous system time in us  */
#if defined ZB_MACSPLIT_USE_SPI
  zb_linux_spi_context_t spi_ctx; /*!< SPI context */
#endif
#ifdef ZB_MACSPLIT_HOST
  zb_uint8_t forced_device_reset;
#endif
  zb_transport_wait_t wait_control;
  zb_bool_t is_inited;
} zb_macsplit_io_ctx_t;

#define ZB_MAC_GET_TRANS_INT_FLAG() 0
#define ZB_MAC_TRANSCEIVER_GO_IDLE()

/* default waiting for event timeout (in msec) */
#define ZB_LINUX_TRANSPORT_EVENT_TIMEOUT 1000

void zb_linux_transport_init();
void zb_linux_transport_deinit();
zb_bool_t zb_linux_transport_is_open();
zb_ret_t zb_linux_io_iteration(zb_int_t do_block);
void zb_linux_transport_send_data(zb_uint8_t* buf, zb_uint_t len);
zb_bool_t zb_linux_transport_is_data_available();
zb_uint8_t zb_linux_transport_get_next_byte();
void zb_linux_transport_handle_data();
osif_ipc_handle_t zb_macsplit_transport_port_get_handler(void);
void zb_mac_transport_port_setup_wait(osif_wait_control_t wait_control, zb_int_t *num);
zb_ret_t zb_mac_transport_handle_data(osif_ipc_handle_t h, zb_uint8_t mask);

#if defined ZB_TRANSPORT_LINUX_SPI || defined DOXYGEN
osif_ipc_handle_t zb_linux_spi_init();
void zb_linux_spi_command_write(zb_uint8_t* data, zb_uint8_t len);
#endif /* defined ZB_TRANSPORT_LINUX_SPI || defined DOXYGEN */

#if defined ZB_TRANSPORT_LINUX_UART || defined DOXYGEN
#define ZB_MAC_TRANSPORT_UART_PATH_SIZE 256

/**
 * Open COM port used for MAC.
 *
 * Uses  @ref zb_mac_uart_path(), @ref zb_get_mcu_dump_path(), @ref zb_get_host_dump_path(),
 * and @ref zb_mac_transport_uart_rst_path_get() for UART port path, MAC traffic dump
 * in corresponding directions, and SoC reset line path evaluation correspondingly. These functions
 * have simple weak implementation. If application requires complex logic with non-trivial path
 * selection for (some of) these entities, these functions are to be re-implemented by application
 * programmer.
 */
void zb_mac_uart_open(void);

/**
 * Provides path to UART port for macsplit transport to use.
 *
 * The function has simple weak implementation that returns the value of
 * system environment variable given in the vendor file.
 * If path selection logic is more complex, please overload
 * the function in the application with appropriate implementation.
 */
const char* zb_mac_uart_path();

/**
 * @brief Returns a reference to a serial port that has been opened by the @ref zb_mac_uart_open()
 * 
 * @return zb_serial_port_t 
 */
zb_serial_port_t zb_mac_get_mserial_port();

#if defined ZB_MAC_TRANSPORT_DUMP
/**
 * Provides path to traffic dump file from SoC.
 *
 * The function has simple weak implementation that returns the value of
 * @ref ZB_MAC_SPLIT_FROM_MCU_DUMP_FILE. If path selection logic is more complex, please overload
 * the function in the application with appropriate implementation.
 */
const char* zb_get_mcu_dump_path();

/**
 * Provides path to traffic dump file to SoC.
 *
 * The function has simple weak implementation that returns the value of
 * @ref ZB_MAC_SPLIT_TO_MCU_DUMP_FILE. If path selection logic is more complex, please overload
 * the function in the application with appropriate implementation.
 */
const char* zb_get_host_dump_path();
#endif /* defined ZB_MAC_TRANSPORT_DUMP */

#if defined ZB_MAC_TRANSPORT_UART_USE_RST_LINE
/**
 * Provide path to SoC reset line path.
 *
 * The function has simple weak implementation that returns the value of
 * @ref ZB_MAC_TRANSPORT_UART_RST_PATH. If path selection logic is more complex, please overload
 * the function in the application with appropriate implementation.
 */
const zb_char_t* zb_mac_transport_uart_rst_path_get();
#endif /* defined ZB_MAC_TRANSPORT_UART_USE_RST_LINE */

void zb_mac_uart_close();
zb_uint_t zb_mac_uart_read(zb_uint8_t* buf, zb_uint_t to_read);
void zb_mac_uart_write(zb_uint8_t* buf, zb_uint_t len);

void zb_linux_transport_set_byte_received_cb(zb_callback_t hnd);

#endif /*#if defined ZB_TRANSPORT_LINUX_UART || defined DOXYGEN*/

zb_ret_t zb_linux_turn_off_radio();

#ifdef ZB_MACSPLIT_PTY_TEST
typedef struct zb_macsplit_io_ctx_s
{
  int   uart_fd;      /*!< com port file descriptor  */
  FILE* dump_file;  /*!< dump file descriptor for dump got from device */
#if defined ZB_MAC_TRANSPORT_DUMP
  FILE* host_dump;  /*!< dump file for data sent to MCU */
  FILE* mcu_dump; /*!< dump file for data got from MCU */
#endif
#ifdef ZB_MAC_TRANSPORT_UART_USE_RST_LINE
  int uart_rst_fd;
#endif
  zb_transport_buffer_t  in_buffer; /*!< buffer for incoming data storing by lower layer */
  zb_uint64_t            prev_time_us;       /*!< previous system time in us  */
#if defined ZB_MACSPLIT_USE_SPI
  zb_linux_spi_context_t spi_ctx; /*!< SPI context */
#endif
#ifdef ZB_MACSPLIT_HOST
  zb_uint8_t forced_device_reset;
#endif
  zb_transport_wait_t wait_control;
  zb_bool_t is_inited;
} zb_macsplit_io_ctx_t;
#endif

#endif /* ifndef ZB_MAC_TRANSPORT_LINUX_H */
