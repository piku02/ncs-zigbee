/* ZBOSS Zigbee software protocol stack
 *
 * Copyright (c) 2012-2020 DSR Corporation, Denver CO, USA.
 * www.dsr-zboss.com
 * www.dsr-corporation.com
 * All rights reserved.
 *
 * This is unpublished proprietary source code of DSR Corporation
 * The copyright notice does not evidence any actual or intended
 * publication of such source code.
 *
 * ZBOSS is a registered trademark of Data Storage Research LLC d/b/a DSR
 * Corporation
 *
 * Commercial Usage
 * Licensees holding valid DSR Commercial licenses may use
 * this file in accordance with the DSR Commercial License
 * Agreement provided with the Software or, alternatively, in accordance
 * with the terms contained in a written agreement between you and
 * DSR.
 */
/*  PURPOSE: Internal header for stack - NCP OTA declarations
*/

#ifndef ZB_OSIF_BOOTLOADER_H
#define ZB_OSIF_BOOTLOADER_H 1

/* NOTE: flash bits after erasing equals to 1 and writing to flash is performed by AND operation.
   All constants are valid only for flash memory which erases to 0xFF.
   Magic numbers has to be such that the current number doesn't have meaning ONES in a place where the previous number had a ZEROS
   since in a result will give always 0 = 0 AND 1.
   Examples:
   GOOD: previous = 0xFFFFAAAA and given = 0x1111AAAA in a result will give 0x1111AAAA
   BAD:  previous = 0x0000AAAA and given = 0x1111AAAA in a result will give 0x0000AAAA again as the previous number
    */

/* When bootloader gets this magic number after reset it initializes SPI and 
   HL proto and sends a request to Host to start OTA image transfer 
*/
#define NCP_OTA_START_UPGRADE                   0x00000000u

/* Bootloader sets this value after getting and verifying integrity of received image and proceeds with reset.
   When bootloader gets this magic number after reset it sets NCP_OTA_TRYING_TO_LOAD_IMAGE and jumps to OTA image
*/
#define NCP_OTA_RESET_AND_TRY_TO_LOAD_IMAGE     0xFFFFBBAAu

/* Bootloader sets this number before jumping to OTA image.
   When bootloader gets this magic number after reset this means that OTA image wasn't loaded, therefore
   bootloader initializes SPI and HL proto and sends a request to Host to start OTA image transfer
*/
#define NCP_OTA_TRYING_TO_LOAD_IMAGE            0xFFCCBBAAu

/* OTA image sets this value after loading to signal to bootloader about successfully loading.
*/
#define NCP_OTA_IMAGE_IS_LOADED_SUCCESSFULLY    0xDDCCBBAAu

/* Metadata area is erased by either Uniflash or bootloader. It doesn't matter, just check the first 32bit word of image vector table 
   and decide what to do depending of the value. If there is not 0xFFFFFFFF or 0x00000000 it means that an image is presence.
*/
#define NCP_OTA_METADATA_IS_ERASED              0xFFFFFFFFu

/* These variables are from a linker file */
extern zb_uint32_t zbs_bl_lnk_meta_base;
extern zb_uint32_t zbs_bl_lnk_fw_base;
extern zb_uint32_t zbs_bl_lnk_nvram_base;

#define ZBS_BL_META_ADDR ((zb_uint32_t)&zbs_bl_lnk_meta_base)
#define ZBS_BL_IMAGE_ADDR ((zb_uint32_t)&zbs_bl_lnk_fw_base)
#define ZBS_BL_NVRAM_BASE ((zb_uint32_t)&zbs_bl_lnk_nvram_base)

#endif /* ZB_OSIF_BOOTLOADER_H */
