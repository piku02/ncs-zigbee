/* ZBOSS Zigbee software protocol stack
 *
 * Copyright (c) 2012-2020 DSR Corporation, Denver CO, USA.
 * www.dsr-zboss.com
 * www.dsr-corporation.com
 * All rights reserved.
 *
 * This is unpublished proprietary source code of DSR Corporation
 * The copyright notice does not evidence any actual or intended
 * publication of such source code.
 *
 * ZBOSS is a registered trademark of Data Storage Research LLC d/b/a DSR
 * Corporation
 *
 * Commercial Usage
 * Licensees holding valid DSR Commercial licenses may use
 * this file in accordance with the DSR Commercial License
 * Agreement provided with the Software or, alternatively, in accordance
 * with the terms contained in a written agreement between you and
 * DSR.
 */
/* PURPOSE: ZBOSS stack configuration file for NCP nsng build
*/

#ifndef ZB_VENDOR_CFG_NCP_HOST_NSNG_H
#define ZB_VENDOR_CFG_NCP_HOST_NSNG_H 1

#include "zb_vendor_cfg_zoi_base.h"

#define NCP_MODE
#define NCP_MODE_HOST

#define ZB_HAVE_SERIAL
#define ZB_HAVE_MULTI_SERIAL
#define ZB_HAVE_ASYNC_SERIAL
#define ZB_NCP_TRANSPORT_TYPE_SERIAL
#define ZB_NCP_PORT_ENV_NAME "NCP_SLAVE_PTY"
#define ZB_NCP_PORT_DEFAULT_PATH "/tmp/ncp_slave_pty"

#define NCP_STACK_VERSION (ZBOSS_MAJOR << 24u)
#define NCP_FW_VERSION 0x1234

#define ZB_INTERRUPT_SAFE_CALLBACKS
/* #define ZB_INTERRUPT_SAFE_ALARMS */

#define ZB_BDB_MODE
#define ZB_BDB_ENABLE_FINDING_BINDING
#define ZB_LITE_BDB_ONLY_COMMISSIONING

#endif /* ZB_VENDOR_CFG_NCP_HOST_NSNG_H */
