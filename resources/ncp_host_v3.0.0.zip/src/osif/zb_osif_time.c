/* ZBOSS Zigbee software protocol stack
 *
 * Copyright (c) 2012-2020 DSR Corporation, Denver CO, USA.
 * www.dsr-zboss.com
 * www.dsr-corporation.com
 * All rights reserved.
 *
 * This is unpublished proprietary source code of DSR Corporation
 * The copyright notice does not evidence any actual or intended
 * publication of such source code.
 *
 * ZBOSS is a registered trademark of Data Storage Research LLC d/b/a DSR
 * Corporation
 *
 * Commercial Usage
 * Licensees holding valid DSR Commercial licenses may use
 * this file in accordance with the DSR Commercial License
 * Agreement provided with the Software or, alternatively, in accordance
 * with the terms contained in a written agreement between you and
 * DSR.
 */
/* PURPOSE: time- and sleep-related functions
*/

#define ZB_TRACE_FILE_ID 30013
#include "zb_common.h"

#if defined ZB_CONFIG_LINUX_MIPS_GP && defined ZB_GP_MAC
#include "gphal.h"
#endif

static zb_uint64_t s_time_prev_us;

#if defined UNIX && defined ZB_THREADS
static osif_mutex_t s_time_mutex = PTHREAD_MUTEX_INITIALIZER;

void zb_osif_time_lock(void)
{
  (void)pthread_mutex_lock(&s_time_mutex);
}


void zb_osif_time_unlock(void)
{
  (void)pthread_mutex_unlock(&s_time_mutex);
}
#endif


zb_uint32_t osif_get_time_ms()
{
  struct timeval tmv;
  gettimeofday(&tmv, NULL);
  return (zb_uint32_t)(tmv.tv_sec * 1000 + tmv.tv_usec / 1000);
}


void osif_gettime_us(zb_uint64_t *time_us)
{
  struct timeval t;

  gettimeofday(&t, NULL);
  *time_us = t.tv_sec * 1000000ll + t.tv_usec;
}


void osif_get_clock_monotonic_raw(struct timespec *t)
{
  memset(t, 0, sizeof(struct timespec));
  clock_gettime(CLOCK_MONOTONIC_RAW, t);
}


#define CLOCK_1SEC_TO_NS (1ULL * 1000 * 1000 * 1000)

zb_uint64_t osif_get_clock_delta_ns(struct timespec *t_old, struct timespec *t_new)
{
  zb_uint64_t old_nsec, new_nsec;

  old_nsec = CLOCK_1SEC_TO_NS * t_old->tv_sec + t_old->tv_nsec;
  new_nsec = CLOCK_1SEC_TO_NS * t_new->tv_sec + t_new->tv_nsec;
  return new_nsec - old_nsec;
}

zb_uint64_t osif_get_clock_delta_us(struct timespec *t_old, struct timespec *t_new)
{
  zb_uint64_t delta_us;

  delta_us = (osif_get_clock_delta_ns(t_old, t_new) / (1000));

  return delta_us;
}

zb_uint64_t osif_get_clock_delta_ms(struct timespec *t_old, struct timespec *t_new)
{
  zb_uint64_t delta_ms;

  delta_ms = (osif_get_clock_delta_ns(t_old, t_new) / (1000 * 1000));

  return delta_ms;
}


void osif_gettime_monotonic_us(zb_uint64_t *time_us)
{
  struct timespec time;

  osif_get_clock_monotonic_raw(&time);

  *time_us = ((zb_uint64_t)time.tv_sec) * 1000000ULL;
  *time_us += (zb_uint32_t)time.tv_nsec / 1000U;
}


void osif_get_clock_realtime(struct timespec *t)
{
  memset(t, 0, sizeof(struct timespec));
  clock_gettime(CLOCK_REALTIME, t);
}


zb_uint32_t osif_timespec_to_seconds(struct timespec *t)
{
  return (zb_uint32_t)(t->tv_sec);
}


void osif_seconds_to_timespec(zb_uint32_t s, struct timespec *t)
{
  memset(t, 0, sizeof(struct timespec));
  t->tv_sec = s;
}


zb_uint32_t osif_get_clock_monotonic_sec()
{
  struct timespec t;

  osif_get_clock_monotonic_raw(&t);
  return osif_timespec_to_seconds(&t);
}


zb_uint32_t osif_get_clock_realtime_sec()
{
  struct timespec t;

  osif_get_clock_realtime(&t);
  return osif_timespec_to_seconds(&t);
}

#define MS_ONE_SECOND 1000
#define US_ONE_SECOND 1000000
#define NS_ONE_SECOND 1000000000

int osif_timespec_compare(struct timespec *t1, struct timespec *t2)
{
  if (t1->tv_sec > t2->tv_sec || (t1->tv_sec == t2->tv_sec && t1->tv_nsec > t2->tv_nsec))
  {
    return 1;
  }
  if (t1->tv_sec == t2->tv_sec && t1->tv_nsec == t2->tv_nsec)
  {
    return 0;
  }
  return -1;
}

zb_uint32_t osif_timespec_diff_us_get(struct timespec *t1, struct timespec *t2)
{
  zb_uint32_t diff_us;
  struct timespec *l1;
  struct timespec *l2;
  int compare_res;

  compare_res = osif_timespec_compare(t1, t2);

  if (compare_res == 0)
  {
    return 0;
  }
  else if (compare_res > 0)
  {
    l1 = t1;
    l2 = t2;
  }
  else
  {
    l1 = t2;
    l2 = t1;
  }

  diff_us = (zb_uint32_t)(l1->tv_sec - l2->tv_sec) * US_ONE_SECOND;
  diff_us += ((l1->tv_nsec - l2->tv_nsec) / 1000);
  return diff_us;
}

void osif_timespec_add_sec(struct timespec *t, zb_uint32_t sec)
{
  t->tv_sec += sec;
}

void osif_timespec_add_ms(struct timespec *t, zb_uint32_t ms)
{
  zb_uint32_t nsec;

  nsec = (zb_uint32_t)(t->tv_nsec + (ms % MS_ONE_SECOND) * US_ONE_SECOND);
  t->tv_sec += ms / MS_ONE_SECOND + nsec / NS_ONE_SECOND;
  t->tv_nsec = nsec % NS_ONE_SECOND;
}


void osif_timespec_add_us(struct timespec *t, zb_uint32_t us)
{
  zb_uint32_t nsec;

  nsec = (zb_uint32_t)t->tv_nsec + (us % US_ONE_SECOND) * MS_ONE_SECOND;
  t->tv_sec += us / US_ONE_SECOND + nsec / NS_ONE_SECOND;
  t->tv_nsec = nsec % NS_ONE_SECOND;
}


void osif_timespec_add_ns(struct timespec *t, zb_uint32_t ns)
{
  zb_uint32_t nsec;

  nsec = (zb_uint32_t)(t->tv_nsec + (ns % NS_ONE_SECOND));
  t->tv_sec += ns / NS_ONE_SECOND + nsec / NS_ONE_SECOND;
  t->tv_nsec = nsec % NS_ONE_SECOND;
}

/* 1 BE = 15.360 ms */
#define BE_IN_US 15360
static struct timespec initial_ts2be = {0};
zb_uint32_t osif_current_time_to_be()
{
  struct timespec t;
  zb_uint32_t res;

  osif_get_clock_monotonic_raw(&t);

  if (initial_ts2be.tv_sec == 0 &&
      initial_ts2be.tv_nsec == 0)
  {
    initial_ts2be.tv_sec = t.tv_sec;
    initial_ts2be.tv_nsec = t.tv_nsec;
  }
  res = (zb_uint32_t)(((t.tv_sec - initial_ts2be.tv_sec) * US_ONE_SECOND) / BE_IN_US);
  res += ((t.tv_nsec - initial_ts2be.tv_nsec) / 1000) / BE_IN_US;
  return res;
}


zb_uint32_t zb_get_utc_time()
{
  time_t t = time(NULL);
  return (zb_uint32_t)t;
}

#if defined ZB_CONFIG_LINUX_MIPS_GP && defined ZB_GP_MAC

zb_time_t osif_transceiver_time_get()
{
  zb_time_t gp_time;

  gpHal_GetTime((UInt32*)&gp_time);

  return gp_time;
}


void osif_sleep_using_transc_timer(zb_time_t interval)
{
  zb_time_t t0 = osif_transceiver_time_get();
  zb_time_t t;

  do
  {
    t = osif_transceiver_time_get();
  }
  while (ZB_TIME_SUBTRACT(t, t0) < interval);

  /* Need to update the internal stack timer immediately after the sleep 
   * when using sleep with the transceiver timer. */ 
  zb_osif_update_timer();  
}

#else

zb_time_t osif_transceiver_time_get()
{
  struct timeval tmv;

  gettimeofday(&tmv, NULL);
  return (zb_time_t)(tmv.tv_sec * (1000000) + tmv.tv_usec);
}


void osif_sleep_using_transc_timer(zb_time_t t)
{
  usleep(t);

  /* Need to update the internal stack timer immediately after the sleep 
   * when using sleep with the transceiver timer. */ 
  zb_osif_update_timer();
}
#endif

void osif_usleep(zb_uint_t us)
{
  usleep(us);
}


void zb_osif_wait_ms(zb_uint16_t ms)
{
  while (ms--)
  {
    osif_usleep(1000);
  }
}


#ifdef ZB_USE_SLEEP
zb_uint32_t zb_osif_sleep(zb_uint32_t sleep_tmo)
{
  osif_usleep(sleep_tmo * 1000);

  return sleep_tmo;
}


void zb_osif_wake_up()
{
}
#endif

void zb_osif_init_timer(void)
{
  osif_gettime_monotonic_us(&s_time_prev_us);
}


/**
   Move internal stack time taking rounding errors into account
 */
void zb_osif_update_timer(void)
{
  zb_uint64_t curr_time_us;
  zb_time_t bi_diff;

  /* Get time in us, calculate internal ZBOSS time. */
  osif_gettime_monotonic_us(&curr_time_us);
  bi_diff = (zb_time_t)((curr_time_us - s_time_prev_us) / ZB_BEACON_INTERVAL_USEC);

  s_time_prev_us += bi_diff * ZB_BEACON_INTERVAL_USEC;

  ZB_OSIF_TIME_LOCK();
  ZB_TIMER_CTX().timer += bi_diff;
  ZB_OSIF_TIME_UNLOCK();

  TRACE_MSG(TRACE_OSIF4, "zb_osif_update_timer: timer %d started %d", (FMT__D_D, zb_timer_get(), ZB_TIMER_CTX().started));
}
