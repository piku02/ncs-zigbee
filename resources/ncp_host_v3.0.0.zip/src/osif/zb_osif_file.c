/* ZBOSS Zigbee software protocol stack
 *
 * Copyright (c) 2012-2020 DSR Corporation, Denver CO, USA.
 * www.dsr-zboss.com
 * www.dsr-corporation.com
 * All rights reserved.
 *
 * This is unpublished proprietary source code of DSR Corporation
 * The copyright notice does not evidence any actual or intended
 * publication of such source code.
 *
 * ZBOSS is a registered trademark of Data Storage Research LLC d/b/a DSR
 * Corporation
 *
 * Commercial Usage
 * Licensees holding valid DSR Commercial licenses may use
 * this file in accordance with the DSR Commercial License
 * Agreement provided with the Software or, alternatively, in accordance
 * with the terms contained in a written agreement between you and
 * DSR.
 */
/* PURPOSE: File i/o, trace, traffic dump
*/
#define ZB_TRACE_FILE_ID 30012
#include "zb_common.h"
#include <errno.h>
#include <syslog.h>
#include <dirent.h>

#ifdef ZB_USE_LOGFILE_ROTATE
#include <unistd.h>
#include <sys/stat.h>
#include <stdbool.h>
#include <stdlib.h>
#endif

#ifdef ZB_PLATFORM_LINUX
#ifdef MACOSX
#include <sys/syslimits.h>
#else
#include "linux/limits.h"
#endif
#include "fcntl.h"
#include <sys/stat.h>
#endif

#if defined ZB_TRACE_TO_STDOUT && defined ZB_USE_LOGFILE_ROTATE
#error ZB_TRACE_TO_STDOUT and ZB_USE_LOGFILE_ROTATE are incompatible
#endif

#if defined ZB_TRACE_TO_STDOUT && defined ZB_TRACE_USE_FULL_BUFFERING
#error ZB_TRACE_TO_STDOUT and ZB_TRACE_USE_FULL_BUFFERING are incompatible
#endif

struct timespec start_t = { .tv_sec = ~0, .tv_nsec = ~0 };

/**
   Global trace mutex for Unix trace implementation
 */
#if defined ZB_THREADS
static pthread_mutex_t s_trace_mutex = PTHREAD_MUTEX_INITIALIZER;
#endif /* ZB_THREADS */

#ifdef ZB_FILE_PATH_MGMNT

zb_file_path_base_type_t zb_file_path_types[ZB_FILE_PATH_MAX_TYPES];
#endif  /* ZB_FILE_PATH_MGMNT */

#ifdef ZB_USE_LOGFILE_ROTATE
#define ZB_LOG_FILE_INDEX_UNDEFINED ((zb_uint32_t )(~0))

static zb_char_t s_logname[255];

#ifdef ZB_USE_LOGFILE_ROTATE
zb_ret_t zb_osif_log_file_rotate(void);

void zb_trace_check_rotate(void)
{
  zb_uint32_t file_size = 0;
  zb_char_t namefile[ZB_MAX_FILE_PATH_SIZE];

  snprintf(namefile, sizeof(namefile), "%s%s.log",
          ZB_FILE_PATH_GET(ZB_FILE_PATH_BASE_TRACE_LOGS,
                           ZB_TMP_FILE_PATH_PREFIX),
          s_logname);
  file_size = zb_osif_get_file_size(namefile);

  if(file_size > ZB_DEFAULT_MAX_LOGFILE_SIZE)
  {
#if defined (ZB_TRACE_TO_FILE)
    zb_trace_file_flush();
#endif
    zb_osif_log_file_rotate();
  }
}
#endif

zb_uint32_t zb_osif_get_file_size(zb_char_t *name)
{
  struct stat file_stat;

  if(stat(name, &file_stat) == -1)
  {
    return -1;
  }
  return file_stat.st_size;
}


static zb_uint32_t zb_osif_log_file_get_index(void)
{
  struct dirent *de;
  zb_char_t   file_name[ZB_MAX_FILE_PATH_SIZE];
  zb_char_t  *ptr;
  zb_uint32_t val = 0;
  zb_uint32_t f_idx = 0;

  DIR *dr = opendir(ZB_FILE_PATH_GET(ZB_FILE_PATH_BASE_TRACE_LOGS,
                                     ZB_TMP_FILE_PATH_PREFIX));

  if (dr == NULL)
  {
    return 0;
  }

  snprintf(file_name, sizeof(file_name), "%s.log.", s_logname);

  while ((de = readdir(dr)) != NULL)
  {
    if (de->d_type == DT_REG)
    {
      ptr = strstr(de->d_name, file_name);
      if (ptr)
      {
        val = atoi(ptr + strlen(file_name));

        if (val + 1 > 0)
        {
          if (val + 1 > f_idx)
          {
            f_idx = val + 1;
          }
        }
        else
        {
          /* TODO: handle index overflow in the proper way! */
          f_idx = 0;
          break;
        }
      }
    }
  }

  closedir(dr);

  return f_idx;
}


zb_ret_t zb_osif_log_file_rotate(void)
{
  static zb_uint32_t f_idx = ZB_LOG_FILE_INDEX_UNDEFINED;
  zb_char_t suffix[10];
  zb_char_t rm_file_name[ZB_MAX_FILE_PATH_SIZE];
  zb_char_t new_name[ZB_MAX_FILE_PATH_SIZE];
  zb_char_t namefile[ZB_MAX_FILE_PATH_SIZE];
  zb_ret_t ret = RET_OK;

  if (zb_trace_is_disable_deinit() == ZB_FALSE)
  {
    /* 09/19/2018 EE CR:MINOR Better have full path in s_logname and do not compose the name in 3 places */
    snprintf(namefile, sizeof(namefile), "%s%s.log",
            ZB_FILE_PATH_GET(ZB_FILE_PATH_BASE_TRACE_LOGS,
                             ZB_TMP_FILE_PATH_PREFIX),
            s_logname);
    strcpy(new_name, namefile);

    /* get last log file index */
    if (f_idx == ZB_LOG_FILE_INDEX_UNDEFINED)
    {
      f_idx = zb_osif_log_file_get_index();
    }
    else
    {
      f_idx++;
    }

    snprintf(suffix, sizeof(suffix), ".%d", f_idx);
    strcat(new_name, suffix);

    zb_trace_deinit_file();

    /* 09/19/2018 EE CR:MAJOR Check ret code! Maybe, file is not renamed? In such case there will be no rotation. */
    rename(namefile, new_name);
    zb_trace_init_file(s_logname);

    /* remove old log files */
    if(f_idx >= MAX_LOGFILE_INDEX)
    {
  /* 09/19/2018 EE CR:MAJOR unlink not just one file, but all previous files. It could be there if we are crashing. */
      snprintf(rm_file_name, sizeof(rm_file_name), "%s.%d", namefile, f_idx-MAX_LOGFILE_INDEX);
      remove(rm_file_name);
    }
  }
  else
  {
    ret = RET_OPERATION_FAILED;
  }

  return ret;
}

#endif

zb_int_t zb_file_get_current_process_path(zb_char_t *buf, zb_uint16_t len)
{
  return (zb_int_t)readlink("/proc/self/exe", buf, len);
}

zb_int_t zb_file_get_current_process_dir(zb_char_t *buf, zb_uint16_t len)
{
  zb_int_t ret;

  if ((ret = zb_file_get_current_process_path(buf, len)))
  {
    const zb_char_t *str = strrchr(buf, '/');

    if (str)
    {
      buf[str - buf] = '\0';
    }
  }
  return ret;
}

#ifdef ZB_FILE_PATH_MGMNT
ZB_WEAK_PRE void app_file_path_init_defaults(void) ZB_WEAK;
void app_file_path_init_defaults(void)
{
  /* Empty implementation. Should be defined by the application. */
}

static void zb_file_path_init_defaults(void)
{
  ZB_BZERO(zb_file_path_types, sizeof(zb_file_path_types));

  zb_file_path_declare(ZB_FILE_PATH_BASE_ROMFS_BINARIES, ZB_BINARY_FILE_PATH_PREFIX);
  zb_file_path_declare(ZB_FILE_PATH_BASE_MNTFS_BINARIES, ZB_BINARY_FILE_PATH_PREFIX);
  zb_file_path_declare(ZB_FILE_PATH_BASE_MNTFS_USER_DATA, ZB_USERDATA_FILE_PATH_PREFIX);
  zb_file_path_declare(ZB_FILE_PATH_BASE_RAMFS_UNIX_SOCKET, UNIX_DOMAIN_SOCKETS_DIR);
  zb_file_path_declare(ZB_FILE_PATH_BASE_RAMFS_TMP_DATA, ZB_TMP_FILE_PATH_PREFIX);
  zb_file_path_declare(ZB_FILE_PATH_BASE_TRACE_LOGS, ZB_TMP_FILE_PATH_PREFIX);
#ifdef ZB_MNTFS_FOR_TRACE_LOGS
  zb_file_path_declare(ZB_FILE_PATH_BASE_MNTFS_TRACE_LOGS, ZB_USERDATA_LOG_FILE_PATH_PREFIX);
#endif

  app_file_path_init_defaults();
}


zb_ret_t zb_file_path_declare(zb_uint8_t base_type, const char *base)
{
  ZB_ASSERT(base_type < ZB_FILE_PATH_MAX_TYPES);
  strcpy(zb_file_path_types[base_type].base, base);

  zb_file_path_types[base_type].declared = ZB_TRUE;
  return RET_OK;
}


const char* zb_file_path_get(zb_uint8_t base_type, const char *default_base)
{
  ZB_ASSERT(base_type < ZB_FILE_PATH_MAX_TYPES);

  if (zb_file_path_types[base_type].declared)
  {
    return zb_file_path_types[base_type].base;
  }
  return default_base;
}


void  zb_file_path_get_with_postfix(zb_uint8_t base_type,const char *default_base,
				    const char *postfix, char *file_path)
{
  const char *path = NULL;

  ZB_ASSERT(base_type < ZB_FILE_PATH_MAX_TYPES);

  if (zb_file_path_types[base_type].declared)
  {
    path = zb_file_path_types[base_type].base;
  }
  else
  {
    path = default_base;
  }

  snprintf(file_path, ZB_MAX_FILE_PATH_SIZE, "%s%s", path, postfix);
}

void zb_file_path_init_from_config(const char * process_path, const char * base_config_file_name,
                                   const char * config_file_name, int items_count, zb_file_config_item_t *items)
{
  if (zb_osif_check_file_exist(config_file_name, F_OK))
  {
    zb_file_config_read(config_file_name, items_count, items);
  }
  else
  {
    /* Let's try to find the file in the same directory where the process is running */
    if (strlen(process_path) != 0)
    {
      zb_char_t path[ZB_MAX_FILE_PATH_SIZE];

      ZB_BZERO(path, ZB_MAX_FILE_PATH_SIZE);

      if (snprintf(path, ZB_MAX_FILE_PATH_SIZE, "%s/%s", process_path, base_config_file_name) > 0)
      {
        if (zb_osif_check_file_exist(path, F_OK))
        {
          zb_file_config_read(path, items_count, items);

          /* fix relative path to full */
          {
            zb_uint16_t i;

            for (i = 0; i < items_count; ++i)
            {
              if (((const char *)items[i].value)[0] && ((const char *)items[i].value)[0] != '/')
              {
                zb_char_t tmp[ZB_MAX_FILE_PATH_SIZE];

                strcpy(tmp, (const char *)items[i].value);
                ZB_BZERO(items[i].value, items[i].value_size);
                snprintf((char *)items[i].value, items[i].value_size, "%s/%s", process_path, tmp);
              }
            }
          }
        }
      }
    }
  }
}

ZB_WEAK_PRE void app_file_path_init(const char * process_path) ZB_WEAK;
void app_file_path_init(const char * process_path)
{
  /* Empty implementation. Should be defined by the application. */
  ZVUNUSED(process_path);
}

typedef struct zb_file_path_config_s
{
  char rfs_binaries_dir[ZB_MAX_FILE_PATH_SIZE];
  char mntfs_binaries_dir[ZB_MAX_FILE_PATH_SIZE];
  char mntfs_userdata_dir[ZB_MAX_FILE_PATH_SIZE];
#ifdef ZB_MNTFS_FOR_TRACE_LOGS
  char mntfs_logs_dir[ZB_MAX_FILE_PATH_SIZE];
#endif
  char ramfs_unix_sock_dir[ZB_MAX_FILE_PATH_SIZE];
  char ramfs_logs_dir[ZB_MAX_FILE_PATH_SIZE];
  char ramfs_tmp_dir[ZB_MAX_FILE_PATH_SIZE];
} zb_file_path_config_t;

/* set paths to dirs, paths defined in the config files have priority over defined in the source code */
void zb_file_path_init(void)
{
  zb_char_t process_path[ZB_MAX_FILE_PATH_SIZE];
  zb_file_path_config_t config;

  zb_file_config_item_t items[] = {
    {
      RFS_BINARIES_DIR,
      config.rfs_binaries_dir,
      sizeof(config.rfs_binaries_dir),
      ZB_FILE_CONFIG_ITEM_STRING_TYPE
    },
    {
      MNTFS_BINARIES_DIR,
      config.mntfs_binaries_dir,
      sizeof(config.mntfs_binaries_dir),
      ZB_FILE_CONFIG_ITEM_STRING_TYPE
    },
    {
      MNTFS_USERDATA_DIR,
      config.mntfs_userdata_dir,
      sizeof(config.mntfs_userdata_dir),
      ZB_FILE_CONFIG_ITEM_STRING_TYPE
    },
#ifdef ZB_MNTFS_FOR_TRACE_LOGS
    {
      MNTFS_LOGS_DIR,
      config.mntfs_logs_dir,
      sizeof(config.mntfs_logs_dir),
      ZB_FILE_CONFIG_ITEM_STRING_TYPE
    },
#endif
    {
      RAMFS_UNIX_DOMAIN_SOCK_DIR,
      config.ramfs_unix_sock_dir,
      sizeof(config.ramfs_unix_sock_dir),
      ZB_FILE_CONFIG_ITEM_STRING_TYPE
    },
    {
      RAMFS_LOGS_DIR,
      config.ramfs_logs_dir,
      sizeof(config.ramfs_logs_dir),
      ZB_FILE_CONFIG_ITEM_STRING_TYPE
    },
    {
      RAMFS_TMP_DIR,
      config.ramfs_tmp_dir,
      sizeof(config.ramfs_tmp_dir),
      ZB_FILE_CONFIG_ITEM_STRING_TYPE
    }
  };

  TRACE_MSG(TRACE_COMMON1, ">zb_file_path_init", (FMT__0));

  ZB_BZERO(&config, sizeof(zb_file_path_config_t));

  /* get process current dir */
  ZB_BZERO(process_path, ZB_MAX_FILE_PATH_SIZE);

  zb_file_get_current_process_dir(process_path, ZB_MAX_FILE_PATH_SIZE);

  /* set default paths */
  zb_file_path_init_defaults();

  zb_file_path_init_from_config(process_path, RFS_CONFIG_FILE_NAME,
                                RFS_CONFIG_FILE_PATH, ZB_ARRAY_SIZE(items), items);

  zb_file_path_init_from_config(process_path, MNTFS_CONFIG_FILE_NAME,
                                MNTFS_CONFIG_FILE_PATH, ZB_ARRAY_SIZE(items), items);

  zb_file_path_init_from_config(process_path, RAMFS_CONFIG_FILE_NAME,
                                RAMFS_CONFIG_FILE_PATH, ZB_ARRAY_SIZE(items), items);

  /* set paths from configs */
  if (ZB_FILE_CONFIG_EXISTS(config.rfs_binaries_dir))
  {
    zb_file_path_declare(ZB_FILE_PATH_BASE_ROMFS_BINARIES,
                         config.rfs_binaries_dir);
    TRACE_MSG(TRACE_COMMON1, "ZB_FILE_PATH_BASE_ROMFS_BINARIES: %s", (FMT__P, config.rfs_binaries_dir));
  }

  if (ZB_FILE_CONFIG_EXISTS(config.mntfs_binaries_dir))
  {
    zb_file_path_declare(ZB_FILE_PATH_BASE_MNTFS_BINARIES,
                         config.mntfs_binaries_dir);
    TRACE_MSG(TRACE_COMMON1, "ZB_FILE_PATH_BASE_MNTFS_BINARIES: %s", (FMT__P, config.mntfs_binaries_dir));
  }

  if (ZB_FILE_CONFIG_EXISTS(config.mntfs_userdata_dir))
  {
    zb_file_path_declare(ZB_FILE_PATH_BASE_MNTFS_USER_DATA,
                         config.mntfs_userdata_dir);
    TRACE_MSG(TRACE_COMMON1, "ZB_FILE_PATH_BASE_MNTFS_USER_DATA: %s", (FMT__P, config.mntfs_userdata_dir));
  }

#ifdef ZB_MNTFS_FOR_TRACE_LOGS
  if (ZB_FILE_CONFIG_EXISTS(config.mntfs_logs_dir))
  {
    zb_file_path_declare(ZB_FILE_PATH_BASE_MNTFS_TRACE_LOGS,
                         config.mntfs_logs_dir);
    TRACE_MSG(TRACE_COMMON1, "ZB_FILE_PATH_BASE_MNTFS_TRACE_LOGS: %s", (FMT__P, config.mntfs_logs_dir));
  }
#endif

  if (ZB_FILE_CONFIG_EXISTS(config.ramfs_unix_sock_dir))
  {
    zb_file_path_declare(ZB_FILE_PATH_BASE_RAMFS_UNIX_SOCKET,
                         config.ramfs_unix_sock_dir);
    TRACE_MSG(TRACE_COMMON1, "ZB_FILE_PATH_BASE_RAMFS_UNIX_SOCKET: %s", (FMT__P, config.ramfs_unix_sock_dir));
  }

  if (ZB_FILE_CONFIG_EXISTS(config.ramfs_logs_dir))
  {
    zb_file_path_declare(ZB_FILE_PATH_BASE_RAMFS_TRACE_LOGS,
                         config.ramfs_logs_dir);
    TRACE_MSG(TRACE_COMMON1, "ZB_FILE_PATH_BASE_RAMFS_TRACE_LOGS: %s", (FMT__P, config.ramfs_logs_dir));
  }

  if (ZB_FILE_CONFIG_EXISTS(config.ramfs_tmp_dir))
  {
    zb_file_path_declare(ZB_FILE_PATH_BASE_RAMFS_TMP_DATA,
                         config.ramfs_tmp_dir);
    TRACE_MSG(TRACE_COMMON1, "ZB_FILE_PATH_BASE_RAMFS_TMP_DATA: %s", (FMT__P, config.ramfs_tmp_dir));
  }

  app_file_path_init(process_path);

  TRACE_MSG(TRACE_COMMON1, "<zb_file_path_init", (FMT__0));
}
#endif  /* ZB_FILE_PATH_MGMNT */

zb_ret_t zb_file_config_read(const char * config_file_name, zb_int_t items_count, zb_file_config_item_t *items)
{
  char            buffer[256] = {0};
  zb_osif_file_t *f;
  zb_ret_t        ret = RET_ERROR;

  TRACE_MSG(TRACE_COMMON1, ">zb_file_config_read %s", (FMT__P, config_file_name));

  do
  {
    f = zb_osif_file_open((char *)config_file_name, "r");

    if (!f)
    {
      TRACE_MSG(TRACE_ERROR, "failed to open config file: %s", (FMT__P, config_file_name));
      break;
    }

    while (fgets(buffer, sizeof(buffer), f))
    {
      zb_int_t i = 0;
      char * param_name = NULL;
      char * param_value = NULL;
      char *tok_ptr = NULL;

      if (buffer[0] == '#')
      {
        /* no action if row is comment */
        continue;
      }

      /* parse first part of row (parameter name) */
      param_name = strtok_r(buffer, ZB_FILE_CONFIG_DELIMITERS, &tok_ptr);

      if (!param_name)
      {
        continue;
      }

      /* recognize what parameter is it */
      for (i = 0; i < items_count; ++i)
      {
        if (!strncmp(param_name, items[i].name,
                     strlen(items[i].name)))
        {
          break;
        }
      }

      if (i == items_count)
      {
        continue;
      }

      /* parse second part of config row (parameter value) */
      param_value = strtok_r(NULL, ZB_FILE_CONFIG_DELIMITERS, &tok_ptr);

      if (!param_value)
      {
        continue;
      }

      switch (items[i].type)
      {
        case ZB_FILE_CONFIG_ITEM_STRING_TYPE:
          ZB_ASSERT((int)strlen(param_value) < items[i].value_size);
          strcpy((char *)items[i].value, param_value);
          break;

        case ZB_FILE_CONFIG_ITEM_NUMBER_TYPE:
        {
          switch (items[i].value_size)
          {
            case 1:
              *(zb_int8_t *)items[i].value = atoi(param_value);
              break;

            case 2:
              *(zb_int16_t *)items[i].value = atoi(param_value);
              break;

            case 4:
              *(zb_int32_t *)items[i].value = atoi(param_value);
              break;

            default:
              ZB_ASSERT(0);
              break;
          };
          break;
        }

        default:
          break;
      };
    }
    zb_osif_file_close(f);
    ret = RET_OK;
  }
  while (0);
  TRACE_MSG(TRACE_APP1, "<zb_file_config_read %hd", (FMT__H, ret));
  return ret;
}

zb_ret_t zb_file_config_update(const char * config_file_name, zb_int_t items_count, zb_file_config_item_t *items)
{
  zb_osif_file_t *config_f;
  zb_osif_file_t *tmp_f;
  zb_ret_t        ret = RET_OK;
  char line[256] = {0};
  char tmp_file_name[256] = {0};

  ZB_ASSERT(config_file_name);
  ZB_ASSERT(items);
  ZB_ASSERT((strlen(config_file_name) + 4) < sizeof(tmp_file_name));

  snprintf(tmp_file_name, sizeof(tmp_file_name), "%s.tmp", config_file_name);
  zb_osif_file_copy(config_file_name, tmp_file_name);

  config_f = zb_osif_file_open((char *)config_file_name, "w");
  tmp_f = zb_osif_file_open((char *)tmp_file_name, "r");

  if (config_f && tmp_f)
  {
    zb_int_t i = 0;
    size_t opt_name_len;

    while (fgets(line, sizeof(line), tmp_f))
    {
      /* recognize what parameter is it */
      for (i = 0; i < items_count; i++)
      {
        opt_name_len = strlen(items[i].name);

        if (strlen(line) >= (opt_name_len+1)) /* +1 for '=' */
        {
          /* No spaces allowed in config file for now */
          if ((0 == memcmp(line, items[i].name, opt_name_len)) &&
            line[opt_name_len] == '=')
          {
            //match
            break;
          }
        }
      }

      if (i < items_count)
      {
        ZB_BZERO(line, sizeof(line));

        switch (items[i].type)
        {
          case ZB_FILE_CONFIG_ITEM_STRING_TYPE:
          {
            snprintf(line, sizeof(line), "%s=%s\n", items[i].name, (char*)items[i].value);
            break;
          }

          case ZB_FILE_CONFIG_ITEM_NUMBER_TYPE:
          {
            switch (items[i].value_size)
            {
              case 1:
                snprintf(line, sizeof(line), "%s=%d\n", items[i].name, *(zb_int8_t *)items[i].value);
                break;

              case 2:
                snprintf(line, sizeof(line), "%s=%d\n", items[i].name, *(zb_int16_t *)items[i].value);
                break;

              case 4:
                snprintf(line, sizeof(line), "%s=%d\n", items[i].name, *(zb_int32_t *)items[i].value);
                break;

              default:
                ZB_ASSERT(0);
                break;
            };
            break;
          }

          default:
            break;
        }
      }

      zb_osif_file_write(config_f, (zb_uint8_t *)line, (zb_uint_t)strlen(line));
    }

    zb_osif_file_flush(config_f);
  }
  else
  {
    ret = RET_ERROR;
  }

  if (config_f)
  {
    zb_osif_file_close(config_f);
  }

  if (tmp_f)
  {
    zb_osif_file_close(tmp_f);
    zb_osif_file_remove(tmp_file_name);
  }

  return ret;
}

/**
   Unix-specific trace file open and mutex init

   @param name - process name. Trace file name generated from this name and current pid
 */
zb_osif_file_t *zb_osif_init_trace(zb_char_t *name)
{
#ifdef ZB_TRACE_TO_STDOUT
  ZVUNUSED(name);

  return stdout;
#else
  zb_osif_file_t *f;
  zb_char_t namefile[ZB_MAX_FILE_PATH_SIZE];
  const char *path;

  path = ZB_FILE_PATH_GET(ZB_FILE_PATH_BASE_TRACE_LOGS,
                          ZB_TMP_FILE_PATH_PREFIX);
  if (strlen(path))
  {
    snprintf(namefile, ZB_MAX_FILE_PATH_SIZE, "%s%s.log", path, name);
  }
  else
  {
#ifdef ZB_BINARY_TRACE
    snprintf(namefile, ZB_MAX_FILE_PATH_SIZE, "%s.bin.log", name);
#else
    snprintf(namefile, ZB_MAX_FILE_PATH_SIZE, "%s.log", name);
#endif
  }

  f = fopen(namefile, "a+");
  if (!f)
  {
    f = fopen(namefile, "w");
  }

  if (start_t.tv_nsec == ~0 && start_t.tv_sec == ~0)
  {
    osif_get_clock_monotonic_raw(&start_t);
  }

#ifdef ZB_USE_LOGFILE_ROTATE
  /* save log file name, for further use */
  /* according memcheck s_logname and *name have overlap data
   * so, if copying takes place between objects that overlap, the behavior is undefined.
   * check that we use different pointers and it is not the same string
   */
  if (s_logname != name)
  {
    strcpy(s_logname, name);
  }
#endif

  if (f)
  {
#if defined(ZB_TRACE_USE_FULL_BUFFERING)
    struct stat stats;
    /* optimal buf size for setvbuf() in bytes*/
    blksize_t   optimal_blksize;
#ifdef ZB_TRACE_BUFF_SIZE
    optimal_blksize = ZB_TRACE_BUFF_SIZE;
#else
    if(fstat(fileno(f), &stats) < 0)
    {
      optimal_blksize = BUFSIZ;
    }
    else
    {
      optimal_blksize = stats.st_blksize;
    }
#endif
    /*_IOFBF full buffering */
    setvbuf(f, NULL, _IOFBF, optimal_blksize);
#else
    /* 09/19/2018 EE CR:MINOR Not meaningful for binary trace. And, anyway, better call flush explicitly. */
    /* set line buffering so not need to call fflush() */
    /* _IOLBF line buffering */
    setvbuf(f, NULL, _IOLBF, 512);
#endif
  }

  return f;
#endif /* ZB_TRACE_TO_STDOUT */
}


/* 08/23/2018 EE CR:MAJOR How do you rotate a traffic dump file? Will it grow forever? */

zb_osif_file_t *zb_osif_init_dump(zb_char_t *name)
{
  zb_osif_file_t *f;
  zb_char_t namefile[255];

  snprintf(namefile, sizeof(namefile), "%s.dump", name);

#ifdef ZB_NSNG_CI
  if (getenv("ZB_FIFO_TRAFFIC_DUMP") != NULL)
  {
    mkfifo(namefile, 0600);
  }
#endif /* ZB_NSNG_CI */

  f = fopen(namefile, "a+");
  return f;
}

zb_bool_t zb_osif_check_dir_exist(const zb_char_t *name)
{
  struct stat st = {0};

  if (stat(name, &st) == 0)
  {
    if (S_ISDIR(st.st_mode))
    {
      return ZB_TRUE;
    }
  }
  return ZB_FALSE;
}

zb_int_t zb_osif_create_dir(const zb_char_t *name)
{
  if (zb_osif_check_dir_exist(name))
  {
    return 0;
  }

  if (mkdir(name, 0700) != 0)
  {
    return -errno;
  }
  return 0;
}

zb_bool_t zb_osif_check_file_exist(const zb_char_t *name, const zb_uint8_t mode)
{
  if (!access(name, mode))
  {
    return ZB_TRUE;
  }
  return ZB_FALSE;
}


zb_osif_file_t *zb_osif_file_open(const zb_char_t *name, const zb_char_t *mode)
{
  zb_osif_file_t *f;
  f = fopen(name, mode);
  return f;
}

#define COPY_BUF_SIZE 4096

void zb_osif_file_copy(const zb_char_t *name_src, const zb_char_t *name_dst)
{
  int f_src;
  int f_dst;
  int err_r;
  int err_w;
  unsigned char buf[COPY_BUF_SIZE];

  f_src = open(name_src, O_RDONLY);
  f_dst = open(name_dst, O_CREAT | O_WRONLY, S_IWRITE | S_IREAD);

  while (1)
  {
    err_r = (int)read(f_src, buf, COPY_BUF_SIZE);

    if (err_r == -1)
    {
      ZB_ASSERT(0);
    }
    else if (err_r == 0)
    {
      break;
    }
    else
    {
      err_w = (int)write(f_dst, buf, err_r);
      if (err_w == -1)
      {
        ZB_ASSERT(0);
      }
    }
  }

  close(f_src);
  close(f_dst);
}


zb_osif_file_t *zb_osif_popen(zb_char_t *arg)
{
  return popen(arg, "w");
}


zb_osif_file_t *zb_osif_file_stdout()
{
  return stdout;
}


zb_osif_file_t *zb_osif_file_stdin()
{
  return stdin;
}


void zb_osif_file_close(zb_osif_file_t *f)
{
  fflush(f);
  fclose(f);
}


int zb_osif_file_remove(const zb_char_t *name)
{
  return remove(name);
}


void zb_osif_trace_printf(zb_osif_file_t *f, const zb_char_t *format, ...)
{
  va_list   arglist;
  va_start(arglist, format);
  vfprintf(f, format, arglist);
  va_end(arglist);
}


void zb_osif_trace_vprintf(zb_osif_file_t *f, const zb_char_t *format, va_list arglist)
{
  vfprintf(f, format, arglist);
}


int zb_osif_file_read(zb_osif_file_t *f, zb_uint8_t *buf, zb_uint_t len)
{
  return (int)fread(buf, 1, len, f);
}


int zb_osif_file_write(zb_osif_file_t *f, const zb_uint8_t *buf, zb_uint_t len)
{
  return (int)fwrite(buf, 1, len, f);
}


int zb_osif_file_flush(zb_osif_file_t *f)
{
  zb_int_t ret;

  ret = fflush(f);

  return ret;
}


int zb_osif_file_sync(zb_osif_file_t *f)
{
#ifdef ZB_FILE_ENABLE_FSYNC
/* removed fsync from all builds: too slow and not really necessary */
  return fsync(fileno(f));
#else
  ZVUNUSED(f);
  return 0;
#endif
}


int zb_osif_file_truncate(zb_osif_file_t *f, zb_uint32_t off)
{
  zb_osif_file_flush(f);
  zb_osif_file_seek(f, 0, SEEK_SET);
  return ftruncate(fileno(f), off);
}


int zb_osif_file_seek(zb_osif_file_t *f, zb_uint32_t off, zb_uint8_t mode)
{
  return fseek(f, off, mode);
}


void zb_osif_trace_get_time(zb_uint_t *sec, zb_uint_t *msec, zb_uint_t *usec)
{
  zb_uint64_t total_usec;
  struct timespec time;

  osif_get_clock_monotonic_raw(&time);

#if 0
  *sec = (zb_uint_t)(time.tv_sec - start_t.tv_sec);
  *msec = (zb_uint_t)((time.tv_nsec - start_t.tv_nsec) / 1000000);
  if (*msec > 1000)
  {
    *sec -= 1;
    *msec += 1000;
  }
#else
  total_usec = osif_get_clock_delta_us(&start_t, &time);
  *usec = total_usec % 1000;

  *msec = total_usec / 1000;
  *sec  = *msec / 1000;
  *msec %= 1000;
#endif
}


/**
   Unix-specific trace lock: lock mutex
 */
void zb_osif_trace_lock()
{
#if defined ZB_THREADS
  pthread_mutex_lock(&s_trace_mutex);
#endif /* ZB_THREADS */
}


/**
   Unix-specific trace unlock: unlock mutex
 */
void zb_osif_trace_unlock()
{
#if defined ZB_THREADS
  pthread_mutex_unlock(&s_trace_mutex);
#endif /* ZB_THREADS */
}


void osif_close_all_descriptor()
{
  int max_fd;
  int i;

#if defined (ZB_TRACE_TO_FILE)
  zb_trace_file_flush();
#endif

#if defined(F_MAXFD)
  do
  {
    max_fd = fcntl(0, F_MAXFD);
  } while (max_fd == -1 && errno == EINTR);

  if (max_fd == -1)
  {
    max_fd = sysconf(_SC_OPEN_MAX);
  }
#else
  {
    DIR *dir = NULL;
    struct dirent *ent;
    max_fd = 3;

    dir = opendir("/proc/self/fd");
    if (dir == NULL) {
      dir = opendir("/proc/fd");
    }

    if (dir != NULL)
    {
      while ((ent = readdir(dir)) != NULL)
      {
        if (ent->d_name[0] != '.')
        {
          int number = atoi(ent->d_name);
          if (number > max_fd)
          {
            max_fd = number;
          }
        }
      }
      closedir(dir);
      ++max_fd;
    }
  }
#endif
/* 08/23/2018 EE CR:MAJOR Either use <= here or do ++max_fd not inside ifdef. I prefer <=.  */
  for (i = 3; i < max_fd; ++i)
  {
    close(i);
  }

}

int zb_osif_stream_read(zb_osif_file_t *stream, zb_uint8_t *buf, zb_uint_t len)
{
  return (int)read(fileno(stream), buf, len);
}

int zb_osif_stream_write(zb_osif_file_t *stream, zb_uint8_t *buf, zb_uint_t len)
{
  return (int)write(fileno(stream), buf, len);
}

const zb_char_t* zb_osif_file_get_name_by_path(const zb_char_t *path)
{
  zb_bool_t is_found = ZB_FALSE;
  zb_int_t  i = 0;

  ZB_ASSERT(path);

  for (i = (zb_int_t)strlen(path) - 1; i >= 0; i--)
  {
    if (path[i] == '/')
    {
      is_found = ZB_TRUE;
      break;
    }
  }

  return (is_found) ? &path[i+1] : path;
}
