/* ZBOSS Zigbee software protocol stack
 *
 * Copyright (c) 2020-2020 Nordic Semiconductor ASA
 *
 * All rights reserved.
 *
 * Commercial Usage
 * Licensees holding valid Commercial licenses may use
 * this file in accordance with the Commercial License
 * Agreement provided with the Software or, alternatively, in accordance
 * with the terms contained in a written agreement relevant to the usage of the file.
 */

#define ZB_TRACE_FILE_ID 30028

#include "zb_common.h"
#include "zb_ncp_serial.h"

#if defined(ZB_NCP_TRANSPORT_TYPE_SERIAL) || defined(ZB_NCP_TRANSPORT_TYPE_USERIAL)

/**
 * @brief Obtain a file name for an NCP serial port.
 *
 * Historically, ZBOSS had a lot of ways to define the filename. Now the rule is following:
 * 1) If ZB_NCP_PORT_ENV_NAME defined, use it as a variable name and read a file name from there
 * 2) (Legacy) Try to read a "NCP_SLAVE_PTY" variable, used to set a filename on a host side
 * 3) Use a default file name if defined by ZB_NCP_PORT_DEFAULT_PATH
 * 4) Throw an error
 *
 * @return const char*
 */
ZB_WEAK_PRE const char* ZB_WEAK zb_ncp_uart_path(void)
{
  char* filename = NULL;

#if defined ZB_NCP_PORT_ENV_NAME
  TRACE_MSG(TRACE_MAC2, "Getting a file name from the environment variable %s", (FMT__P, ZB_NCP_PORT_ENV_NAME));
  filename = getenv(ZB_NCP_PORT_ENV_NAME);
#endif /* defined SERIAL_ENV_NAME */

  /* Legacy step, should be removed in future. */
  if (filename == NULL)
  {
    TRACE_MSG(TRACE_MAC2, "Getting a file name from the environment variable NCP_SLAVE_PTY", (FMT__0));
    filename = getenv("NCP_SLAVE_PTY");
  }

#if defined(ZB_NCP_PORT_DEFAULT_PATH)
  if (filename == NULL)
  {
    TRACE_MSG(TRACE_MAC2, "Using a %s file name defined in the MACSPLIT_DEFAULT_PATH", (FMT__P, ZB_NCP_PORT_DEFAULT_PATH));
    filename = ZB_NCP_PORT_DEFAULT_PATH;
  }
#endif

  ZB_VERIFY(filename != NULL, RET_FILE_NOT_FOUND);

  TRACE_MSG(TRACE_MAC2, "NCP serial file name is %s", (FMT__P, filename));
  return filename;
}

#endif /* ZB_NCP_TRANSPORT_TYPE_SERIAL || ZB_NCP_TRANSPORT_TYPE_USERIAL */
