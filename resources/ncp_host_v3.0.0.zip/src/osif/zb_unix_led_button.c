/* ZBOSS Zigbee software protocol stack
 *
 * Copyright (c) 2012-2020 DSR Corporation, Denver CO, USA.
 * www.dsr-zboss.com
 * www.dsr-corporation.com
 * All rights reserved.
 *
 * This is unpublished proprietary source code of DSR Corporation
 * The copyright notice does not evidence any actual or intended
 * publication of such source code.
 *
 * ZBOSS is a registered trademark of Data Storage Research LLC d/b/a DSR
 * Corporation
 *
 * Commercial Usage
 * Licensees holding valid DSR Commercial licenses may use
 * this file in accordance with the DSR Commercial License
 * Agreement provided with the Software or, alternatively, in accordance
 * with the terms contained in a written agreement between you and
 * DSR.
 */
/* PURPOSE: Linux stubs for led/buttons support.
*/

#define ZB_TRACE_FILE_ID 32364
#include "zboss_api_core.h"
#include "zb_led_button.h"

#if 1 /*#ifdef ZB_USE_BUTTONS*/

#ifdef ZB_DEPRECATED_API
/* This function is not used anywhere and seems its objective is not different from
 * 'zb_osif_led_button_init()' which is currently used. It will be removed in a future
 * release. */
void zb_led_init(void)
{
  return;
}
#endif /* ZB_DEPRECATED_API */

void zb_osif_led_button_init(void)
{
  return;
}

void zb_osif_led_on(zb_uint8_t led_no)
{
  ZVUNUSED(led_no);
}

void zb_osif_led_off(zb_uint8_t led_no)
{
  ZVUNUSED(led_no);
}

void zb_led_blink_on(zb_uint8_t led_arg)
{
  ZVUNUSED(led_arg);
}

void zb_led_blink_off(zb_uint8_t led_arg)
{
  ZVUNUSED(led_arg);
}

void zb_osif_button_cb(zb_uint8_t arg)
{
  ZVUNUSED(arg);
}

zb_bool_t zb_osif_button_state(zb_uint8_t arg)
{
  /* Button is always switched off */
  ZVUNUSED(arg);
  return ZB_FALSE;
}

/* FIXME: That function defines in zb_gpmac_scheduler.c and use most probably only in LCGW.
   Need to resolve those dependencies in GP MAC and LCGW in a proper way.
*/
#ifndef ZB_GP_MAC
zb_bool_t zb_setup_buttons_cb(zb_callback_t cb)
{
  ZVUNUSED(cb);
  return ZB_TRUE;
}
#endif /* ZB_GP_MAC */


#endif  /* ZB_USE_BUTTONS */
