/* ZBOSS Zigbee software protocol stack
 *
 * Copyright (c) 2012-2020 DSR Corporation, Denver CO, USA.
 * www.dsr-zboss.com
 * www.dsr-corporation.com
 * All rights reserved.
 *
 * This is unpublished proprietary source code of DSR Corporation
 * The copyright notice does not evidence any actual or intended
 * publication of such source code.
 *
 * ZBOSS is a registered trademark of Data Storage Research LLC d/b/a DSR
 * Corporation
 *
 * Commercial Usage
 * Licensees holding valid DSR Commercial licenses may use
 * this file in accordance with the DSR Commercial License
 * Agreement provided with the Software or, alternatively, in accordance
 * with the terms contained in a written agreement between you and
 * DSR.
 */
/* PURPOSE: diagnostic-related functions
*/

#define ZB_TRACE_FILE_ID 30014
#include "zb_common.h"

#if !defined(ZB_LITE_NO_DIAGNOSTIC) && defined(ZB_OSIF_DIAGNOSTIC_TOOLS)

zb_cli_transport_type_t zb_osif_cli_get_default_transport_type(void)
{
  zb_cli_transport_type_t cli_transport_type = ZB_CLI_TRANSPORT_TYPE_SYNC_SERIAL;

  const char *cli_transport_type_env = NULL;

#ifdef ZB_CLI_TRANSPORT_TYPE_ENV_NAME
  cli_transport_type_env = getenv(ZB_CLI_TRANSPORT_TYPE_ENV_NAME);
#endif

  if (cli_transport_type_env != NULL)
  {
    zb_char_t cli_transport_type_env_value[32];
    strncpy(cli_transport_type_env_value, cli_transport_type_env, ZB_ARRAY_SIZE(cli_transport_type_env_value));

    if (strncmp(cli_transport_type_env_value, "sync_serial", ZB_ARRAY_SIZE(cli_transport_type_env_value)) == 0)
    {
      cli_transport_type = ZB_CLI_TRANSPORT_TYPE_SYNC_SERIAL;
    }
    else if (strncmp(cli_transport_type_env_value, "async_serial", ZB_ARRAY_SIZE(cli_transport_type_env_value)) == 0)
    {
      cli_transport_type = ZB_CLI_TRANSPORT_TYPE_ASYNC_SERIAL;
    }
    else if (strncmp(cli_transport_type_env_value, "stdio", ZB_ARRAY_SIZE(cli_transport_type_env_value)) == 0)
    {
      cli_transport_type = ZB_CLI_TRANSPORT_TYPE_STDIO;
    }
    else
    {
      ZB_ASSERT(ZB_FALSE);
    }
  }
  else
  {
    cli_transport_type = ZB_CLI_TRANSPORT_TYPE_STDIO;
  }

  return cli_transport_type;
}


const char *zb_osif_cli_get_transport_serial_port(void)
{
  static const char* cli_transport_port = "zb_cli.pty";

  const char *cli_transport_port_env = getenv("ZB_CLI_SERIAL_PORT");

  if (cli_transport_port_env != NULL)
  {
    return cli_transport_port_env;
  }
  else
  {
    return cli_transport_port;
  }
}


const zb_uint8_t *zb_osif_cli_format_message(
  const zb_char_t *message,
  zb_size_t message_length,
  zb_size_t *prepared_message_length)
{
  *prepared_message_length = message_length;
  return (const zb_uint8_t*)message;
}

#endif /* !ZB_LITE_NO_DIAGNOSTIC && ZB_OSIF_DIAGNOSTIC_TOOLS */