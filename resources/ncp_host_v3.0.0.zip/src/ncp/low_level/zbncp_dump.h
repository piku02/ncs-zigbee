/* ZBOSS Zigbee software protocol stack
 *
 * Copyright (c) 2012-2021 DSR Corporation, Denver CO, USA.
 * www.dsr-zboss.com
 * www.dsr-corporation.com
 * All rights reserved.
 *
 * This is unpublished proprietary source code of DSR Corporation
 * The copyright notice does not evidence any actual or intended
 * publication of such source code.
 *
 * ZBOSS is a registered trademark of Data Storage Research LLC d/b/a DSR
 * Corporation
 *
 * Commercial Usage
 * Licensees holding valid DSR Commercial licenses may use
 * this file in accordance with the DSR Commercial License
 * Agreement provided with the Software or, alternatively, in accordance
 * with the terms contained in a written agreement between you and
 * DSR.
 */

/*  PURPOSE: NCP traffic dump.
*/

#ifndef ZBNCP_INCLUDE_DUMP_H
#define ZBNCP_INCLUDE_DUMP_H 1

/* If compiling not inside ZBOSS codebase (even reduced), we have no zb_vendor.h */
#ifdef ZBNCP_COMPILE_INSIDE_ZBOSS
#include "zb_vendor.h"

#if defined ZBNCP_USE_ZBOSS_DUMP
/* You need to add ZBNCP_USE_ZBOSS_DUMP
    while compiling to enable NCP dump
*/
#if defined ZB_TRAFFIC_DUMP_ON
#include "zb_common.h"
#include "low_level/zbncp_ll_pkt.h"
void zbncp_traffic_dump(const zbncp_ll_pkt_t *pkt_buff, zb_bool_t is_w);

#define ZB_NCP_INCOMING_TRAFFIC_DUMP(buff) zbncp_traffic_dump((buff), ZBNCP_FALSE)
#define ZB_NCP_OUTGOING_TRAFFIC_DUMP(buff) zbncp_traffic_dump((buff), ZBNCP_TRUE)

#endif /* defined ZB_TRAFFIC_DUMP_ON */

#endif /* ZBNCP_USE_ZBOSS_DUMP */

#endif  /* ZBNCP_COMPILE_INSIDE_ZBOSS */

#ifndef ZB_NCP_INCOMING_TRAFFIC_DUMP
#define ZB_NCP_INCOMING_TRAFFIC_DUMP(buff)
#define ZB_NCP_OUTGOING_TRAFFIC_DUMP(buff)
#endif

#endif /* ZBNCP_INCLUDE_DUMP_H */
