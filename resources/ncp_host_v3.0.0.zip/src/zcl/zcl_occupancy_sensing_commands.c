/* ZBOSS Zigbee software protocol stack
 *
 * Copyright (c) 2012-2020 DSR Corporation, Denver CO, USA.
 * www.dsr-zboss.com
 * www.dsr-corporation.com
 * All rights reserved.
 *
 * This is unpublished proprietary source code of DSR Corporation
 * The copyright notice does not evidence any actual or intended
 * publication of such source code.
 *
 * ZBOSS is a registered trademark of Data Storage Research LLC d/b/a DSR
 * Corporation
 *
 * Commercial Usage
 * Licensees holding valid DSR Commercial licenses may use
 * this file in accordance with the DSR Commercial License
 * Agreement provided with the Software or, alternatively, in accordance
 * with the terms contained in a written agreement between you and
 * DSR.
 */
/* PURPOSE: ZCL Occupancy Sensing cluster specific commands handling
*/

#define ZB_TRACE_FILE_ID 153

#include "zb_common.h"

#if defined (ZB_ZCL_SUPPORT_CLUSTER_OCCUPANCY_SENSING)

#include "zcl/zb_zcl_occupancy_sensing.h"

/** @internal
    @{
*/

zb_ret_t check_value_occupancy_sensing_server(zb_uint16_t attr_id, zb_uint8_t endpoint, zb_uint8_t *value);

void zb_zcl_occupancy_sensing_init_server()
{
    zb_zcl_add_cluster_handlers(ZB_ZCL_CLUSTER_ID_OCCUPANCY_SENSING,
                                ZB_ZCL_CLUSTER_SERVER_ROLE,
                                check_value_occupancy_sensing_server,
                                (zb_zcl_cluster_write_attr_hook_t)NULL,
                                (zb_zcl_cluster_handler_t)NULL);
}

void zb_zcl_occupancy_sensing_init_client()
{
    zb_zcl_add_cluster_handlers(ZB_ZCL_CLUSTER_ID_OCCUPANCY_SENSING,
                                ZB_ZCL_CLUSTER_CLIENT_ROLE,
                                (zb_zcl_cluster_check_value_t)NULL,
                                (zb_zcl_cluster_write_attr_hook_t)NULL,
                                (zb_zcl_cluster_handler_t)NULL);
}

zb_ret_t check_value_occupancy_sensing_server(zb_uint16_t attr_id, zb_uint8_t endpoint, zb_uint8_t *value)
{
    zb_ret_t ret = RET_ERROR;

    zb_uint16_t new_delay;
    zb_uint16_t max_delay;

    zb_uint8_t min_threshold;
    zb_uint8_t max_threshold;

    /* Unused without trace. */
    ZVUNUSED(endpoint);

    TRACE_MSG(TRACE_ZCL1, "> check_value_occupancy_sensing_server attr_id %d, ep %hd, val %hd",
              (FMT__H_H_D, attr_id, endpoint, value));

    if (value)
    {
        if (attr_id == ZB_ZCL_ATTR_OCCUPANCY_SENSING_PIR_OCC_TO_UNOCC_DELAY_ID ||
            attr_id == ZB_ZCL_ATTR_OCCUPANCY_SENSING_PIR_UNOCC_TO_OCC_DELAY_ID ||
            attr_id == ZB_ZCL_ATTR_OCCUPANCY_SENSING_ULTRASONIC_OCCUPIED_TO_UNOCCUPIED_DELAY_ID ||
            attr_id == ZB_ZCL_ATTR_OCCUPANCY_SENSING_ULTRASONIC_UNOCCUPIED_TO_OCCUPIED_DELAY_ID ||
            attr_id == ZB_ZCL_ATTR_OCCUPANCY_SENSING_PHYSICAL_CONTACT_OCCUPIED_TO_UNOCCUPIED_DELAY_ID ||
            attr_id == ZB_ZCL_ATTR_OCCUPANCY_SENSING_PHYSICAL_CONTACT_UNOCCUPIED_TO_OCCUPIED_DELAY_ID)
        {
            max_delay = ZB_ZCL_OCCUPANCY_SENSING_PHYSICAL_CONTACT_OCCUPIED_TO_UNOCCUPIED_DELAY_NO_REPORTING_VALUE;
            switch (attr_id)
            {
                case ZB_ZCL_ATTR_OCCUPANCY_SENSING_PIR_OCC_TO_UNOCC_DELAY_ID:
                {
                    max_delay = ZB_ZCL_OCCUPANCY_SENSING_PIR_OCC_TO_UNOCC_DELAY_MAX_VALUE;
                }break;
                case ZB_ZCL_ATTR_OCCUPANCY_SENSING_PIR_UNOCC_TO_OCC_DELAY_ID:
                {
                    max_delay = ZB_ZCL_OCCUPANCY_SENSING_PIR_UNOCC_TO_OCC_DELAY_MAX_VALUE;
                }break;
                case ZB_ZCL_ATTR_OCCUPANCY_SENSING_ULTRASONIC_OCCUPIED_TO_UNOCCUPIED_DELAY_ID:
                {
                    max_delay = ZB_ZCL_OCCUPANCY_SENSING_ULTRASONIC_OCCUPIED_TO_UNOCCUPIED_DELAY_MAX_VALUE;
                }break;
                case ZB_ZCL_ATTR_OCCUPANCY_SENSING_ULTRASONIC_UNOCCUPIED_TO_OCCUPIED_DELAY_ID:
                {
                    max_delay = ZB_ZCL_OCCUPANCY_SENSING_ULTRASONIC_UNOCCUPIED_TO_OCCUPIED_DELAY_MAX_VALUE;
                }
            }
            new_delay = ZB_ZCL_ATTR_GET16(value);

            if (new_delay > max_delay)
            {
                ret = RET_OUT_OF_RANGE;
            }
            else
            {
                ret = RET_OK;
            }
        }
        else if (attr_id == ZB_ZCL_ATTR_OCCUPANCY_SENSING_PIR_UNOCC_TO_OCC_THRESHOLD_ID ||
                 attr_id == ZB_ZCL_ATTR_OCCUPANCY_SENSING_ULTRASONIC_UNOCCUPIED_TO_OCCUPIED_THRESHOLD_ID ||
                 attr_id == ZB_ZCL_ATTR_OCCUPANCY_SENSING_PHYSICAL_CONTACT_UNOCCUPIED_TO_OCCUPIED_THRESHOLD_ID)
        {
            switch (attr_id)
            {
                case ZB_ZCL_ATTR_OCCUPANCY_SENSING_PIR_UNOCC_TO_OCC_THRESHOLD_ID:
                {
                    min_threshold = ZB_ZCL_OCCUPANCY_SENSING_PIR_UNOCC_TO_OCC_THRESHOLD_MIN_VALUE;
                    max_threshold = ZB_ZCL_OCCUPANCY_SENSING_PIR_UNOCC_TO_OCC_THRESHOLD_MAX_VALUE;
                }break;
                case ZB_ZCL_ATTR_OCCUPANCY_SENSING_ULTRASONIC_UNOCCUPIED_TO_OCCUPIED_THRESHOLD_ID:
                {
                    min_threshold = ZB_ZCL_OCCUPANCY_SENSING_ULTRASONIC_UNOCCUPIED_TO_OCCUPIED_THRESHOLD_MIN_VALUE;
                    max_threshold = ZB_ZCL_OCCUPANCY_SENSING_ULTRASONIC_UNOCCUPIED_TO_OCCUPIED_THRESHOLD_MAX_VALUE;
                }break;
                case ZB_ZCL_ATTR_OCCUPANCY_SENSING_PHYSICAL_CONTACT_UNOCCUPIED_TO_OCCUPIED_THRESHOLD_ID:
                {
                    min_threshold = ZB_ZCL_OCCUPANCY_SENSING_PHYSICAL_CONTACT_UNOCCUPIED_TO_OCCUPIED_THRESHOLD_MIN_VALUE;
                    max_threshold = ZB_ZCL_OCCUPANCY_SENSING_PHYSICAL_CONTACT_UNOCCUPIED_TO_OCCUPIED_THRESHOLD_MAX_VALUE;
                }break;
                default:
                {
                    TRACE_MSG(TRACE_ERROR, "zcl_occ_sens_check_threshold_value: Unsupported attribute ID!", (FMT__0));
                    ZB_ASSERT(0); /*Unsupported attribute*/
                }break;
            }

            if (((*value) < min_threshold) || ((*value) > max_threshold))
            {
                ret = RET_OUT_OF_RANGE;
            }
            else
            {
                ret = RET_OK;
            }
        }
    }
    else
    {
        TRACE_MSG(TRACE_ERROR, "check_value_occupancy_sensing_server: new value pointer is NULL!", (FMT__0));
    }
    TRACE_MSG(TRACE_ZCL1, "< check_value_occupancy_sensing_server ret %hd", (FMT__H, ret));
    return ret;
}

#endif
