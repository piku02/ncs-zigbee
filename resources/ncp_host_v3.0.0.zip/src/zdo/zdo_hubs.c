/* ZBOSS Zigbee software protocol stack
 *
 * Copyright (c) 2012-2020 DSR Corporation, Denver CO, USA.
 * www.dsr-zboss.com
 * www.dsr-corporation.com
 * All rights reserved.
 *
 * This is unpublished proprietary source code of DSR Corporation
 * The copyright notice does not evidence any actual or intended
 * publication of such source code.
 *
 * ZBOSS is a registered trademark of Data Storage Research LLC d/b/a DSR
 * Corporation
 *
 * Commercial Usage
 * Licensees holding valid DSR Commercial licenses may use
 * this file in accordance with the DSR Commercial License
 * Agreement provided with the Software or, alternatively, in accordance
 * with the terms contained in a written agreement between you and
 * DSR.
 */
/* PURPOSE: Routines to support WWAH moved there from ZCL
*/

#define ZB_TRACE_FILE_ID 20100
#include "zb_common.h"
#include "zdo_wwah_stubs.h"

zb_bool_t zb_wwah_in_configuration_mode(void)
{
  return ZB_IS_DEVICE_ZC() || !ZB_U2B(HUBS_CTX().configuration_mode_disabled);
}

void zb_wwah_set_configuration_mode(zb_bool_t allowed)
{
  TRACE_MSG(TRACE_ZDO1, "zb_wwah_set_configuration_mode %d", (FMT__D, allowed));
  HUBS_CTX().configuration_mode_disabled = ZB_B2U(!allowed);
#ifdef ZB_ZCL_ENABLE_WWAH_SERVER
  if (ZB_ZDO_CHECK_IF_WWAH_SERVER_BEHAVIOR())
  {
    /* sync with WWAH cluster */
    (void)zb_zcl_wwah_set_configuration_mode(allowed);
  }
#endif

}

/*
 * Checks ZDO command. See ConfigurationModeEnabled attribute specification.
 * @return ZB_TRUE if ZDO command allowed by WWAH
 * @return ZB_FALSE otherwise
 */
zb_ret_t zb_wwah_check_zdo_command(zb_apsde_data_indication_t *di)
{
  zb_ret_t ret = RET_OK;

  /* if ConfigurationMode is disabled */
  if (!zb_wwah_in_configuration_mode())
  {
#ifdef ZB_ZCL_ENABLE_WWAH_SERVER
    if (ZB_ZDO_CHECK_IF_WWAH_SERVER_BEHAVIOR()) /* WWAH Amazon Part */
    {
      /* if ZDO command have not been encrypted using the Trust Center Link key */
      if (!ZB_B2U(di->aps_key_from_tc))
      {
        /* if ZDO command not in exemption list*/
        if (di->clusterid != ZDO_NWK_ADDR_REQ_CLID && di->clusterid != ZDO_IEEE_ADDR_REQ_CLID &&
            di->clusterid != ZDO_NODE_DESC_REQ_CLID && di->clusterid != ZDO_POWER_DESC_REQ_CLID &&
            di->clusterid != ZDO_SIMPLE_DESC_REQ_CLID && di->clusterid != ZDO_ACTIVE_EP_REQ_CLID &&
            di->clusterid != ZDO_MATCH_DESC_REQ_CLID && di->clusterid != ZDO_COMPLEX_DESC_REQ_CLID &&
            di->clusterid != ZDO_USER_DESC_REQ_CLID && di->clusterid != ZDO_DEVICE_ANNCE_CLID &&
#ifndef R23_DISABLE_DEPRECATED_ZDO_CMDS
            di->clusterid != ZDO_SYSTEM_SERVER_DISCOVERY_REQ_CLID &&
            di->clusterid != ZDO_EXTENDED_SIMPLE_DESC_REQ_CLID &&
            di->clusterid != ZDO_EXTENDED_ACTIVE_EP_REQ_CLID &&
#endif
            di->clusterid != ZDO_MGMT_RTG_REQ_CLID &&
            di->clusterid != ZDO_PARENT_ANNCE_CLID &&
            di->clusterid != ZDO_MGMT_LQI_REQ_CLID &&
            di->clusterid != ZDO_MGMT_NWK_UPDATE_REQ_CLID && di->clusterid != ZDO_MGMT_NWK_ENHANCED_UPDATE_REQ_CLID &&
            di->clusterid != ZDO_MGMT_NWK_IEEE_JOINING_LIST_REQ_CLID && di->clusterid != ZDO_NWK_ADDR_RESP_CLID &&
            di->clusterid != ZDO_IEEE_ADDR_RESP_CLID && di->clusterid != ZDO_NODE_DESC_RESP_CLID &&
            di->clusterid != ZDO_POWER_DESC_RESP_CLID && di->clusterid != ZDO_SIMPLE_DESC_RESP_CLID &&
            di->clusterid != ZDO_ACTIVE_EP_RESP_CLID && di->clusterid != ZDO_MATCH_DESC_RESP_CLID &&
            di->clusterid != ZDO_COMPLEX_DESC_RESP_CLID && di->clusterid != ZDO_USER_DESC_RESP_CLID)
        {
          ret = RET_ERROR;
        }
      }
    }
    else /* R23 part */
#endif   /* #ifdef ZB_ZCL_ENABLE_WWAH_SERVER */
    {
      /* 2782 b. If the sender is the Trust Center AND has APS encryption, the command is not restricted */
      if ((di->src_addr != 0u) || !ZB_U2B(di->aps_key_from_tc))
      {
        /* list of restricted commands */
        if (di->clusterid == ZDO_BIND_REQ_CLID ||
            di->clusterid == ZDO_UNBIND_REQ_CLID ||
            di->clusterid == ZDO_CLEAR_ALL_BIND_REQ_CLID ||
            di->clusterid == ZDO_MGMT_LEAVE_REQ_CLID ||
            di->clusterid == ZDO_MGMT_DIRECT_JOIN_REQ_CLID
           )
        {
          ret = RET_UNAUTHORIZED;
        }
      }
    }
  }

  return ret;
}

zb_bool_t zb_wwah_check_nwk_upd_bcast_allowed(void)
{
#ifdef ZB_ZCL_ENABLE_WWAH_SERVER
  if (ZB_ZDO_CHECK_IF_WWAH_SERVER_BEHAVIOR())
  {
    /*
In WWAH more (requirement C-3) TCSecurityOnNwkKeyRotationEnabled attriute also affects NWK update command.
In r23 broadcasts for NWK update are allowed.
     */
    return !ZB_U2B(HUBS_CTX().require_lk_encryption);
  }
#endif
  return ZB_TRUE;
}

/*
 * Check if Transport Key requires encryption by the unique TCLK
 */
zb_bool_t zb_wwah_check_require_lk_encryption(void)
{
  return ZB_U2B(HUBS_CTX().require_lk_encryption);
}

void zb_wwah_set_require_lk_encryption(zb_bool_t require)
{
  TRACE_MSG(TRACE_ZDO1, "zb_wwah_set_require_lk_encryption %d", (FMT__D, require));
  HUBS_CTX().require_lk_encryption = ZB_B2U(require);
#ifdef ZB_ZCL_ENABLE_WWAH_SERVER
  if (ZB_ZDO_CHECK_IF_WWAH_SERVER_BEHAVIOR())
  {
    zb_zcl_wwah_set_require_lk_encryption(require);
  }
#endif
}

/*
 * Check if leave without rejoin allowed
 * @return ZB_TRUE if leave without rejoin is allowed
 */
zb_bool_t zb_wwah_check_if_leave_without_rejoin_allowed(void)
{
  return !ZB_IS_DEVICE_ZC() && !ZB_U2B(HUBS_CTX().leave_without_rejoin_disallowed);
}


void zb_wwah_set_leave_without_rejoin_allowed(zb_bool_t allowed)
{
  TRACE_MSG(TRACE_ZDO1, "zb_wwah_set_leave_without_rejoin_allowed %d", (FMT__D, allowed));
  HUBS_CTX().leave_without_rejoin_disallowed = ZB_B2U(!allowed);
  ZB_NIB().leave_req_allowed = (zb_uint8_t)ZB_B2U(allowed);
#ifdef ZB_ZCL_ENABLE_WWAH_SERVER
  if (ZB_ZDO_CHECK_IF_WWAH_SERVER_BEHAVIOR())
  {
    /* sync with WWAH cluster */
    (void)zb_zcl_wwah_set_leave_without_rejoin(allowed);
  }
#endif
}


zb_bool_t zb_wwah_check_if_interpan_supported(void)
{
  return ZB_IS_DEVICE_ZC() || !ZB_U2B(HUBS_CTX().interpan_disabled);
}


void zb_wwah_set_interpan_supported(zb_bool_t enabled)
{
  TRACE_MSG(TRACE_ZDO1, "zb_wwah_set_interpan_supported %d", (FMT__D, enabled));
  HUBS_CTX().interpan_disabled = ZB_B2U(!enabled);
}


void zb_wwah_set_pending_channel(zb_uint32_t channel_mask)
{
  TRACE_MSG(TRACE_ZDO1, "zb_wwah_set_pending_channel 0x%x", (FMT__D, channel_mask));
  ZB_NIB().nwk_next_channel_change = channel_mask;
#ifdef ZB_ZCL_ENABLE_WWAH_SERVER
  if (ZB_ZDO_CHECK_IF_WWAH_SERVER_BEHAVIOR())
  {
    /* sync with WWAH cluster */
    (void)zb_zcl_wwah_set_pending_channel(channel_mask);
  }
#endif
}


void zb_wwah_set_pending_panid(zb_uint16_t next_pan_id)
{
  TRACE_MSG(TRACE_ZDO1, "zb_wwah_set_pending_panid 0x%x", (FMT__D, next_pan_id));
  ZB_NIB().nwk_next_pan_id = next_pan_id;
#ifdef ZB_ZCL_ENABLE_WWAH_SERVER
  if (ZB_ZDO_CHECK_IF_WWAH_SERVER_BEHAVIOR())
  {
    /* sync with WWAH cluster */
    (void)zb_zcl_wwah_set_pending_panid(next_pan_id);
  }
#endif
}



#ifdef ZB_CERTIFICATION_HACKS
void zb_wwah_overwrite_hub_connectivity(zb_bool_t overwrite, zb_bool_t val)
{
  TRACE_MSG(TRACE_ZDO1, "zb_wwah_overwrite_hub_connectivity overwrite %d val %d", (FMT__D_D, overwrite, val));
  ZB_CERT_HACKS().hub_connectivity = ZB_B2U(val);
  ZB_CERT_HACKS().overwrite_hub_connectivity = ZB_B2U(overwrite);
}
#endif

