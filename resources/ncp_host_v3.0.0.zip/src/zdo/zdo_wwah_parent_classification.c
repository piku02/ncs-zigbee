/* ZBOSS Zigbee software protocol stack
 *
 * Copyright (c) 2012-2020 DSR Corporation, Denver CO, USA.
 * www.dsr-zboss.com
 * www.dsr-corporation.com
 * All rights reserved.
 *
 * This is unpublished proprietary source code of DSR Corporation
 * The copyright notice does not evidence any actual or intended
 * publication of such source code.
 *
 * ZBOSS is a registered trademark of Data Storage Research LLC d/b/a DSR
 * Corporation
 *
 * Commercial Usage
 * Licensees holding valid DSR Commercial licenses may use
 * this file in accordance with the DSR Commercial License
 * Agreement provided with the Software or, alternatively, in accordance
 * with the terms contained in a written agreement between you and
 * DSR.
 */
/* PURPOSE: WWAH Parent classification routines
*/

#define ZB_TRACE_FILE_ID 12086

#include "zb_common.h"
#include "zb_mac.h"
#include "zb_nwk.h"
#include "zcl/zb_zcl_wwah.h"
#include "zdo_wwah_parent_classification.h"
#include "zdo_common.h"


zb_zcl_wwah_parent_priority_t zdo_wwah_get_parent_priority_by_classification_mask(zb_uint16_t mask)
{
  zb_zcl_wwah_parent_priority_t priority;

  TRACE_MSG(
    TRACE_ZDO2,
    ">>zdo_wwah_get_parent_priority_by_classification_mask, mask 0x%hx",
    (FMT__H, mask));

  switch (mask & ZB_ZCL_WWAH_TC_CONNECTIVITY_AND_LONG_UPTIME_MASK)
  {
    case ZB_ZCL_WWAH_NO_TC_CONNECTIVITY_AND_SHORT_UPTIME_MASK:
      priority = ZB_ZCL_WWAH_PARENT_PRIORITY_VERY_LOW;
      break;

    case ZB_ZCL_WWAH_NO_TC_CONNECTIVITY_AND_LONG_UPTIME_MASK:
      priority = ZB_ZCL_WWAH_PARENT_PRIORITY_LOW;
      break;

    case ZB_ZCL_WWAH_TC_CONNECTIVITY_AND_SHORT_UPTIME_MASK:
      priority = ZB_ZCL_WWAH_PARENT_PRIORITY_HIGH;
      break;

    case ZB_ZCL_WWAH_TC_CONNECTIVITY_AND_LONG_UPTIME_MASK:
      priority = ZB_ZCL_WWAH_PARENT_PRIORITY_VERY_HIGH;
      break;

    default:
      priority = ZB_ZCL_WWAH_PARENT_PRIORITY_INVALID;
      break;
  }

  TRACE_MSG(
    TRACE_ZDO2,
    "<<zdo_wwah_get_parent_priority_by_classification_mask, priority %d",
    (FMT__D, priority));

  return priority;
}



void zdo_wwah_parent_classification_set(zb_bool_t enable)
{
  HUBS_CTX().parent_classification_enabled = ZB_B2U(enable);
}

static zb_bool_t zdo_wwah_parent_classification_is_enabled(void)
{
  return ZB_U2B(HUBS_CTX().parent_classification_enabled);
}

zb_bool_t zdo_wwah_compare_neighbors(
  zb_ext_neighbor_tbl_ent_t *nbte_first, zb_ext_neighbor_tbl_ent_t *nbte_second)
{
  zb_bool_t res;

  TRACE_MSG(TRACE_ZDO1, ">> zdo_wwah_compare_neighbors", (FMT__0));

  ZB_ASSERT(nbte_first);
  ZB_ASSERT(nbte_second);

  TRACE_MSG(TRACE_ZDO1, "first_rssi %hd, second_rssi %hd", (FMT__H_H, nbte_first->rssi, nbte_second->rssi));

  if (zdo_wwah_parent_classification_is_enabled())
  {
    zb_uint8_t first_rssi_group = ZB_B2U(ZDO_WWAH_GET_LINK_QUALITY_GROUP_BY_RSSI(nbte_first->rssi));
    zb_uint8_t second_rssi_group = ZB_B2U(ZDO_WWAH_GET_LINK_QUALITY_GROUP_BY_RSSI(nbte_second->rssi));
    zb_zcl_wwah_parent_priority_t first_parent_priority =
      zdo_wwah_get_parent_priority_by_classification_mask(nbte_first->classification_mask);
    zb_zcl_wwah_parent_priority_t second_parent_priority =
      zdo_wwah_get_parent_priority_by_classification_mask(nbte_second->classification_mask);

    TRACE_MSG(TRACE_ZDO1, "first_parent_priority %hd, second_parent_priority %hd",
              (FMT__H_H, first_parent_priority, second_parent_priority));

    if (first_rssi_group == second_rssi_group)
    {
      TRACE_MSG(TRACE_ZDO1, "RSSI groups are the same, choose by Parent Priority", (FMT__0));
      if (first_parent_priority == second_parent_priority)
      {
        TRACE_MSG(TRACE_ZDO1, "Parents Priorities are the same, choose by RSSI", (FMT__0));
        res = (zb_bool_t)(nbte_first->rssi > nbte_second->rssi);
      }
      else
      {
        TRACE_MSG(TRACE_ZDO1, "Parents Priorities are different, choose the best", (FMT__0));
        res = (zb_bool_t)(first_parent_priority > second_parent_priority);
      }
    }
    else
    {
      TRACE_MSG(TRACE_ZDO1, "RSSI groups are different, choose parent from the Good group", (FMT__0));
      res = (zb_bool_t)(first_rssi_group > second_rssi_group);
    }
  }
  else
  {
    TRACE_MSG(TRACE_ZDO1, "WWAH Parent Classification is disabled! Use only LQI to find the best", (FMT__0));
    res = (zb_bool_t)(nbte_first->lqi > nbte_second->lqi);
  }

  TRACE_MSG(TRACE_ZDO1, "first is better - %hd", (FMT__H, res));
  TRACE_MSG(TRACE_ZDO1, "<< zdo_wwah_compare_neighbors", (FMT__0));

  return res;
}

/* Return ZB_TRUE if nbte_first is preferred parent */
zb_bool_t zdo_nwk_compare_neighbors(zb_ext_neighbor_tbl_ent_t *nbte_first, zb_ext_neighbor_tbl_ent_t *nbte_second, zb_uint8_t parent_preference)
{
  TRACE_MSG(TRACE_ZDO1, "zdo_nwk_compare_neighbors, first 0x%x, second 0x%x", (FMT__D_D, nbte_first->short_addr, nbte_second->short_addr));

#if (defined ZB_ZCL_SUPPORT_CLUSTER_WWAH && defined ZB_ZCL_ENABLE_WWAH_SERVER)
  if (ZB_ZDO_CHECK_IF_WWAH_SERVER_BEHAVIOR())
  {
    return zdo_wwah_compare_neighbors(nbte_first, nbte_second);
  }
#endif

  /* 3.6.1.5.2 Parent Selection (R23) */
  /* 1. A parent that indicates Hub Connectivity is 1 SHALL be preferred over a parent with Hub Connectivity of 0 */
  if (ZB_TLV_ROUTER_INFO_BIT_IS_SET(nbte_first->classification_mask, ZB_TLV_ROUTER_INFORMATION_HUB_CONNECTIVITY) !=
      ZB_TLV_ROUTER_INFO_BIT_IS_SET(nbte_second->classification_mask, ZB_TLV_ROUTER_INFORMATION_HUB_CONNECTIVITY))
  {
    TRACE_MSG(TRACE_ZDO1, "parent selection: hub connectivity, ret %hd", (FMT__H,
        ZB_TLV_ROUTER_INFO_BIT_IS_SET(nbte_first->classification_mask, ZB_TLV_ROUTER_INFORMATION_HUB_CONNECTIVITY)));
    return ZB_TLV_ROUTER_INFO_BIT_IS_SET(nbte_first->classification_mask, ZB_TLV_ROUTER_INFORMATION_HUB_CONNECTIVITY);
  }

  /* 2. A parent that indicates a Preferred Parent of 1 SHALL be preferred to a parent with a Preferred Parent of 0 */
  if ( ZB_TLV_ROUTER_INFO_BIT_IS_SET(nbte_first->classification_mask, ZB_TLV_ROUTER_INFORMATION_PREFERRED_PARENT) !=
       ZB_TLV_ROUTER_INFO_BIT_IS_SET(nbte_second->classification_mask, ZB_TLV_ROUTER_INFORMATION_PREFERRED_PARENT))
  {
    TRACE_MSG(TRACE_ZDO1, "parent selection: preferred parent, ret %hd", (FMT__H,
        ZB_TLV_ROUTER_INFO_BIT_IS_SET(nbte_first->classification_mask, ZB_TLV_ROUTER_INFORMATION_PREFERRED_PARENT)));
    return ZB_TLV_ROUTER_INFO_BIT_IS_SET(nbte_first->classification_mask, ZB_TLV_ROUTER_INFORMATION_PREFERRED_PARENT);
  }

#if 0
  /* 3. A good Parent signal SHALL be preferred over a marginal parent signal. */
  {
    zb_uint8_t first_lqa = zb_nwk_calculate_raw_lqa(nbte_first->lqi, nbte_first->rssi);
    zb_uint8_t second_lqa = zb_nwk_calculate_raw_lqa(nbte_second->lqi, nbte_second->rssi);

    if (ZB_LQA_IS_GOOD(first_lqa) != ZB_LQA_IS_GOOD(second_lqa))
    {
      TRACE_MSG(TRACE_ZDO1, "parent selection: good lqa, ret %hd", (FMT__H, ZB_LQA_IS_GOOD(first_lqa)));
      return (zb_bool_t) ZB_LQA_IS_GOOD(first_lqa);
    }
  }
#endif

  /* 4. If the device is rejoining, is an End Device, and the parent is the current parent for the device. */
  if (ZB_IS_DEVICE_ZED() && ZG->zdo.handle.rejoin)
  {
    if (nbte_first->short_addr == ZG->zdo.handle.rejoin_ctx.prev_parent)
    {
      TRACE_MSG(TRACE_ZDO1, "parent selection: prev parent, ret 1", (FMT__0));
      return ZB_TRUE;
    }

    if (nbte_second->short_addr == ZG->zdo.handle.rejoin_ctx.prev_parent)
    {
      TRACE_MSG(TRACE_ZDO1, "parent selection: prev parent, ret 0", (FMT__0));
      return ZB_FALSE;
    }
  }

  /* 5. A parent that indicates Long Uptime over a device that indicates Short Uptime */
  if ( ZB_TLV_ROUTER_INFO_BIT_IS_SET(nbte_first->classification_mask, ZB_TLV_ROUTER_INFORMATION_UPTIME) !=
       ZB_TLV_ROUTER_INFO_BIT_IS_SET(nbte_second->classification_mask, ZB_TLV_ROUTER_INFORMATION_UPTIME))
  {
    TRACE_MSG(TRACE_ZDO1, "parent selection: uptime, ret %hd", (FMT__H,
        ZB_TLV_ROUTER_INFO_BIT_IS_SET(nbte_first->classification_mask, ZB_TLV_ROUTER_INFORMATION_UPTIME)));
    return ZB_TLV_ROUTER_INFO_BIT_IS_SET(nbte_first->classification_mask, ZB_TLV_ROUTER_INFORMATION_UPTIME);
  }

  /* 6. A parent that has the newest NWK Update ID value, considering wrap for an 8-bit value */
  if (nbte_first->update_id != nbte_second->update_id)
  {
    TRACE_MSG(TRACE_ZDO1, "parent selection: update id, ret %hd", (FMT__H,
        ZB_NWK_UPDATE_ID1_GE_ID2(nbte_first->update_id, nbte_second->update_id)));
    return ZB_NWK_UPDATE_ID1_GE_ID2(nbte_first->update_id, nbte_second->update_id);
  }

  /* 7. A parent that has preferred feature support as indicated by the application via the ParentPreference in the NLME-JOIN.request */
  if (ZB_U2B(parent_preference & (zb_uint8_t)(1u << ZB_PARENT_PREFERENCE_KEY_NEGOTIATION_SUPPORT_BIT)))
  {
    if ( nbte_first->support_kn_methods_tlv_found !=
         nbte_second-> support_kn_methods_tlv_found)
    {
      TRACE_MSG(TRACE_ZDO1, "parent selection: support kn methods tlv, ret %hd", (FMT__H,
          nbte_first->support_kn_methods_tlv_found));
      return (zb_bool_t) nbte_first->support_kn_methods_tlv_found;
    }
  }

  /* 8. Other manufacturer specific feature support that is desired. */
  return ZB_TRUE;
}

