/* ZBOSS Zigbee software protocol stack
 *
 * Copyright (c) 2012-2020 DSR Corporation, Denver CO, USA.
 * www.dsr-zboss.com
 * www.dsr-corporation.com
 * All rights reserved.
 *
 * This is unpublished proprietary source code of DSR Corporation
 * The copyright notice does not evidence any actual or intended
 * publication of such source code.
 *
 * ZBOSS is a registered trademark of Data Storage Research LLC d/b/a DSR
 * Corporation
 *
 * Commercial Usage
 * Licensees holding valid DSR Commercial licenses may use
 * this file in accordance with the DSR Commercial License
 * Agreement provided with the Software or, alternatively, in accordance
 * with the terms contained in a written agreement between you and
 * DSR.
 */

/* PURPOSE: ZDO commands TLV routines
*/

#define ZB_TRACE_FILE_ID 109

#include "zb_common.h"
#include "zb_tlv.h"
#include "zdo_hubs.h"

#if defined ZB_JOIN_CLIENT

void zb_zdo_st_key_neg_req_put_tlv(zb_uint8_t param)
{
  zb_tlv_put_value_start_key_neg_req_rsp_public_point(param,
                                                      ZB_PIBCACHE_EXTENDED_ADDRESS(),
                                                      ZB_ZDO_JOINER_KEY_NEGOTIATION_CTX().public_key_point_i);
}

void zb_zdo_get_auth_tok_req_put_tlv(zb_uint8_t param)
{
  zb_tlv_put_value_authentication_token(param);
}

zb_ret_t zb_zdo_start_k_neg_r_proc_tlv(zb_uint8_t *tlv_ptr,
                                       zb_uint8_t tlv_data_len,
                                       zb_ieee_addr_t tc_ieee)
{
  zb_ret_t ret;

  TRACE_MSG(TRACE_ZDO2, ">> zb_zdo_start_key_negotiation_rsp_process_tlv tlv_data_len %hd",
            (FMT__H, tlv_data_len));

  ret = zb_tlv_general_tlv_processing(tlv_ptr, tlv_data_len);

  /* Public point TLV processing */
  if (ret == RET_OK)
  {
    ret = zb_tlv_parse_value_start_key_neg_req_rsp_public_point(tlv_ptr,
                                                                tlv_data_len,
                                                                tc_ieee,
                                                                ZB_ZDO_JOINER_KEY_NEGOTIATION_CTX().public_key_point_r);
  }

  if (ret == RET_OK)
  {
    if (!ZB_IEEE_ADDR_CMP(ZB_AIB().trust_center_address, tc_ieee))
    {
      /* Treat as malformed if ieee in the TLV is not equal TC ieee */
      TRACE_MSG(TRACE_ERROR, "zb_zdo_start_key_negotiation_rsp_process_tlv: tlv is malformed", (FMT__0));
      ret = RET_ERROR;
    }
  }
  else
  {
    ret = RET_ERROR;
  }

  TRACE_MSG(TRACE_ZDO2, "<< zb_zdo_start_key_negotiation_rsp_process_tlv, ret %d", (FMT__D, ret));

  return ret;
}


zb_ret_t zb_zdo_get_auth_tkn_rsp_proc_tlv(zb_uint8_t *tlv_ptr,
                                        zb_uint8_t tlv_data_len,
                                        zb_uint8_t *passphrase)
{
  zb_ret_t ret;
  TRACE_MSG(TRACE_ZDO2, ">> zb_zdo_get_authentication_token_rsp_process_tlv tlv_data_len %hd",
            (FMT__H, tlv_data_len));

  /* 128-bit Symmetric Passphrase TLV processing */
  ret = zb_tlv_general_tlv_processing(tlv_ptr, tlv_data_len);

  if (ret == RET_OK)
  {
    ret = zb_tlv_parse_value_symmetric_passphrase(tlv_ptr, tlv_data_len, passphrase);
  }

  TRACE_MSG(TRACE_ZDO2, "<< zb_zdo_get_authentication_token_rsp_process_tlv, ret %d", (FMT__D, ret));

  return ret;
}

#endif /* ZB_JOIN_CLIENT */

#if defined ZB_COORDINATOR_ROLE || defined ZB_ROUTER_ROLE

void zb_zdo_st_key_neg_rsp_put_tlv(zb_uint8_t param,
                                   zb_uint8_t *public_point)
{
  ZB_ASSERT(public_point);

  zb_tlv_put_value_start_key_neg_req_rsp_public_point(param,
                                                      ZB_PIBCACHE_EXTENDED_ADDRESS(),
                                                      public_point);
}

void zb_zdo_get_auth_tok_rsp_put_tlv(zb_uint8_t param, zb_uint8_t *passphrase)
{
  ZB_ASSERT(passphrase);

  zb_tlv_put_value_symmetric_passphrase(param, passphrase);
}


zb_secur_ecdhe_common_ctx_t* zb_zdo_start_key_negotiation_req_process_parse_tlv(const zb_uint8_t* tlv_ptr,
                                                                                zb_uint8_t tlv_data_len,
                                                                                zb_uint8_t* status,
                                                                                zb_bool_t is_dlk)
{
  zb_ret_t ret_code;
  zb_ieee_addr_t ieee_addr;
  zb_address_ieee_ref_t ref_ieee = 0;
  zb_secur_ecdhe_common_ctx_t* key_neg_ctx_ptr;
  zb_uint8_t key_neg_method;
  zb_uint8_t selected_secret;
  zb_uint8_t curve_id;
  zb_uint8_t pub_key[ZB_ECC_PUB_KEY_MAX_LEN];
  zb_uint8_t nwk_key_seq_num = 0;

  TRACE_MSG(TRACE_SECUR1, ">> zb_zdo_start_key_negotiation_req_process_parse_tlv: tlv_addr 0x%x, tlv_size %hd, is_dlk %hd",
      (FMT__H_H_H, tlv_ptr, tlv_data_len, is_dlk));

  *status = ZB_APS_STATUS_SUCCESS;

  /* Parse key negotiation method */
  if (is_dlk)
  {
    /* DLK already passed key update req stage to that moment, and has key neg method in context */
    curve_id = ZB_ECC_CURVE_25519;
  }
  else
  {
    ret_code = zb_tlv_direct_parse_value_selected_key_neg_method(tlv_ptr, tlv_data_len, &key_neg_method, &selected_secret);
    if ((ret_code != RET_OK) ||
        (!is_dlk && (key_neg_method <= ZB_TLV_DIRECT_KEY_ECDHE_RESERVED_MIN)) ||
        /*cstat !MISRAC2012-Rule-14.3_b*/
        /** @mdr{00015,11} */
        (key_neg_method >= (is_dlk ? ZB_TLV_KEY_ECDHE_RESERVED_MAX : ZB_TLV_DIRECT_KEY_ECDHE_RESERVED_MAX)))
    {
        TRACE_MSG(TRACE_APP1, "zb_zdo_start_key_negotiation_req_process_parese_tlv: Invalid selected key negotiation method, exit", (FMT__0));
        *status = ZB_APS_STATUS_SECURITY_FAIL;
        return NULL;
    }
    else
    {
      curve_id = zb_secur_curve_id_get_by_key_neg_method(key_neg_method);
    }
  }

  /* Parse initiator's ieee address and public key point */
  ret_code = zb_tlv_parse_value_start_key_neg_req_rsp_public_point_common(
      tlv_ptr,
      tlv_data_len,
      ieee_addr,
      pub_key,
      curve_id,
      is_dlk);

  if (ret_code != RET_OK)
  {
      TRACE_MSG(TRACE_APP1, "zb_zdo_start_key_negotiation_req_process_parse_tlv: Couldn't parse key neg req TLV, exit", (FMT__0));
      *status = ZB_NWK_STATUS_MISSING_TLV;
      return NULL;
  }

  /* For Zigbee Direct parse Network Key Sequence number TLV as well */
  if (!is_dlk)
  {
    (void) zb_tlv_direct_parse_value_start_key_neg_req_rsp_nwk_key_seq_num(
      tlv_ptr,
      tlv_data_len,
      &nwk_key_seq_num);

    if (nwk_key_seq_num >= ZB_SECUR_N_SECUR_MATERIAL)
    {
      TRACE_MSG(TRACE_APP1,
                "zb_zdo_start_key_negotiation_req_process_parse_tlv: Nwk Key Seq Num too big (%hd), exit",
                (FMT__H, nwk_key_seq_num));
      return NULL;
    }
  }

  if (zb_address_by_ieee(ieee_addr,
              ZB_TRUE,
              ZB_FALSE,
              &ref_ieee) != RET_OK)
  {
      TRACE_MSG(TRACE_APP1, "zb_zdo_start_key_negotiation_req_process_parse_tlv: Couldn't register peer's IEEE address, exit", (FMT__0));
      *status = ZB_ZDP_STATUS_TABLE_FULL;
      return NULL;
  }

  /* Create key negotiation context and start to fill it */
  key_neg_ctx_ptr = zb_zdo_ecdhe_common_ctx_get_by_ref(ref_ieee);

  if (key_neg_ctx_ptr == NULL)
  {
    key_neg_ctx_ptr = zb_zdo_ecdhe_common_ctx_alloc_by_ref(ref_ieee);
  }

  if (key_neg_ctx_ptr == NULL)
  {
      TRACE_MSG(TRACE_APP1, "zb_zdo_start_key_negotiation_req_process_parse_tlv: Can't allocate key negotiation common context, exit", (FMT__0));
      *status = ZB_ZDP_STATUS_TABLE_FULL;
      return NULL;
  }

  if (!is_dlk)
  {
    /* DLK does already have these values by that moment */
    key_neg_ctx_ptr->selected_key_neg_method = key_neg_method;
    key_neg_ctx_ptr->selected_psk_secret = selected_secret;
    key_neg_ctx_ptr->nwk_key_seq_num = nwk_key_seq_num;
  }
  ZB_MEMCPY(key_neg_ctx_ptr->public_key_point_i, pub_key, ZB_DLK_PUB_KEY_LEN(curve_id));
  key_neg_ctx_ptr->nwk_key_seq_num = nwk_key_seq_num;

  TRACE_MSG(TRACE_SECUR1, "<< zb_zdo_start_key_negotiation_req_process_parse_tlv",
      (FMT__0));

  return key_neg_ctx_ptr;
}

zb_ret_t zb_zdo_get_authentication_token_req_process_tlv(zb_uint8_t *tlv_ptr,
                                                         zb_uint8_t tlv_data_len)
{
  zb_ret_t ret = RET_OK;
  zb_uint8_t auth_token_id;

  /* Requested Authentication Token ID TLV processing */
  zb_ret_t is_tlv_processed = zb_tlv_general_tlv_processing(tlv_ptr, tlv_data_len);
  zb_ret_t is_tlv_parsed = zb_tlv_parse_value_authentication_token(tlv_ptr, tlv_data_len, &auth_token_id);

  TRACE_MSG(TRACE_ZDO2, ">> zb_zdo_get_authentication_token_req_process_tlv tlv_data_len %hd",
            (FMT__H, tlv_data_len));
  TRACE_MSG(TRACE_ZDO2, "is_tlv_processed 0x%lx, is_tlv_parsed 0x%lx", (FMT__L_L, is_tlv_processed, is_tlv_parsed));

  if (is_tlv_processed != RET_OK || is_tlv_parsed != RET_OK)
  {
    TRACE_MSG(TRACE_ERROR, "zb_zdo_get_authentication_token_req_process_tlv: tlv is malformed", (FMT__0));
    ret = RET_ERROR;
  }

  if (ret == RET_OK &&
      auth_token_id != ZB_TLV_SUPPORTED_AUTHENTICATION_TOKEN)
  {
    /* The only supported authentication token in this specification is 0x45, 128-bit Symmetric
     * Passphrase TLV. */
    ret = RET_NO_MATCH;
  }

  TRACE_MSG(TRACE_ZDO2, "<< zb_zdo_get_authentication_token_req_process_tlv, ret %d", (FMT__D, ret));

  return ret;
}

#endif /* ZB_COORDINATOR_ROLE || ZB_ROUTER_ROLE */

void zb_zdo_key_neg_methods_put_tlv(zb_uint8_t param)
{
  zb_uint8_t supported_key_methods = zb_get_supported_key_neg_method();
  zb_uint8_t supported_secrets = zb_get_supported_psk_secrets();

  zb_tlv_put_value_supported_key_neg_methods(param,
                                             ZB_PIBCACHE_EXTENDED_ADDRESS(),
                                             &supported_key_methods,
                                             &supported_secrets);

  zb_tlv_put_value_fragmentation_parameters(param,
                                            ZB_PIBCACHE_NETWORK_ADDRESS(),
                                            ZB_ZDO_NODE_DESC()->max_incoming_transfer_size);
}

void zb_zdo_upd_key_req_put_tlvs(zb_uint8_t param, zb_uint8_t selected_method, zb_uint8_t selected_secret)
{
  TRACE_MSG(TRACE_ZDO2, "+zb_zdo_upd_key_req_put_tlvs, param", (FMT__H, param));

  zb_tlv_put_value_selected_key_neg_method(param,
                                           ZB_PIBCACHE_EXTENDED_ADDRESS(),
                                           &selected_method,
                                           &selected_secret);

#if defined ZB_CERTIFICATION_HACKS
  if (!ZB_CERT_HACKS().tlv_disable_frag_param_tlv)
#endif /* ZB_CERTIFICATION_HACKS  */
  {
    zb_tlv_put_value_fragmentation_parameters(param,
                                              ZB_PIBCACHE_NETWORK_ADDRESS(),
                                              ZB_ZDO_NODE_DESC()->max_incoming_transfer_size);
  }

  TRACE_MSG(TRACE_ZDO2, "-zb_zdo_upd_key_req_put_tlvs, param", (FMT__H, param));
}

zb_ret_t zb_zdo_upd_key_req_process_tlv(zb_uint8_t *tlv_ptr,
                                        zb_uint8_t tlv_data_len,
                                        zb_uint16_t src_short_addr)
{
  zb_ret_t ret;

  TRACE_MSG(TRACE_ZDO2, ">> zb_zdo_upd_key_req_process_tlv tlv_data_len %hd, src_short_addr 0x%x",
            (FMT__H_D, tlv_data_len, src_short_addr));

  ret = zb_tlv_general_tlv_processing(tlv_ptr, tlv_data_len);

  /* It's Trust Center. Update address and methods. */
  if (ret == RET_OK && src_short_addr == 0x0000U)
  {
    ret = zb_tlv_parse_value_selected_key_neg_method(
            tlv_ptr,
            tlv_data_len,
            ZB_AIB().trust_center_address,
            &ZB_ZDO_JOINER_KEY_NEGOTIATION_CTX().selected_key_neg_method,
            &ZB_ZDO_JOINER_KEY_NEGOTIATION_CTX().selected_psk_secret);

    if (ret == RET_OK)
    {
      zb_address_ieee_ref_t ref;
      ret = zb_address_update(ZB_AIB().trust_center_address, 0x0000, ZB_FALSE, &ref);

      if (ZB_IS_DEVICE_ZR() && ZB_NIB().beacon_apx_tlv_size > 0u)
      {
        /* Update IEEE addr for support kn tlv in beacon apx */
        zb_tlv_hdr_t *tlv_hdr_ptr = zb_tlv_get_tlv_ptr(ZB_TLV_SUPPORTED_KEY_NEGOTIATION_METHODS, ZB_NIB().beacon_apx_tlv, ZB_NIB().beacon_apx_tlv_size);
        if (tlv_hdr_ptr != NULL)
        {
          zb_uint8_t *ieee_addr_ptr = &ZB_TLV_GET_BODY_PTR(tlv_hdr_ptr)[sizeof(zb_uint8_t) + sizeof(zb_uint8_t)];
          ZB_HTOLE64(ieee_addr_ptr, ZB_AIB().trust_center_address);
        }
      }
    }
  }

  if (ret == RET_OK)
  {
    zb_uint16_t short_addr;
    zb_uint16_t max_incoming_transfer_size;
    zb_uint8_t  fragmentation_options;

    ret = zb_tlv_parse_value_fragmentation_parameters(tlv_ptr,
                                                      tlv_data_len,
                                                      &short_addr,
                                                      &fragmentation_options,
                                                      &max_incoming_transfer_size);

    if (ret == RET_OK &&
        short_addr == src_short_addr)
    {
      TRACE_MSG(TRACE_NWK2, "zb_zdo_upd_key_req_process_tlv: short addr = 0x%x, incoming transfer size = %d",
                (FMT__D_D, short_addr, max_incoming_transfer_size));

#ifdef APS_FRAGMENTATION
      {
        zb_uint8_t max_buffer_size = zb_aps_get_max_buffer_size(short_addr);

        if (max_buffer_size == ZB_APS_INVALID_MAX_TRANS_SIZE)
        {
          max_buffer_size = ZB_ASDU_MAX_LEN; /* == 96 , this value is workaround. The problem is that we have no max_buf_size here */
        }
        zb_aps_add_max_trans_size(short_addr, max_incoming_transfer_size, max_buffer_size);
      }
#endif /* APS_FRAGMENTATION */
    }
    else
    {
      /* TLV parsing is failed or frame from TC but address into TLV is not 0x0000.
         Treat this as malformed TLV. */

      TRACE_MSG(TRACE_ERROR, "Parse Fragmentation Global TLV failed. This isn't critical for us now, skip and continue",
                (FMT__0));

      ret = RET_OK;
    }
  }

  TRACE_MSG(TRACE_ZDO2, "<< zb_zdo_upd_key_req_process_tlv, ret %d", (FMT__D, ret));

  return ret;
}

zb_ret_t zb_zdo_key_neg_methods_and_frag_param_process_tlv(zb_uint8_t *tlv_ptr,
                                                           zb_uint8_t tlv_data_len,
                                                           zb_uint8_t src_short_addr)
{
  zb_ret_t ret;

  TRACE_MSG(TRACE_ZDO2, ">> zb_zdo_key_neg_methods_and_frag_param_process_tlv tlv_data_len %hd, src_short_addr 0x%x",
            (FMT__H_D, tlv_data_len, src_short_addr));

  ret = zb_tlv_general_tlv_processing(tlv_ptr, tlv_data_len);

  /* It's Trust Center. Update address and methods. */
  if (ret == RET_OK && src_short_addr == 0x0000U)
  {
    ret = zb_tlv_parse_value_supported_key_neg_methods(tlv_ptr,
                                                       tlv_data_len,
                                                       ZB_AIB().trust_center_address,
                                                       &(ZB_AIB().trust_center_supported_key_negotiation_methods),
                                                       &(ZB_AIB().trust_center_supported_preshared_secrets));

    TRACE_MSG(TRACE_ZDO2, "zb_zdo_key_neg_methods_and_frag_param_process_tlv: ieee_addr " TRACE_FORMAT_64,
              (FMT__A, TRACE_ARG_64(ZB_AIB().trust_center_address)));

    TRACE_MSG(TRACE_ZDO2, "zb_zdo_key_neg_methods_and_frag_param_process_tlv: supported_key_negotiation_methods 0x%x",
              (FMT__D, ZB_AIB().trust_center_supported_key_negotiation_methods));

    if (ret == RET_OK)
    {
      zb_address_ieee_ref_t ref;
      ret = zb_address_update(ZB_AIB().trust_center_address, 0x0000, ZB_FALSE, &ref);
    }
  }

  if (ret == RET_OK)
  {
    zb_uint16_t short_addr;
    zb_uint16_t max_incoming_transfer_size;
    zb_uint8_t  fragmentation_options;

    ret = zb_tlv_parse_value_fragmentation_parameters(tlv_ptr,
                                                      tlv_data_len,
                                                      &short_addr,
                                                      &fragmentation_options,
                                                      &max_incoming_transfer_size);

    if (ret == RET_OK
          && short_addr == src_short_addr
          && ZB_U2B(fragmentation_options & (1U << ZB_TLV_FRAGMENTATION_OPT_APS_FRAG_SUPPORT)))
    {
      TRACE_MSG(TRACE_NWK2, "zb_zdo_key_neg_methods_and_frag_param_process_tlv: short addr = 0x%x, incoming transfer size = %d",
                (FMT__D_D, short_addr, max_incoming_transfer_size));

#ifdef APS_FRAGMENTATION
      {
        zb_uint8_t max_buffer_size = zb_aps_get_max_buffer_size(short_addr);

        if (max_buffer_size == ZB_APS_INVALID_MAX_TRANS_SIZE)
        {
          max_buffer_size = ZB_ASDU_MAX_LEN; /* == 96 , this value is workaround. The problem is that we have no max_buf_size here */
        }
        zb_aps_add_max_trans_size(short_addr, max_incoming_transfer_size, max_buffer_size);
      }
#endif /* APS_FRAGMENTATION */
    }
    else
    {
      /* TLV parsing is failed or frame from TC but address into TLV is not 0x0000.
         Treat this as malformed TLV. */

      TRACE_MSG(TRACE_ZDO2, "Parse Fragmentation Global TLV failed or fragmentation not supported. Skip and continue",
                (FMT__0));

      ret = RET_OK;
    }
  }

  TRACE_MSG(TRACE_ZDO2, "<< zb_zdo_key_neg_methods_and_frag_param_process_tlv, ret %d", (FMT__D, ret));

  return ret;
}

void zb_zdo_encapsulation_put_tlv(zb_uint8_t param,
                                  zb_secur_ecdhe_common_ctx_t *ecdhe_ctx)
{
  zb_uint8_t enc_tlv_len = 0;

  if (ecdhe_ctx == NULL)
  {
    zb_uint8_t supported_key_methods = zb_get_supported_key_neg_method();
    zb_uint8_t supported_secrets = zb_get_supported_psk_secrets();
    zb_tlv_hdr_t *enc_tlv_hdr = (zb_tlv_hdr_t *) zb_buf_alloc_right(param, sizeof(zb_tlv_hdr_t));

    enc_tlv_len += (zb_uint8_t)(sizeof(zb_tlv_hdr_t)) + zb_tlv_get_size(ZB_TLV_SUPPORTED_KEY_NEGOTIATION_METHODS);
    enc_tlv_len += (zb_uint8_t)(sizeof(zb_tlv_hdr_t)) + zb_tlv_get_size(ZB_TLV_FRAGMENTATION_PARAMETERS);

    enc_tlv_hdr->tlv_id = zb_tlv_get_id(ZB_TLV_BEACON_APPENDIX_ENCAPSULATION);
    enc_tlv_hdr->length = enc_tlv_len - 1U;

    zb_tlv_put_value_supported_key_neg_methods(param,
                                               ZB_PIBCACHE_EXTENDED_ADDRESS(),
                                               &supported_key_methods,
                                               &supported_secrets);

    zb_tlv_put_value_fragmentation_parameters(param,
                                              ZB_PIBCACHE_NETWORK_ADDRESS(),
                                              ZB_ZDO_NODE_DESC()->max_incoming_transfer_size);
  }
  else
  {
    /* Calculate Joiner_encapsulation_tlv_len */
    if (ZB_U2B(ecdhe_ctx->supported_key_neg_method_tlv_found))
    {
      enc_tlv_len += (zb_uint8_t)(sizeof(zb_tlv_hdr_t)) + zb_tlv_get_size(ZB_TLV_SUPPORTED_KEY_NEGOTIATION_METHODS);
    }

    if (ZB_U2B(ecdhe_ctx->fragmentation_tlv_found))
    {
      enc_tlv_len += (zb_uint8_t)(sizeof(zb_tlv_hdr_t)) + zb_tlv_get_size(ZB_TLV_FRAGMENTATION_PARAMETERS);
    }

    if (ZB_U2B(ecdhe_ctx->device_capability_extension_tlv_found))
    {
      enc_tlv_len += (zb_uint8_t)(sizeof(zb_tlv_hdr_t)) + zb_tlv_get_size(ZB_TLV_DEVICE_CAPABILITY_EXTENSION);
    }

    /* Put */
    if (ZB_U2B(enc_tlv_len))
    {
      zb_tlv_hdr_t *enc_tlv_hdr = (zb_tlv_hdr_t *) zb_buf_alloc_right(param, sizeof(zb_tlv_hdr_t));

      enc_tlv_hdr->tlv_id = zb_tlv_get_id(ZB_TLV_JOINER_ENCAPSULATION);
      enc_tlv_hdr->length = enc_tlv_len - 1U;

      if (ZB_U2B(ecdhe_ctx->supported_key_neg_method_tlv_found))
      {
        zb_ieee_addr_t ieee_addr;

        zb_address_ieee_by_ref(ieee_addr, ecdhe_ctx->ref);
        zb_tlv_put_value_supported_key_neg_methods(param,
                                                   ieee_addr,
                                                   &ecdhe_ctx->supported_key_neg_method_tlv_value,
                                                   &ecdhe_ctx->supported_secrets_tlv_value);
      }

      if (ZB_U2B(ecdhe_ctx->fragmentation_tlv_found))
      {
        zb_uint16_t short_addr;
        zb_address_short_by_ref(&short_addr, ecdhe_ctx->ref);
        zb_tlv_put_value_fragmentation_parameters(param,
                                                  short_addr,
                                                  ecdhe_ctx->fragmentation_tlv_value);
      }

#ifdef ZB_DIRECT_ENABLED
      if (ZB_U2B(ecdhe_ctx->device_capability_extension_tlv_found))
      {
        zb_tlv_put_value_device_capability_extension(
          param,
          ecdhe_ctx->device_capability_extension_tlv_value);
      }
#endif /* ZB_DIRECT_ENABLED */
    }
  }
}

void zb_zdo_encapsulation_process_tlv(zb_uint8_t *tlv_ptr,
                                      zb_uint8_t tlv_data_len,
                                      zb_secur_ecdhe_common_ctx_t *ecdhe_ctx)
{
  zb_tlv_hdr_t *enc_tlv_hdr;

  TRACE_MSG(TRACE_COMMON1, ">> zb_zdo_encapsulation_process_tlv, tlv_data_len %hd", (FMT__H, tlv_data_len));

  if (ecdhe_ctx != NULL)
  {
    enc_tlv_hdr = zb_tlv_get_tlv_ptr(ZB_TLV_JOINER_ENCAPSULATION, tlv_ptr, tlv_data_len);

    if (enc_tlv_hdr != NULL)
    {
      zb_uint8_t *tlv_val_p = ZB_TLV_GET_BODY_PTR(enc_tlv_hdr);
      zb_uint8_t tlv_len = enc_tlv_hdr->length + 1U;
      zb_ieee_addr_t ieee_addr;
      zb_uint16_t short_addr;
      zb_uint8_t fragmentation_options;

      if (zb_tlv_parse_value_supported_key_neg_methods(tlv_val_p,
                                                       tlv_len,
                                                       ieee_addr,
                                                       &ecdhe_ctx->supported_key_neg_method_tlv_value,
                                                       &ecdhe_ctx->supported_secrets_tlv_value) == RET_OK)
      {
        if (zb_zdo_ecdhe_common_ctx_get_by_ieee(ieee_addr) == ecdhe_ctx)
        {
          ecdhe_ctx->supported_key_neg_method_tlv_found = 1;
        }
        else
        {
          TRACE_MSG(TRACE_ERROR, "zb_zdo_ecdhe_common_ctx_get_by_ieee(ieee_addr) != ecdhe_ctx (supported_key_neg_methods)", (FMT__0));
        }
      }

      if (zb_tlv_parse_value_fragmentation_parameters(tlv_val_p,
                                                      tlv_len,
                                                      &short_addr,
                                                      &fragmentation_options,
                                                      &ecdhe_ctx->fragmentation_tlv_value) == RET_OK)
      {
        if (zb_zdo_ecdhe_common_ctx_get_by_short(short_addr) == ecdhe_ctx)
        {
          ecdhe_ctx->fragmentation_tlv_found = 1;
        }
        else
        {
          TRACE_MSG(TRACE_ERROR, "zb_zdo_ecdhe_common_ctx_get_by_ieee(ieee_addr) != ecdhe_ctx (fragmentation)", (FMT__0));
        }
      }

#ifdef ZB_DIRECT_ENABLED
      if (zb_tlv_parse_value_device_capability_extension_parameters(
        tlv_val_p,
        tlv_len,
        &ecdhe_ctx->device_capability_extension_tlv_value) == RET_OK)
      {
        ecdhe_ctx->device_capability_extension_tlv_found = ZB_TRUE;
      }
#endif /* ZB_DIRECT_ENABLED */
    }
    else
    {
      TRACE_MSG(TRACE_ERROR, "zb_zdo_encapsulation_process_tlv: Joiner Encapsulation TLV not found", (FMT__0));
    }
  }
  else
  {
    enc_tlv_hdr = zb_tlv_get_tlv_ptr(ZB_TLV_BEACON_APPENDIX_ENCAPSULATION, tlv_ptr, tlv_data_len);

    if (enc_tlv_hdr != NULL)
    {
      zb_uint8_t *tlv_val_p = (zb_uint8_t *) (enc_tlv_hdr + 1);
      zb_uint8_t tlv_len = enc_tlv_hdr->length + 1U; /* actual length is TLV length + 1 */

      /* Called only for frames from zc. Not necessary to double check the address. */
      zb_ret_t ret = zb_zdo_key_neg_methods_and_frag_param_process_tlv(tlv_val_p, tlv_len, 0x0000U);

      if (ret == RET_OK)
      {
        TRACE_MSG(TRACE_ZDO2, "zb_zdo_encapsulation_process_tlv: update nwkGlobalBeaconPayloadTLVs",
                  (FMT__0));

        /*
         * If the TLV Update is set to 1 and the Beacon Appendix Encapsulation TLV is also present
         * the receiver SHALL store all Global TLVs from the TLV Data in the nwkGlobalBeaconPayloadTLVs
         * of the NIB.
         */
        ZB_NIB().beacon_apx_tlv_size = tlv_len;
        ZB_MEMCPY(ZB_NIB().beacon_apx_tlv, tlv_val_p, ZB_NIB().beacon_apx_tlv_size);
      }
      else if (ret == RET_NOT_FOUND)
      {
        TRACE_MSG(TRACE_ZDO2, "zb_zdo_encapsulation_process_tlv: clear nwkGlobalBeaconPayloadTLVs",
                  (FMT__0));

        /*
         * If the TLV Update is set to 1 and the Global Beacon Appendix Encapsulation TLV Data is not
         * present, the receiver SHALL clear the contents of the nwkGlobalBeaconPayloadTLVs loadTLVs
         * of the NIB.
         *
         * Not clear what to do in case of distributed network.
         */

        ZB_NIB().beacon_apx_tlv_size = 0;
        ZB_MEMSET(ZB_NIB().beacon_apx_tlv, 0, ZB_MAX_BEACON_APPENDIX_TLV_SIZE);
      }
      else
      {
        TRACE_MSG(TRACE_ERROR, "zb_zdo_encapsulation_process_tlv: Beacon appendix encapsulation TLVs are incorrect", (FMT__0));
      }
    }
  }

  TRACE_MSG(TRACE_ZDO2, "<< zb_zdo_encapsulation_process_tlv", (FMT__0));
}

void zb_zdo_set_configuration_req_process_tlv(zb_uint8_t *tlv_ptr,
                                              zb_uint8_t tlv_data_len,
                                              zb_zdo_processing_status_tlv_ctx_t *tlv_statuses)
{
  zb_uint16_t conf_mode_bitmask;
  zb_uint16_t next_pan_id;
  zb_uint32_t channel_mask;

  TRACE_MSG(TRACE_SECUR2, ">> zb_zdo_set_configuration_req_tlv_process", (FMT__0));

  /*
   * 4937 A device that is not the Trust Center SHALL process only the following TLVs, all other TLVs SHALL be ignored:
   * 4938 Configuration Parameters Global TLV
   * 4939 Next Channel Change Global TLV
   * 4940 Next PAN ID Global TLV
   */

  /* ZB_TLV_CONFIGURATION_MODE_PARAMETERS */
  if (RET_OK == zb_tlv_parse_value_conf_mode_param(tlv_ptr, tlv_data_len, &conf_mode_bitmask))
  {
    tlv_statuses->conf_mode_param_tlv_status = ZB_ZDP_STATUS_SUCCESS;

    TRACE_MSG(TRACE_SECUR2, "Configuration Mode TLV bitmask: 0x%x", (FMT__D, conf_mode_bitmask));

    zb_wwah_set_configuration_mode(!ZB_U2B(ZB_SECUR_GET_CONF_MODE(conf_mode_bitmask)));
    zb_wwah_set_require_lk_encryption(ZB_U2B(ZB_SECUR_GET_LINK_KEY_ENC(conf_mode_bitmask)));
    zb_wwah_set_leave_without_rejoin_allowed(ZB_U2B(ZB_SECUR_GET_LEAVE_REQ_ALLOWED(conf_mode_bitmask)));
  }

  /* ZB_TLV_NEXT_CANNEL_CHANGE */
  if (RET_OK == zb_tlv_parse_value_next_channel_change(tlv_ptr, tlv_data_len, &channel_mask))
  {
    tlv_statuses->next_channel_change_tlv_status = ZB_ZDP_STATUS_SUCCESS;
    zb_wwah_set_pending_channel(channel_mask);
  }

  /* ZB_TLV_NEXT_PAN_ID */
  if (RET_OK == zb_tlv_parse_value_next_pan_id(tlv_ptr, tlv_data_len, &next_pan_id))
  {
    tlv_statuses->next_pan_id_tlv_status = ZB_ZDP_STATUS_SUCCESS;
    zb_wwah_set_pending_panid(next_pan_id);
  }

  TRACE_MSG(TRACE_SECUR2, "<< zb_zdo_set_configuration_req_tlv_process", (FMT__0));
}

void zb_zdo_put_processing_status_tlv(zb_uint8_t param, zb_zdo_processing_status_tlv_ctx_t *tlv_statuses)
{
  zb_uint8_t tlv_status_cnt = (ZB_B2U(tlv_statuses->conf_mode_param_tlv_status != ZB_NWK_STATUS_MISSING_TLV)
                               + ZB_B2U(tlv_statuses->next_channel_change_tlv_status != ZB_NWK_STATUS_MISSING_TLV)
                               + ZB_B2U(tlv_statuses->next_pan_id_tlv_status != ZB_NWK_STATUS_MISSING_TLV));

  if (tlv_status_cnt != 0u)
  {
    zb_ret_t ret = RET_ERROR;
    zb_uint8_t *ptr;
    zb_tlv_hdr_t *tlv_hdr;

    /* Put TLV HDR */
    tlv_hdr = (zb_tlv_hdr_t *)zb_buf_alloc_right(param, sizeof(zb_tlv_hdr_t));
    tlv_hdr->tlv_id = zb_tlv_get_id(ZB_TLV_PROCESSING_STATUS);
    tlv_hdr->length = 2U * tlv_status_cnt;

    /* Put tlv status count and processing statuses */
    ptr = zb_buf_alloc_right(param, sizeof(zb_uint8_t));
    if (ptr != NULL)
    {
      ret = RET_OK;
      *ptr = tlv_status_cnt;
    }

    if (ret == RET_OK && tlv_statuses->conf_mode_param_tlv_status != ZB_NWK_STATUS_MISSING_TLV)
    {
      ret = zb_tlv_status_append(param, ZB_TLV_CONFIGURATION_MODE_PARAMETERS, tlv_statuses->conf_mode_param_tlv_status);
    }

    if (ret == RET_OK && tlv_statuses->next_channel_change_tlv_status != ZB_NWK_STATUS_MISSING_TLV)
    {
      ret = zb_tlv_status_append(param, ZB_TLV_NEXT_CANNEL_CHANGE, tlv_statuses->next_channel_change_tlv_status);
    }

    if (ret == RET_OK && tlv_statuses->next_pan_id_tlv_status != ZB_NWK_STATUS_MISSING_TLV)
    {
      (void)zb_tlv_status_append(param, ZB_TLV_NEXT_PAN_ID, tlv_statuses->next_pan_id_tlv_status);
    }
  }
}

static zb_ret_t zb_zdo_process_eui64_array(zb_tlv_hdr_t *tlv_hdr,
                                           zb_tlv_eui64_array_t *tlv_param)
{
  zb_ret_t ret = RET_ERROR;
  zb_uint8_t tlv_data_len;
  zb_uint8_t *tlv_val_ptr;

  ZB_ASSERT(tlv_hdr != NULL);
  ZB_ASSERT(tlv_param != NULL);

  tlv_data_len = tlv_hdr->length + 1U;
  tlv_val_ptr = (zb_uint8_t *)tlv_hdr + sizeof(zb_tlv_hdr_t);

  if (tlv_data_len > 0U)
  {
    tlv_param->eui64_cnt = *tlv_val_ptr;

    if ((sizeof(zb_ieee_addr_t) * tlv_param->eui64_cnt) == (tlv_data_len - sizeof(zb_uint8_t)))
    {
      zb_uint_t i;
      zb_uint8_t offset = (zb_uint8_t)sizeof(zb_uint8_t);

      if (tlv_param->eui64_cnt <= ZB_TLV_EUI64_ARRAY_MAX_CNT)
      {
        for (i = 0U; i < tlv_param->eui64_cnt; i++)
        {
          ZB_IEEE_ADDR_COPY(tlv_param->eui64_arr[i], tlv_val_ptr + offset);
          offset += (zb_uint8_t)sizeof(zb_ieee_addr_t);
        }

        ret = RET_OK;
      }
      else
      {
        TRACE_MSG(TRACE_ERROR, "zb_zdo_clear_all_bind_process_tlv: eui64_cnt > ZB_TLV_EUI64_ARRAY_MAX_CNT", (FMT__0));
      }
    }
  }

  return ret;
}


/* This function uses for Decommission TLV too */
zb_ret_t zb_zdo_clear_all_bind_put_tlv(zb_uint8_t param)
{
  zb_zdo_clear_all_bind_req_param_t req_param = *ZB_BUF_GET_PARAM(param, zb_zdo_clear_all_bind_req_param_t);
  zb_ret_t ret = RET_ERROR;

  if (req_param.eui64_count <= ZB_ZDO_CLEAR_ALL_BIND_EUI64_LIST_SIZE)
  {
    zb_uint8_t *ptr;
    zb_tlv_hdr_t *tlv_hdr;
    zb_uint_t i;

    /* Put TLV HDR */
    tlv_hdr = (zb_tlv_hdr_t *)zb_buf_alloc_right(param, sizeof(zb_tlv_hdr_t));
    tlv_hdr->tlv_id = zb_tlv_get_id(ZB_TLV_CLEAR_ALL_BIND_REQ_EUI64);
    tlv_hdr->length = 1u /*eui64_cnt*/ + 8u * req_param.eui64_count - 1u /* tlv_len = actual len - 1 */;

    ptr = zb_buf_alloc_right(param, 1u);
    *ptr = req_param.eui64_count;

    for (i = 0; i < req_param.eui64_count; i++)
    {
      ptr = zb_buf_alloc_right(param, 8u);
      ZB_IEEE_ADDR_COPY(ptr, req_param.eui64_list[i]);
    }

    ret = RET_OK;
  }

  return ret;
}


zb_ret_t zb_zdo_clear_all_bind_process_tlv(zb_uint8_t *tlv_ptr,
                                           zb_uint8_t tlv_data_len,
                                           zb_tlv_clear_all_bind_req_eui64_t *tlv_param)
{
  zb_ret_t ret = RET_ERROR;
  zb_tlv_hdr_t *tlv_hdr_ptr;

  if (tlv_ptr != NULL
      && tlv_param != NULL)
  {
    /*
    * ZB_TLV_CLEAR_ALL_BIND_REQ_EUI64
    *
    */
    tlv_hdr_ptr = zb_tlv_get_tlv_ptr(ZB_TLV_CLEAR_ALL_BIND_REQ_EUI64, tlv_ptr, tlv_data_len);
    if (tlv_hdr_ptr != NULL)
    {
      ret = zb_zdo_process_eui64_array(tlv_hdr_ptr, tlv_param);
    }
  }

  return ret;
}


zb_ret_t zb_zdo_decommission_process_tlv(zb_uint8_t *tlv_ptr,
                                         zb_uint8_t tlv_data_len,
                                         zb_tlv_decommission_req_eui64_t *tlv_param)
{
  zb_ret_t ret = RET_ERROR;
  zb_tlv_hdr_t *tlv_hdr_ptr;

  if (tlv_ptr != NULL
      && tlv_param != NULL)
  {
    /*
     * ZB_TLV_SECUR_DECOMMISSION_REQ_EUI64
     *
     */
    tlv_hdr_ptr = zb_tlv_get_tlv_ptr(ZB_TLV_SECUR_DECOMMISSION_REQ_EUI64, tlv_ptr, tlv_data_len);
    if (tlv_hdr_ptr != NULL)
    {
      ret = zb_zdo_process_eui64_array(tlv_hdr_ptr, tlv_param);
    }
  }
  return ret;
}

zb_ret_t zb_zdo_put_tlv_by_id(zb_uint8_t param, zb_uint8_t id)
{
  zb_ret_t ret = RET_OK;
  zb_tlv_tag_t tag;

  tag = zb_tlv_get_tag(ZB_TLV_TAG_GLOBAL_MIN, id);

  if (tag != ZB_TLV_NOT_FOUND)
  {
    switch (tag)
    {
      case ZB_TLV_SUPPORTED_KEY_NEGOTIATION_METHODS:
        zb_zdo_key_neg_methods_put_tlv(param);
        break;

      case ZB_TLV_PANID_CONFLICT_REPORT:
        zb_tlv_put_panid_conflict_report(param);
        break;

      case ZB_TLV_NEXT_PAN_ID:
        zb_tlv_put_value_next_pan_id(param, &ZB_NIB().nwk_next_pan_id);
        break;

      case ZB_TLV_NEXT_CANNEL_CHANGE:
        zb_tlv_put_value_next_channel_change(param, &ZB_NIB().nwk_next_channel_change);
        break;


      case ZB_TLV_FRAGMENTATION_PARAMETERS:
        zb_tlv_put_value_fragmentation_parameters(param,
                                                  ZB_PIBCACHE_NETWORK_ADDRESS(),
                                                  ZB_ZDO_NODE_DESC()->max_incoming_transfer_size);
        break;

      case ZB_TLV_CONFIGURATION_MODE_PARAMETERS:
      {
        zb_uint16_t bitmask = 0u;

        if (!zb_wwah_in_configuration_mode())
        {
          ZB_SECUR_SET_CONF_MODE(bitmask);
        }

        if (zb_wwah_check_require_lk_encryption())
        {
          ZB_SECUR_SET_LINK_KEY_ENC(bitmask);
        }

        if (ZB_U2B(ZB_NIB().leave_req_allowed))
        {
          ZB_SECUR_SET_LEAVE_REQ_ALLOWED(bitmask);
        }

        zb_tlv_put_value_conf_mode_param(param,  &bitmask);
        break;
      }


#if defined ZB_ROUTER_ROLE
      case ZB_TLV_ROUTER_INFORMATION:
        zb_tlv_put_value_router_information(param);
        break;
#endif
      case ZB_TLV_BEACON_APPENDIX_ENCAPSULATION:
      case ZB_TLV_POTENTIAL_PARENTS:
      case ZB_TLV_JOINER_ENCAPSULATION:
      case ZB_TLV_SYMMETRIC_PASSPHRASE:
      case ZB_TLV_MANUFACTURER_SPECIFIC:
          /* FALLTHROUGH */
      default:
        ret = RET_IGNORE;
        break;
    }
  }
  else
  {
    ret = RET_IGNORE;
  }

  return ret;
}


void zb_zdo_beacon_survey_resp_put_tlv(zb_uint8_t param, zb_zdo_beacon_survey_resp_params_t *resp_params)
{
  zb_uint8_t parents_cnt;
  zb_uint16_t buf_len;
  zb_uint8_t tlv_size;
  zb_bool_t is_zc_or_zr = ZB_IS_DEVICE_ZC_OR_ZR();

  /* put results tlv */
  zb_zdo_beacon_survey_put_results_tlv(param,
      resp_params->results.total_beacons_surveyed,
      resp_params->results.num_cur_nwk_beacons,
      resp_params->results.num_potential_parents_current_zbn,
      resp_params->results.num_other_nwk_beacons
  );

  /* put potential parents tlv */
  parents_cnt = (resp_params->parents.count_potential_parents >= ZB_BEACON_SURVEY_POTENTIAL_PARENTS_TLV_MAX_PARENTS) ?
    ZB_BEACON_SURVEY_POTENTIAL_PARENTS_TLV_MAX_PARENTS :
    resp_params->parents.count_potential_parents;
  buf_len = (zb_uint16_t)zb_buf_len(param);
  tlv_size = zb_tlv_get_size(ZB_TLV_PANID_CONFLICT_REPORT);

  zb_tlv_put_potential_parents(param,
                               resp_params->parents.current_parent,
                               parents_cnt,
                               resp_params->parents.parent_list);

  /* Do we have enough space in the packet? */
  if ((sizeof(zb_tlv_hdr_t) + buf_len + tlv_size) <= ZB_APS_MAX_PAYLOAD_SIZE
      && is_zc_or_zr)
  {
    /* Put panid conflict report, but do not reset panid conflict counters. */
    zb_tlv_put_panid_conflict_report(param);
  }
}


void zb_zdo_challenge_req_put_tlv (zb_uint8_t param, zb_uint8_t *rand)
{
  zb_uint8_t *ptr;
  ptr = zb_tlv_put_next(param, ZB_TLV_APS_FRAME_CNT_CHALLENGE_REQ);

  ZB_ASSERT(ptr != NULL);

  /* place sender ieee */
  ZB_IEEE_ADDR_COPY(ptr, ZB_PIBCACHE_EXTENDED_ADDRESS());
  ptr += 8;

  /* place rand value */
  ZB_MEMCPY(ptr, rand, ZB_APS_CHALLENGE_VAL_SIZE);
  ptr += ZB_APS_CHALLENGE_VAL_SIZE;

  /* init hmac by zero */
  ZB_BZERO(ptr, ZB_CCM_KEY_SIZE);
}

zb_ret_t zb_zdo_challenge_req_process_tlv(zb_uint8_t *tlv_ptr, zb_uint8_t tlv_data_len,
                                              zb_uint8_t *sender_ieee, zb_uint8_t *rand_value)
{
  zb_ret_t ret = RET_ERROR;

  if (tlv_ptr != NULL
      && sender_ieee != NULL
      && rand_value != NULL)
  {
    zb_tlv_hdr_t *tlv_hdr_ptr;
    tlv_hdr_ptr = zb_tlv_get_tlv_ptr(ZB_TLV_APS_FRAME_CNT_CHALLENGE_REQ, tlv_ptr, tlv_data_len);
    if (tlv_hdr_ptr != NULL)
    {
      zb_uint8_t *body_ptr = ZB_TLV_GET_BODY_PTR(tlv_hdr_ptr);

      ZB_IEEE_ADDR_COPY(sender_ieee, body_ptr);
      body_ptr += 8;

      ZB_MEMCPY(rand_value, body_ptr, ZB_APS_CHALLENGE_VAL_SIZE);

      ret = RET_OK;
    }
  }
  return ret;
}

zb_uint8_t *zb_zdo_challenge_rsp_put_tlv (zb_uint8_t param, zb_uint8_t *rand, zb_uint32_t out_cnt, zb_uint32_t challenge_cnt)
{
  zb_uint8_t *ptr;
  ptr = zb_tlv_put_next(param, ZB_TLV_APS_FRAME_CNT_CHALLENGE_RSP);

  ZB_ASSERT(ptr != NULL);

  /* place sender ieee */
  ZB_IEEE_ADDR_COPY(ptr, ZB_PIBCACHE_EXTENDED_ADDRESS());
  ptr += 8;

  /* place challenge value */
  ZB_MEMCPY(ptr, rand, ZB_APS_CHALLENGE_VAL_SIZE);
  ptr += ZB_APS_CHALLENGE_VAL_SIZE;

  /* place outgoing counter */
  ZB_HTOLE32(ptr, &out_cnt);
  ptr += 4;

  /* place challenge counter */
  ZB_HTOLE32(ptr, &challenge_cnt);
  ptr += 4;

  /* init mic64 by zero */
  ZB_BZERO(ptr, ZB_ZDO_CHALLENGE_RSP_MIC_SIZE);

  return ptr;
}

zb_ret_t zb_zdo_challenge_resp_process_tlv(zb_uint8_t *tlv_ptr, zb_uint8_t tlv_data_len,
                                              zb_uint8_t *sender_ieee, zb_uint8_t *rand_value,
                                              zb_uint32_t *out_counter, zb_uint32_t *challenge_counter, zb_uint8_t *mic)
{
  zb_ret_t ret = RET_ERROR;

  if (tlv_ptr != NULL
      && sender_ieee != NULL
      && rand_value != NULL
      && out_counter != NULL
      && challenge_counter != NULL
      && mic != NULL)
  {
    zb_tlv_hdr_t *tlv_hdr_ptr;

    tlv_hdr_ptr = zb_tlv_get_tlv_ptr(ZB_TLV_APS_FRAME_CNT_CHALLENGE_RSP, tlv_ptr, tlv_data_len);
    if (tlv_hdr_ptr != NULL)
    {
      zb_uint8_t *body_ptr = ZB_TLV_GET_BODY_PTR(tlv_hdr_ptr);

      ZB_IEEE_ADDR_COPY(sender_ieee, body_ptr);
      body_ptr += 8;

      ZB_MEMCPY(rand_value, body_ptr, ZB_APS_CHALLENGE_VAL_SIZE);
      body_ptr += ZB_APS_CHALLENGE_VAL_SIZE;

      ZB_LETOH32(out_counter, body_ptr);
      body_ptr += 4;

      ZB_LETOH32(challenge_counter, body_ptr);
      body_ptr += 4;

      ZB_MEMCPY(mic, body_ptr, ZB_ZDO_CHALLENGE_RSP_MIC_SIZE);

      ret = RET_OK;
    }
  }
  return ret;
}

void zb_zdo_get_auth_level_req_put_target_ieee_tlv(zb_uint8_t param, zb_uint8_t *target_ieee)
{
  zb_uint8_t *ptr;
  ptr = zb_tlv_put_next(param, ZB_TLV_TARGET_IEEE_ADDR);

  ZB_IEEE_ADDR_COPY(ptr, target_ieee);
}

zb_ret_t zb_zdo_get_auth_level_req_process_target_ieee_tlv(zb_uint8_t *tlv_ptr, zb_uint8_t tlv_data_len, zb_uint8_t *target_ieee)
{
  zb_ret_t ret = RET_ERROR;

  if (tlv_ptr != NULL
      && target_ieee != NULL)
  {
    zb_tlv_hdr_t *tlv_hdr_ptr;
    tlv_hdr_ptr = zb_tlv_get_tlv_ptr(ZB_TLV_TARGET_IEEE_ADDR, tlv_ptr, tlv_data_len);
    if (tlv_hdr_ptr != NULL)
    {
      zb_uint8_t *body_ptr = ZB_TLV_GET_BODY_PTR(tlv_hdr_ptr);

      ZB_IEEE_ADDR_COPY(target_ieee, body_ptr);
      ret = RET_OK;
    }
  }
  return ret;
}

zb_ret_t zb_zdo_get_auth_level_rsp_process_dev_auth_lvl_tlv(zb_uint8_t *tlv_ptr, zb_uint8_t tlv_data_len,
            zb_uint8_t *target_ieee, zb_uint8_t *initial_join_auth, zb_uint8_t *active_lk_type)
{
  zb_ret_t ret = RET_ERROR;

  if (tlv_ptr != NULL
      && target_ieee != NULL
      && initial_join_auth != NULL
      && active_lk_type != NULL)
  {
    zb_tlv_hdr_t *tlv_hdr_ptr;
    tlv_hdr_ptr = zb_tlv_get_tlv_ptr(ZB_TLV_DEVICE_AUTH_LEVEL, tlv_ptr, tlv_data_len);
    if (tlv_hdr_ptr != NULL)
    {
      zb_uint8_t *body_ptr = ZB_TLV_GET_BODY_PTR(tlv_hdr_ptr);

      ZB_IEEE_ADDR_COPY(target_ieee, body_ptr);
      body_ptr += 8;

      *initial_join_auth = *body_ptr;
      body_ptr += 1;

      *active_lk_type = *body_ptr;
      ret = RET_OK;
    }
  }

  return ret;
}

void zb_zdo_get_auth_level_rsp_put_dev_auth_lvl_tlv(zb_uint8_t param, zb_uint8_t *target_ieee, zb_uint8_t initial_join_auth, zb_uint8_t active_lk_type)
{
  zb_uint8_t *ptr;
  ptr = zb_tlv_put_next(param, ZB_TLV_DEVICE_AUTH_LEVEL);

  ZB_IEEE_ADDR_COPY(ptr, target_ieee);
  ptr += 8;

  *ptr = initial_join_auth;
  ptr += 1;

  *ptr = active_lk_type;
}

void zb_zdo_construct_relay_tlv(zb_uint8_t param, zb_uint8_t *joiner_ieee)
{
  zb_tlv_hdr_t *tlv_hdr_ptr;
  zb_uint8_t tlv_len;

  ZB_MEMCPY(zb_buf_alloc_left(param, sizeof(zb_ieee_addr_t)), joiner_ieee, sizeof(zb_ieee_addr_t));
  tlv_len = (zb_uint8_t)zb_buf_len(param) - 1U;

  tlv_hdr_ptr = (zb_tlv_hdr_t *) zb_buf_alloc_left(param, sizeof(zb_tlv_hdr_t));
  tlv_hdr_ptr->length = tlv_len;
  tlv_hdr_ptr->tlv_id = zb_tlv_get_id(ZB_TLV_RELAY_MESSAGE);
}

void zb_zdo_cut_all_except_relay_msg_tlv(zb_uint8_t param)
{
  zb_uint8_t *tlv_start = zb_buf_begin(param);
  zb_uint8_t *buf_end = (zb_uint8_t*)zb_buf_end(param);
  zb_uint8_t tlvs_len = (zb_uint8_t)zb_buf_len(param);
  zb_tlv_hdr_t *relay_tlv_hdr;
  zb_uint_t tunneled_frame_len;

  /*
   *                 Relay Message TLV
   *   [  2             8                      X      ]
   *   [Header   Src/dst_(joiner ieee)  Tunneled_frame]
   */

  relay_tlv_hdr = zb_tlv_get_tlv_ptr (ZB_TLV_RELAY_MESSAGE, tlv_start, tlvs_len);
  ZB_ASSERT(relay_tlv_hdr != NULL);

  tunneled_frame_len = relay_tlv_hdr->length - sizeof(zb_ieee_addr_t) + 1U;

  /* It is a false-positive case. relay_tlv_hdr and tlv_start point to the same buffer in fact. */
  /*cstat !MISRAC2012-Rule-18.3*/
  ZB_ASSERT((zb_uint8_t*)relay_tlv_hdr >= tlv_start && (zb_uint8_t*)relay_tlv_hdr < buf_end);
  /*cstat !MISRAC2012-Rule-18.2*/
  (void)zb_buf_cut_left(param, (zb_uint_t)((zb_uint8_t *)relay_tlv_hdr - (zb_uint8_t *)tlv_start));
  (void)zb_buf_cut_right(param, zb_buf_len(param) - (sizeof(zb_tlv_hdr_t) + sizeof(zb_ieee_addr_t) + tunneled_frame_len));
}


void zb_zdo_get_tunneled_frame_from_relay(zb_uint8_t param)
{
  /* cut all except tunneled_frame */
  zb_zdo_cut_all_except_relay_msg_tlv(param);
  (void)zb_buf_cut_left(param, sizeof(zb_tlv_hdr_t) + sizeof(zb_ieee_addr_t));
}


zb_ret_t zb_zdo_link_key_capabilities_process_tlv(zb_uint8_t *tlv_ptr, zb_uint8_t tlv_data_len, zb_uint8_t *capabilities)
{
  zb_ret_t ret;

  ret = zb_tlv_general_tlv_processing(tlv_ptr, tlv_data_len);
  if (ret == RET_OK)
  {
    zb_tlv_hdr_t *tlv_hdr;

    tlv_hdr = zb_tlv_get_tlv_ptr (ZB_TLV_LINK_KEY_CAPABILITIES, tlv_ptr, tlv_data_len);
    if (tlv_hdr != NULL)
    {
      *capabilities = *((zb_uint8_t *)ZB_TLV_GET_BODY_PTR(tlv_hdr));
    }
    else
    {
      ret = RET_NOT_FOUND;
    }
  }

  return ret;
}


void zb_zdo_link_key_cap_put_tlv(zb_uint8_t param, zb_uint8_t capabilities)
{
  zb_uint8_t *ptr;
  ptr = zb_tlv_put_next(param, ZB_TLV_LINK_KEY_CAPABILITIES);
  *ptr = capabilities;
}
