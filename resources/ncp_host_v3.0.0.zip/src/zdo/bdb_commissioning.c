/* ZBOSS Zigbee software protocol stack
 *
 * Copyright (c) 2012-2020 DSR Corporation, Denver CO, USA.
 * http://www.dsr-zboss.com
 * http://www.dsr-corporation.com
 * All rights reserved.
 *
 * This is unpublished proprietary source code of DSR Corporation
 * The copyright notice does not evidence any actual or intended
 * publication of such source code.
 *
 * ZBOSS is a registered trademark of Data Storage Research LLC d/b/a DSR
 * Corporation
 *
 * Commercial Usage
 * Licensees holding valid DSR Commercial licenses may use
 * this file in accordance with the DSR Commercial License
 * Agreement provided with the Software or, alternatively, in accordance
 * with the terms contained in a written agreement between you and
 * DSR.
 */
/*  PURPOSE: BDB commissioning code
*/

#define ZB_TRACE_FILE_ID 426
#include "zb_common.h"
#include "zb_scheduler.h"
#include "zb_bufpool.h"
#include "zb_nwk.h"
#include "zb_nwk_nib.h"
#include "zb_aps.h"
#include "zb_zdo.h"
#include "zb_secur.h"
#include "zb_secur_api.h"
#include "zb_nvram.h"
#include "zb_bdb_internal.h"

#if defined ZB_BDB_MODE && defined BDB_OLD

void bdb_initialization_procedure(zb_uint8_t param);
void bdb_network_steering_on_network(zb_uint8_t param);
void bdb_after_mgmt_permit_joining_cb(zb_uint8_t param);
void bdb_start_rejoin(zb_uint8_t buf_ref, zb_uint16_t secure);

#ifdef ZB_JOIN_CLIENT
void bdb_network_steering_start_scan(zb_uint8_t param);
#endif

#if defined(ZB_BDB_ENABLE_FINDING_BINDING)
void bdb_finding_and_binding(zb_uint8_t param);
#ifdef ZB_JOIN_CLIENT
void bdb_network_steering_not_on_network(zb_uint8_t param);
#endif
#endif


void bdb_initiate_commissioning(zb_uint8_t param)
{
#ifdef ZB_COORDINATOR_ROLE
  zdo_formation_force_link();
#endif
  ZB_BDB().bdb_commissioning_step = ZB_BDB_INITIALIZATION;
  TRACE_MSG(TRACE_ZDO1, "bdb mode - initiate bdb commissioning", (FMT__0));
  ZB_SCHEDULE_CALLBACK(bdb_commissioning_machine, param);
}


zb_bool_t bdb_start_top_level_commissioning(zb_uint8_t mode_mask)
{
  TRACE_MSG(TRACE_ZDO1, "bdb_start_top_level_commissioning mode_mask 0x%hx", (FMT__H, mode_mask));
  if((ZB_BDB().bdb_commissioning_step != ZB_BDB_INITIALIZATION) &&
     (ZB_BDB().bdb_commissioning_step != ZB_BDB_COMMISSIONING_STOP))
  {
    TRACE_MSG(TRACE_ZDO1, "bdb_commissioning in progress (step=%hd), return ZB_FALSE",
                          (FMT__H,ZB_BDB().bdb_commissioning_step));
    return ZB_FALSE;
  }
  ZB_BDB().bdb_commissioning_mode = mode_mask;
  ZB_BDB().bdb_commissioning_step = ZB_BDB_INITIALIZATION;
  /* Do stack init and startup */
  if (!ZB_JOINED())
  {
    ZB_SCHEDULE_CALLBACK(zb_zdo_dev_start_cont, 0);
  }
  else
  {
    if (mode_mask == ZB_BDB_NETWORK_STEERING)
    {
      TRACE_MSG(TRACE_ZDO1, "Network Steering only", (FMT__0));
      ZB_BDB().bdb_commissioning_status = ZB_BDB_STATUS_IN_PROGRESS;
      ZB_BDB().bdb_commissioning_step = ZB_BDB_NETWORK_STEERING;
      ZB_BDB().bdb_application_signal = ZB_BDB_SIGNAL_STEERING;
    }
    zb_buf_get_out_delayed(bdb_commissioning_machine);
  }
  return ZB_TRUE;
}


/**
   Base device commissioning state machine
 */
void bdb_commissioning_machine(zb_uint8_t param)
{
  /*
    BDB Figure 2 - Top level commissioning procedure
  */

  TRACE_MSG(TRACE_ZDO1, ">> bdb_commissioning_machine param %hd step 0x%x bdb_commissioning_mode 0x%x bdb_commissioning_status %d joined %d",
            (FMT__H_D_D_D_D, param, ZB_BDB().bdb_commissioning_step, ZB_BDB().bdb_commissioning_mode, ZB_BDB().bdb_commissioning_status, ZB_JOINED()));
  if (ZB_BDB().bdb_commissioning_step == ZB_BDB_INITIALIZATION)
  {
    /* bdb_commissioning_mode == ZB_BDB_TOUCHLINK_TARGET means do not start
     * network but start ZLL Target at startup. */
#ifdef ZB_BDB_TOUCHLINK
    if (ZB_BDB().bdb_commissioning_mode != ZB_BDB_TOUCHLINK_TARGET)
#endif
    {
      ZB_BDB().bdb_commissioning_status = ZB_BDB_STATUS_IN_PROGRESS;
      ZB_BDB().v_do_primary_scan = ZB_BDB_JOIN_MACHINE_PRIMARY_SCAN;
      ZB_BDB().v_scan_channels = 0; /* Will be set from scan routines. */
      TRACE_MSG(TRACE_ZDO1, "Start BDB Initialization procedure", (FMT__0));
      ZB_SCHEDULE_CALLBACK(bdb_initialization_procedure, param);
    }
#ifdef ZB_BDB_TOUCHLINK
    else
    {
      ZB_BDB().bdb_commissioning_step = ZB_BDB_TOUCHLINK_TARGET;
      ZB_SCHEDULE_CALLBACK(bdb_commissioning_machine, param);
    }
#endif
  }
#ifdef ZB_BDB_TOUCHLINK
  else if (ZB_BDB().bdb_commissioning_step == ZB_BDB_TOUCHLINK_TARGET)
  {
    /* Now if touchlink compiled, force formation compile (need for distributed). */
    /* TODO: a) check for touchlink enabled; b) call touchlink indirectly */
#ifdef ZB_FORMATION
    zdo_formation_force_link();
#endif
    ZB_SCHEDULE_CALLBACK(bdb_touchlink_target_start, param);
  }
#endif
  else if (ZB_BDB().bdb_commissioning_step == ZB_BDB_LAST_COMMISSIONING_STEP)
  {
    ZB_BDB().bdb_commissioning_step <<= 1;
    /* commissioning done */
    if (ZB_BDB().bdb_commissioning_status == ZB_BDB_STATUS_IN_PROGRESS)
    {
      ZB_BDB().bdb_commissioning_status = ZB_BDB_STATUS_SUCCESS;
      /* Reset "force rejoin" flag */
      ZB_BDB().bdb_force_router_rejoin = ZB_FALSE;
    }

    if (ZB_BDB_SIGNAL_FINDING_AND_BINDING_INITIATOR_FINISHED != ZB_BDB().bdb_application_signal)
    {
      zb_app_signal_pack(param, ZB_BDB().bdb_application_signal, -ZB_BDB().bdb_commissioning_status, 0);
      ZB_SCHEDULE_CALLBACK(zb_zdo_startup_complete_int, param);
    }

    TRACE_MSG(TRACE_ZDO1, "BDB commissioning done, status %d, app signal %d. Calling zb_zdo_startup_complete_int status %d",
              (FMT__D_D_D, ZB_BDB().bdb_commissioning_status, ZB_BDB().bdb_application_signal, zb_buf_get_status(param)));
  }

#ifdef ZB_BDB_TOUCHLINK
  else if ((ZB_BDB().bdb_commissioning_mode & ZB_BDB().bdb_commissioning_step) & ZB_BDB_TOUCHLINK_COMMISSIONING)
  {
#if 0
    /* If we are NFN and rejoin was ok, we do not need to run touchlink - finish now. */
    if ((ZB_BDB().bdb_application_signal == ZB_BDB_SIGNAL_DEVICE_REBOOT) && !ZB_ZLL_IS_FACTORY_NEW() && ZB_JOINED())
    {
      ZB_BDB().bdb_commissioning_step = ZB_BDB_LAST_COMMISSIONING_STEP;
      ZB_SCHEDULE_CALLBACK(bdb_commissioning_machine, param);
    }
    else
#endif
    {
      TRACE_MSG(TRACE_ZDO1, "Running BDB Touchlink initiator v_do_primary_scan %hd", (FMT__H, ZB_BDB().v_do_primary_scan));
      ZB_SCHEDULE_CALLBACK(bdb_touchlink_initiator, param);
    }
  }
#endif
  else if (((ZB_BDB().bdb_commissioning_mode & ZB_BDB().bdb_commissioning_step) & ZB_BDB_NETWORK_STEERING)
           /* For ZC steering means "open net for join". Meaningful only after formation complete. */
           && (!ZB_IS_DEVICE_ZC() || ZB_JOINED()))
  {
    TRACE_MSG(TRACE_ZDO1, "bdb_commissioning_mode 0x%x bdb_commissioning_step 0x%x bdb_commissioning_status %d joined %d - network steering",
              (FMT__D_D_D_D, ZB_BDB().bdb_commissioning_mode, ZB_BDB().bdb_commissioning_step, ZB_BDB().bdb_commissioning_status, ZB_JOINED()));
#ifdef ZB_JOIN_CLIENT
    if (zdo_secur_waiting_for_tclk_update())
    {
      TRACE_MSG(TRACE_ZDO1, "We are waiting for TCLK update. What to do? Lets free the buf at least. buf %hd", (FMT__H, param));
      zb_buf_free(param);
    }
    else
#endif
    {
#ifdef ZB_JOIN_CLIENT
      /* BDB has no status "joined but failed to authenticate", so check 2 flags. */
      if (ZB_BDB().bdb_commissioning_status == ZB_BDB_STATUS_NO_NETWORK && ZB_JOINED())
      {
#ifdef ZB_CERTIFICATION_HACKS
        if (ZB_CERT_HACKS().stay_on_network_after_auth_failure && ZB_JOINED())
        {
          /* special hack for bdb tests - do not leave network if authentication failed */
          ZB_BDB().bdb_commissioning_step = ZB_BDB_LAST_COMMISSIONING_STEP;
          ZB_SCHEDULE_CALLBACK(bdb_commissioning_machine, param);
        }
        else
#endif
        {
          TRACE_MSG(TRACE_ZDO1, "Authentication failure. Leave.", (FMT__0));
          /* Attempt to mimic old behavior - prevent call to zb_nwk_neighbor_clear in zb_nlme_reset_request(). Looks not very good.. */
          ZG->nwk.handle.state = ZB_NLME_STATE_RESET_NO_NIB_REINIT;
          /*ZG->nwk.handle.state = ZB_NLME_STATE_RESET_AFTER_LEAVE;*/
          /* Note : must call nlme-reset, but without nib reinit.
             FIXME: TODO:TODO: recheck and implement!
          */
          /* NK: How to reproduce that? We are not waiting for TCLK, but joined and status is
           * NO_NETWORK and we are in BDB machine... Usually we leave on auth fail from
           * zdo_commissioning_authentication_failed(). */
          zb_nwk_do_leave(param, 0);
        }
      }
      else if (ZB_BDB().bdb_commissioning_status == ZB_BDB_STATUS_TCLK_EX_FAILURE)
      {
        /* Joined but failed to update it's TC link key - leave network and complete steering
         * with status ZB_BDB_STATUS_TCLK_EX_FAILURE */

        TRACE_MSG(TRACE_ZDO1, "TC link key update failure. Leave.", (FMT__0));
        ZB_BDB().bdb_commissioning_step = ZB_BDB_LAST_COMMISSIONING_STEP;

#ifdef ZB_CERTIFICATION_HACKS
        if (ZB_CERT_HACKS().stay_on_network_after_auth_failure)
        {
          /* special hack for bdb tests - do not leave network if tclk update failed */
          ZB_SCHEDULE_CALLBACK(bdb_commissioning_machine, param);
        }
        else
#endif
        {
          /* Broadcast leave message */
          zb_nlme_leave_request_t *req = ZB_BUF_GET_PARAM(param,
                                                          zb_nlme_leave_request_t);

          ZB_IEEE_ADDR_ZERO(req->device_address);
          req->remove_children = ZB_FALSE;
          req->rejoin = ZB_FALSE;
          ZG->nwk.handle.state = ZB_NLME_STATE_RESET_NO_NIB_REINIT;
          zb_nlme_leave_request(param);
        }
      }
      else
#endif /* ZB_JOIN_CLIENT */
        if (ZB_JOINED())
        {
          /*
            The node then sets bdbCommissioningStatus to SUCCESS. If the node supports
            touchlink, it sets the values of the aplFreeNwkAddrRangeBegin,
            aplFreeNwkAddrRangeEnd, aplFreeGroupID-RangeBegin and
            aplFreeGroupIDRangeEnd attributes all to 0x0000 (indicating the node 1045 having
            joined the network using MAC association).
          */
          if (ZB_BDB().bdb_commissioning_step & ZB_BDB_NETWORK_STEERING)
          {
            TRACE_MSG(TRACE_ZDO1, "Start BDB network steering when on network", (FMT__0));
            ZB_SCHEDULE_CALLBACK(bdb_network_steering_on_network, param);
          }
          else
          {
            TRACE_MSG(TRACE_ZDO1, "skip steeing step", (FMT__0));
            ZB_SCHEDULE_CALLBACK(bdb_commissioning_machine, param);
          }
        }
#ifdef ZB_JOIN_CLIENT
        else
        {
          /* If we are NFN and join failed - finish and pass it up to application. */
          if (ZB_BDB().nfn)
          {
            TRACE_MSG(TRACE_ZDO1, "Not ZB_JOINED and NFN - finish BDB", (FMT__0));
            ZB_BDB().bdb_commissioning_step = ZB_BDB_LAST_COMMISSIONING_STEP;
            ZB_BDB().bdb_commissioning_status = ZB_BDB_STATUS_NO_NETWORK;
            ZB_SCHEDULE_CALLBACK(bdb_commissioning_machine, param);
          }
          else
          {
            TRACE_MSG(TRACE_ZDO1, "Start BDB network steering when NOT on network", (FMT__0));
            ZB_SCHEDULE_CALLBACK(bdb_network_steering_not_on_network, param);
          }
        }
#endif  /* ZB_JOIN_CLIENT */
    }
  } /* if ZB_BDB_NETWORK_STEERING */

#ifdef ZB_FORMATION           /* zr + zc */
  else if (((ZB_BDB().bdb_commissioning_mode & ZB_BDB().bdb_commissioning_step) & ZB_BDB_NETWORK_FORMATION)
           && !ZB_JOINED()
           && (
#ifdef ZB_DISTRIBUTED_SECURITY_ON
             (ZB_IS_DEVICE_ZR()
              && APS_SELECTOR().bdb_formation != NULL
              /* ZR can do formation in Distributed only */
              && zb_tc_is_distributed())
#else
             0
#endif
             /* Do Formation as ZC */
             || ZB_AIB().aps_designated_coordinator))
  {
    TRACE_MSG(TRACE_ZDO1, "Start BDB formation for device type %d", (FMT__D, ZB_NIB_DEVICE_TYPE()));
    ZB_ASSERT(APS_SELECTOR().bdb_formation);
    ZB_SCHEDULE_CALLBACK(APS_SELECTOR().bdb_formation, param);
  }
#endif  /* ZB_ROUTER_ROLE */
  else if (ZB_BDB().bdb_commissioning_step < ZB_BDB_COMMISSIONING_STOP)
  {
    ZB_BDB().bdb_commissioning_step <<= 1;
    TRACE_MSG(TRACE_ZDO1, "bdb_commissioning_machine next step %d", (FMT__D, ZB_BDB().bdb_commissioning_step));
    ZB_SCHEDULE_CALLBACK(bdb_commissioning_machine, param);
  }
  else
  {
    ZB_BDB().bdb_commissioning_step = ZB_BDB_COMMISSIONING_STOP;
    TRACE_MSG(TRACE_ZDO1, "bdb_commissioning_machine: stop", (FMT__0));
    if (param)
    {
      zb_buf_free(param);
    }
  }
  TRACE_MSG(TRACE_ZDO1, "<< bdb_commissioning_machine", (FMT__0));
}

#ifdef ZB_BDB_TOUCHLINK
void bdb_check_fn()
{
  if (!ZB_AIB().aps_use_nvram)
  {
    TRACE_MSG(TRACE_ZDO1, "No nvram - factory new", (FMT__0));
    ZB_ZLL_SET_FACTORY_NEW();
  }
  else
  {
    if (ZB_NVRAM().empty)
    {
      TRACE_MSG(TRACE_ZDO1, "Factory new", (FMT__0));
      ZB_ZLL_SET_FACTORY_NEW();
    }
    else
    {
      TRACE_MSG(TRACE_ZDO1, "Not factory new", (FMT__0));
      ZB_ZLL_CLEAR_FACTORY_NEW();
    }
  }
}
#endif

void bdb_preinit()
{
#ifndef ZB_COORDINATOR_ONLY
  zb_aps_device_key_pair_set_t *aps_key;
#endif
  zb_bool_t joined;

  TRACE_MSG(TRACE_ZDO1, ">> bdb_initialization_procedure", (FMT__0));

#ifdef ZB_BDB_TOUCHLINK
  bdb_check_fn();
#endif

  ZB_BDB().tclk_valid = ZB_FALSE;

#ifndef ZB_COORDINATOR_ONLY
  aps_key = zb_secur_get_link_key_by_address(ZB_AIB().trust_center_address, ZB_SECUR_VERIFIED_KEY);
  if (aps_key
      || ZB_IEEE_ADDR_CMP(ZB_AIB().trust_center_address, ZB_PIBCACHE_EXTENDED_ADDRESS())
#if defined ZB_DISTRIBUTED_SECURITY_ON
      || IS_DISTRIBUTED_SECURITY()
      || zb_tc_is_distributed()
#endif
    )
#endif /* ZB_COORDINATOR_ONLY */
  {
    ZB_BDB().tclk_valid = ZB_TRUE;
  }

  if (ZB_NIB_DEVICE_TYPE() == ZB_NWK_DEVICE_TYPE_NONE)
#ifdef ZB_ROUTER_ROLE
  {
    if (ZB_AIB().aps_designated_coordinator)
    {
      ZB_NIB().device_type = ZB_NWK_DEVICE_TYPE_COORDINATOR;
    }
    else
    {
      ZB_NIB().device_type = ZB_NWK_DEVICE_TYPE_ROUTER;
    }
  }
#else
  {
    ZB_NIB().device_type = ZB_NWK_DEVICE_TYPE_ED;
  }
#endif

  joined = (zb_bool_t)(!ZB_EXTPANID_IS_ZERO(ZB_NIB_EXT_PAN_ID()) &&
    ZG->aps.authenticated);

  if (ZB_AIB().coordinator_version >= 21)
  {
    joined = (zb_bool_t)(joined && ZB_BDB().tclk_valid);
  }

#if defined ZB_DISTRIBUTED_SECURITY_ON
  if (joined)
  {
    zb_sync_distributed();
  }
#endif

  /* parallel NFN flag used if no touchlink & zll */
  ZB_BDB().nfn = joined;
  if (joined)
  {
    TRACE_MSG(TRACE_ZDO1, "Not factory new", (FMT__0));
#ifdef ZB_BDB_TOUCHLINK
    /* just in case */
    ZB_ZLL_CLEAR_FACTORY_NEW();
#endif
  }

#ifdef ZB_BDB_TOUCHLINK
  /* 8.7 Touchlink procedure for an initiator:
     The touchlink procedure for an initiator can perform a "normal" channel scan or an "extended"
     channel scan; the latter is used if a reset to factory new is required (see sub-clause 9.2) or
     if the target could be operating on a channel other than those defined in
     bdbcTLPrimaryChannelSet.
 */
  ZB_BDB().bdb_ext_channel_scan = 1; /* ZB_ZLL_IS_FACTORY_NEW() */
#endif
  TRACE_MSG(TRACE_ERROR, "dev type %hd, joined %hd, ext_pan_id %hd, authenticated %hd, tclk_valid %hd",
            (FMT__H_H_H_H_H, ZB_NIB_DEVICE_TYPE(), joined, !ZB_EXTPANID_IS_ZERO(ZB_NIB_EXT_PAN_ID()), ZG->aps.authenticated, ZB_BDB().tclk_valid));
}

/**
   BDB Initialization procedure according to 7.1 Initialization procedure
 */
void bdb_initialization_procedure(zb_uint8_t param)
{
  /* Note: Called twice on startup in r21 (from zb_zdo_dev_init() and here), but looks like it is not
   * a big problem. */
  bdb_preinit();
/* Can do rejoin if ZED and if authenticated: only secured rejoin is
   * allowed by BDB.
   * Seems, ZR must continue its work without a rejoin (hmm?)
   */
#ifdef ZB_FORMATION
  if (ZB_BDB().nfn
      && ZB_JOINED()
      && ZB_BDB().bdb_commissioning_mode == ZB_BDB_NETWORK_FORMATION)
  {
    TRACE_MSG(TRACE_ZDO2, "Repeat Formation when joined - do nothing", (FMT__0));
    ZB_BDB().bdb_application_signal = ZB_BDB_SIGNAL_FORMATION;
    ZB_BDB().bdb_commissioning_step = ZB_BDB_LAST_COMMISSIONING_STEP;
  }
  else
#endif
    if (ZB_BDB().nfn)
  {
#if defined ZB_COORDINATOR_ROLE
    if (ZB_IS_DEVICE_ZC())
    {
      TRACE_MSG(TRACE_ZDO2, "Start ZC without formation", (FMT__0));
      ZB_JOINED() = 1;
      ZB_SCHEDULE_CALLBACK(zb_nwk_cont_without_formation, param);
      param = 0;
    }
    else
#endif
#if defined ZB_ROUTER_ROLE
    if (ZB_IS_DEVICE_ZR() && !ZB_BDB().bdb_force_router_rejoin)
    {
      TRACE_MSG(TRACE_ZDO2, "Initiate start router for ZR", (FMT__0));
      ZB_JOINED() = 1;
      ZB_SCHEDULE_CALLBACK(zb_zdo_start_router, param);
      param = 0;
    }
    else
#endif
    {
      /* Do not rejoin in touchlink mode by default.
         Rationale: When start in NFN with touchlink we do scan+rejoin. To exclude double rejoin, do
         not rejoin before scan. Also do not start in ZB_BDB_TOUCHLINK_COMMISSIONING mode if NFN
         (from application) if scan is not needed - use ZB_BDB_NETWORK_STEERING instead.
      */
      if (ZB_BDB().bdb_commissioning_mode != ZB_BDB_TOUCHLINK_COMMISSIONING)
      {
        zb_channel_list_t rejoin_ch_list;

        zb_channel_list_init(rejoin_ch_list);
        zb_channel_page_list_set_2_4GHz_mask(rejoin_ch_list,
                                             zb_aib_channel_page_list_get_2_4GHz_mask());
        zdo_initiate_rejoin(param, ZB_NIB_EXT_PAN_ID(),
                            rejoin_ch_list,
                            ZB_TRUE);
        param = 0;
      }
    }

    ZB_BDB().bdb_application_signal = ZB_BDB_SIGNAL_DEVICE_REBOOT;
    ZB_BDB().bdb_commissioning_step = ZB_BDB_TOUCHLINK_COMMISSIONING;
  }
  else if (ZB_EXTPANID_IS_ZERO(ZB_NIB_EXT_PAN_ID()) &&
           !ZG->aps.authenticated &&
           (ZB_BDB().tclk_valid == ZB_FALSE
#ifndef ZB_COORDINATOR_ONLY
            || ZB_IEEE_ADDR_CMP(ZB_AIB().trust_center_address, ZB_PIBCACHE_EXTENDED_ADDRESS())
#else
            || ZB_TRUE  /* ZB_COORDINATOR_ONLY */
#endif
#if defined ZB_DISTRIBUTED_SECURITY_ON
            || IS_DISTRIBUTED_SECURITY()
            || zb_tc_is_distributed()
#endif
             ))
  {
    /* Not ever joined - perform commissioning */

    TRACE_MSG(TRACE_ZDO1, "Not joined, start BDB commissioning", (FMT__0));
    if (ZB_BDB().bdb_commissioning_mode == ZB_BDB_NETWORK_FORMATION)
    {
      TRACE_MSG(TRACE_ZDO1, "Formation only", (FMT__0));
      ZB_BDB().bdb_application_signal = ZB_BDB_SIGNAL_FORMATION;
    }
    else
    {
      ZB_BDB().bdb_application_signal = ZB_BDB_SIGNAL_DEVICE_FIRST_START;
    }
    /* first step */
    ZB_BDB().bdb_commissioning_step = ZB_BDB_TOUCHLINK_COMMISSIONING;
 }
  else if (!ZB_EXTPANID_IS_ZERO(ZB_NIB_EXT_PAN_ID())
           && ((ZB_AIB().coordinator_version < 21) ||
               ((ZB_AIB().coordinator_version >= 21) && ZB_BDB().tclk_valid)))
  {
#ifndef ZB_COORDINATOR_ONLY
    zb_channel_list_t rejoin_ch_list;
#endif
    TRACE_MSG(TRACE_ZDO1, "It seems that nwk key is outdated - initiate TC Rejoin", (FMT__0));
#ifndef ZB_COORDINATOR_ONLY
    zb_channel_list_init(rejoin_ch_list);
    zb_channel_page_list_set_2_4GHz_mask(rejoin_ch_list,
                                         zb_aib_channel_page_list_get_2_4GHz_mask());
    zdo_initiate_rejoin(param, ZB_NIB_EXT_PAN_ID(),
                        rejoin_ch_list, ZB_FALSE);
#endif  /* #ifndef ZB_COORDINATOR_ONLY */
    ZB_BDB().bdb_application_signal = ZB_BDB_SIGNAL_DEVICE_REBOOT;
    ZB_BDB().bdb_commissioning_step = ZB_BDB_TOUCHLINK_COMMISSIONING;
    param = 0;
  }
#ifndef ZB_COORDINATOR_ONLY
  else
  {
    TRACE_MSG(TRACE_ERROR, "Strange configuration, leave", (FMT__0));
    zb_nwk_do_leave(param, 0);
    param = 0;
  }
#endif  /* #ifndef ZB_COORDINATOR_ONLY */

  if (param)
  {
    TRACE_MSG(TRACE_ZDO1, "bdb_commissioning_machine do next step %d", (FMT__D, ZB_BDB().bdb_commissioning_step));
    ZB_SCHEDULE_CALLBACK(bdb_commissioning_machine, param);
  }
}


#ifdef ZB_JOIN_CLIENT
void bdb_network_steering_start_scan(zb_uint8_t param)
{
  zb_nlme_network_discovery_request_t *req = ZB_BUF_GET_PARAM(param, zb_nlme_network_discovery_request_t);
  ZB_BZERO(req, sizeof(zb_nlme_network_discovery_request_t));

  TRACE_MSG(TRACE_ZDO3, "bdb_network_steering_start_scan param %hd", (FMT__H, param));
  /* MMDEVSTUBS */
  zb_channel_page_list_set_2_4GHz_mask(req->scan_channels_list, ZB_BDB().v_scan_channels);

  req->scan_duration = ZB_BDB().bdb_scan_duration;
  ZDO_CTX().zdo_ctx.discovery_ctx.disc_count = ZDO_CTX().conf_attr.nwk_scan_attempts;
  /* That finishes in zdo_app.c zb_nlme_network_discovery_confirm */
  ZB_SCHEDULE_CALLBACK(zb_nlme_network_discovery_request, param);
}


void bdb_network_steering_not_on_network(zb_uint8_t param)
{
  if (ZB_BDB().v_do_primary_scan == ZB_BDB_JOIN_MACHINE_PRIMARY_SCAN
      && ZB_BDB().bdb_primary_channel_set != 0
      && !ZB_AIB().aps_designated_coordinator)
  {
    ZB_BDB().v_do_primary_scan = ZB_BDB_JOIN_MACHINE_SECONDARY_SCAN_START;
    ZB_BDB().bdb_commissioning_status = ZB_BDB_STATUS_IN_PROGRESS;

#ifdef ZB_REJOIN_BACKOFF
    if (zb_zdo_rejoin_backoff_is_running() && (ZDO_CTX().zdo_rejoin_backoff.rjb_cnt == 1) && !ZB_BDB().v_scan_channels)
    {
      /* the first attempt - do secure rejoin using the current channel */
      ZB_BDB().v_scan_channels = (1l << ZB_PIBCACHE_CURRENT_CHANNEL());
      /* TRICKY: Set primary_scan again - we will do 2 PRIMARY_SCANs (first on current channel,
       * second on bdb_primary_channel_set), then SECONDARY_SCAN.  */
      ZB_BDB().v_do_primary_scan = ZB_BDB_JOIN_MACHINE_PRIMARY_SCAN;
    }
    else
    {
      /* We done rejoin_backoff specific attempt, now reset v_scan_channels and use usual scheme
       * (bdb_primary_channel_set, then bdb_secondary_channel_set). */
      ZB_BDB().v_scan_channels = 0;

      /* the second and further attempts - do secure rejoin using ALL channels */

      /* 01/27/2017 EE Why having already 2 channel sets we introduce
         another one - rejoin backoff channels mask? Can't we go thru
         primary/secondary like we do for usual start? ok, after first attempt at
         the current channel.
         Do we need default_channel_mask parameter in zb_zdo_rejoin_backoff_start?
         Isn't product_cfg.aps_channel_mask == bdb_primary_channel_set?
      */
      /* NK: Seems like it is ok. Lets update bdb_channel_mask on rejoin_backoff start instead of
       * using rjb_chan_mask (in the case when application wants to use custom channel mask for rjb).
       *
       * Currently will not remove rjb_chan_mask because it is used in legacy (non-BDB)
       * variant. It is a hack because in this variant we overwrite original
       * ZB_AIB().aps_channel_mask on 1st rjb attempt, then restore it from rjb_chan_mask (in all known
       * cases production_mask == ZB_AIB().aps_channel_mask == rjb_chan_mask).
       * Not sure about supporting legacy (non-BDB) rejoin_backoff, for me it looks like it may be
       * completely removed.
       */

      /* Implement insecure rejoin via BDB if needed. */
    }
#endif

    if (!ZB_BDB().v_scan_channels)
    {
      /* 01/30/2017 EE  In case of rejoin backoff you substitute pribary
      channel set by current channel, then use secondary channel set.
      Not sure this is what you want to do.
      Probably need to go in 2 steps: current, primary, secondary.
      As an alternative (simpler, but a bit further from BDB : current, primary | secondary.
      BTW I do not know why they ever invented primary and secondary...
      */
      ZB_BDB().v_scan_channels = ZB_BDB().bdb_primary_channel_set;
    }
    TRACE_MSG(TRACE_ZDO1, "Doing primary scan channel mask 0x%lx", (FMT__L, ZB_BDB().v_scan_channels));
    ZB_SCHEDULE_CALLBACK(bdb_network_steering_start_scan, param);
  }
  else if (!ZB_AIB().aps_designated_coordinator
           && ((ZB_BDB().v_do_primary_scan == ZB_BDB_JOIN_MACHINE_SECONDARY_SCAN_START
                && ZB_BDB().bdb_secondary_channel_set != 0)
               ||
               (ZB_BDB().v_do_primary_scan == ZB_BDB_JOIN_MACHINE_PRIMARY_SCAN
                && ZB_BDB().bdb_secondary_channel_set != 0
                && ZB_BDB().bdb_primary_channel_set == 0)))
  {
    ZB_BDB().v_do_primary_scan = ZB_BDB_JOIN_MACHINE_SECONDARY_SCAN_DONE;
    ZB_BDB().bdb_commissioning_status = ZB_BDB_STATUS_IN_PROGRESS;
    ZB_BDB().v_scan_channels = ZB_BDB().bdb_secondary_channel_set;
    TRACE_MSG(TRACE_ZDO1, "Doing secondary scan channel mask 0x%lx", (FMT__L, ZB_BDB().v_scan_channels));
    ZB_SCHEDULE_CALLBACK(bdb_network_steering_start_scan, param);
  }
  else
  {
    ZB_BDB().bdb_commissioning_status = ZB_BDB_STATUS_NO_NETWORK;
    TRACE_MSG(TRACE_ZDO1, "BDB: Could not join or authorize - run next bdb machine step", (FMT__0));
    ZB_BDB().v_do_primary_scan = ZB_BDB_JOIN_MACHINE_PRIMARY_SCAN;
    ZB_BDB().bdb_commissioning_step <<= 1;
    ZB_SCHEDULE_CALLBACK(bdb_commissioning_machine, param);
  }
}
#endif  /* ZB_JOIN_CLIENT */


void bdb_network_steering_on_network(zb_uint8_t param)
{
  TRACE_MSG(TRACE_ZDO3, "bdb_network_steering_on_network param %hd", (FMT__H, param));
  /*
    Send Permit Joining.

    If I am ZR or ZC, open myself for connects (permit joining).
   */
  {
    /*
  Continues EZ-Mode Nwk steering after network has been formed or device has joined to the nwk:
  invokes permit_joining routines for ZC & ZR, pushes the results of Nwk steering up
  via user callback for ZED
*/
    /* Send mgmt permit joining broadcast */
    zb_zdo_mgmt_permit_joining_req_param_t *req_param = ZB_BUF_GET_PARAM(param, zb_zdo_mgmt_permit_joining_req_param_t);

    ZB_BZERO(req_param, sizeof(zb_zdo_mgmt_permit_joining_req_param_t));
    req_param->dest_addr = ZB_NWK_BROADCAST_ROUTER_COORDINATOR;
    req_param->permit_duration = ZB_BDBC_MIN_COMMISSIONING_TIME_S;
    req_param->tc_significance = 1;
    zb_zdo_mgmt_permit_joining_req(param, bdb_after_mgmt_permit_joining_cb);
  }
}

/*
  Called when broadcasting PermitJoining finished
  during EZ-Mode Nwk Steering for ZC or ZR:
  schedules local nlme.permit_joining request
*/
void bdb_after_mgmt_permit_joining_cb(zb_uint8_t param)
{

  TRACE_MSG(TRACE_ZDO2, "> bdb_after_mgmt_permit_joining_cb %hd", (FMT__H, param));

  if (zb_buf_get_status(param) == RET_OK)
  {
#ifdef ZB_ROUTER_ROLE
    if (ZB_IS_DEVICE_ZC_OR_ZR())
    {
      zb_zdo_mgmt_permit_joining_req_param_t *req = ZB_BUF_GET_PARAM(param,
                                                                           zb_zdo_mgmt_permit_joining_req_param_t);

      ZB_BZERO(req, sizeof(zb_zdo_mgmt_permit_joining_req_param_t));
      req->permit_duration = ZB_BDBC_MIN_COMMISSIONING_TIME_S;
      req->dest_addr = ZB_PIBCACHE_NETWORK_ADDRESS();

      zb_zdo_mgmt_permit_joining_req(param, bdb_commissioning_machine);
      param = 0;
    }
#endif
  }
  else
  {
    ZB_BDB().bdb_commissioning_status = ZB_BDB_STATUS_NOT_PERMITTED;
  }
  ZB_BDB().bdb_commissioning_step <<= 1;
  if (param)
  {
    ZB_SCHEDULE_CALLBACK(bdb_commissioning_machine, param);
  }

  TRACE_MSG(TRACE_ZCL2, "< bdb_after_mgmt_permit_joining_cb", (FMT__0));
}


#if defined(ZB_BDB_ENABLE_FINDING_BINDING)
void bdb_finding_and_binding(zb_uint8_t param)
{
  TRACE_MSG(TRACE_ZDO3, "bdb_finding_and_binding param %hd", (FMT__H, param));

  ZB_BDB().bdb_commissioning_step <<= 1;
  ZB_SCHEDULE_CALLBACK(bdb_commissioning_machine, param);
}
#endif

void bdb_load_factory_new_flag(void)
{
#ifndef ZB_COORDINATOR_ONLY
  zb_aps_device_key_pair_set_t *aps_key;
#endif
  zb_bool_t joined;
  zb_bool_t tclk_valid = ZB_FALSE;

#ifndef ZB_COORDINATOR_ONLY
  aps_key = zb_secur_get_link_key_by_address(ZB_AIB().trust_center_address, ZB_SECUR_VERIFIED_KEY);
  if (aps_key
      || ZB_IEEE_ADDR_CMP(ZB_AIB().trust_center_address, ZB_PIBCACHE_EXTENDED_ADDRESS())
#if defined ZB_DISTRIBUTED_SECURITY_ON
      || IS_DISTRIBUTED_SECURITY()
      || zb_tc_is_distributed()
#endif
    )
#endif /* ZB_COORDINATOR_ONLY */
  {
    tclk_valid = ZB_TRUE;
  }

  joined = (zb_bool_t)(!ZB_EXTPANID_IS_ZERO(ZB_NIB_EXT_PAN_ID()) &&
    ZG->aps.authenticated);

  if (ZB_AIB().coordinator_version >= 21)
  {
    joined = (zb_bool_t)(joined && tclk_valid);
  }

  ZB_BDB().nfn = joined;

  TRACE_MSG(TRACE_ZDO1, "bdb_load_factory_new_flag %hd",
            (FMT__H, ZB_BDB().nfn));
}

#if 0                           /* from r21 */
void bdb_commissioning_leave_done(void)
{
  zb_bool_t call_user_app = ZB_TRUE;

  TRACE_MSG(TRACE_ZDO1, "bdb_commissioning_leave_done: comm_step %hd comm_status %hd",
            (FMT__H_H, ZB_BDB().bdb_commissioning_step, ZB_BDB().bdb_commissioning_status));

  if (ZB_BDB().bdb_commissioning_step != ZB_BDB_COMMISSIONING_STOP &&
      ZB_BDB().bdb_commissioning_step != ZB_BDB_FINDING_N_BINDING)
  {
    /* BDB commissioning machine is in progress */
  if (ZB_BDB().bdb_commissioning_status == ZB_BDB_STATUS_TCLK_EX_FAILURE)
  {
    /* BDB device failed to update tclk exchange */
    zb_buf_get_out_delayed(bdb_commissioning_machine);
      call_user_app = ZB_FALSE;
  }
  else if (ZB_BDB().bdb_commissioning_status == ZB_BDB_STATUS_NO_NETWORK)
  {
    /* Left network by internal stack's reason (authentication failure) - TK with NWK
     * key failed - schedule next search iteration */
    /* Will be here after bdb device failed authentication - lets join to
     * other networks */
    ZB_BDB().bdb_commissioning_status = ZB_BDB_STATUS_IN_PROGRESS;
    ZB_BDB().bdb_commissioning_status = ZB_BDB_STATUS_IN_PROGRESS;
    ZB_SCHEDULE_CALLBACK(zb_zdo_dev_start_cont, 0);
      call_user_app = ZB_FALSE;
  }
  }

  if (call_user_app)
  {
    /* Left network by external stack's reason - local or remote leave. Inform
     * application. */
    ZB_BDB().bdb_commissioning_step   = ZB_BDB_COMMISSIONING_STOP;
    ZB_BDB().bdb_commissioning_status = ZB_BDB_STATUS_NO_NETWORK;
    zb_zdo_reset_inform_user_app();
  }
}
#endif

#endif  /* ZB_BDB_MODE && BDB_OLD */
