/* ZBOSS Zigbee software protocol stack
 *
 * Copyright (c) 2012-2020 DSR Corporation, Denver CO, USA.
 * www.dsr-zboss.com
 * www.dsr-corporation.com
 * All rights reserved.
 *
 * This is unpublished proprietary source code of DSR Corporation
 * The copyright notice does not evidence any actual or intended
 * publication of such source code.
 *
 * ZBOSS is a registered trademark of Data Storage Research LLC d/b/a DSR
 * Corporation
 *
 * Commercial Usage
 * Licensees holding valid DSR Commercial licenses may use
 * this file in accordance with the DSR Commercial License
 * Agreement provided with the Software or, alternatively, in accordance
 * with the terms contained in a written agreement between you and
 * DSR.
 */
/* PURPOSE: ZDO RX path
*/


#define ZB_TRACE_FILE_ID 2101
#include "zb_common.h"
#include "zb_scheduler.h"
#include "zb_bufpool.h"
#include "zb_nwk.h"
#include "zb_aps.h"
#include "zb_zdo.h"
#include "zdo_common.h"
#include "zdo_wwah_stubs.h"
/*! \addtogroup ZB_ZDO */
/*! @{ */

#ifdef ZB_ROUTER_ROLE
static void zdo_device_annce_srv(zb_uint8_t param, void *dt);
static void zb_parent_annce_resp_handler(zb_uint8_t param, void *dt);

#if (defined ZB_JOINING_LIST_SUPPORT) && defined(ZB_ROUTER_ROLE)
static void zb_nwk_ieee_joining_list_resp_handler(zb_uint8_t param);
#endif /* (defined ZB_JOINING_LIST_SUPPORT) && defined(ZB_ROUTER_ROLE) */
#ifdef ZB_ENABLE_ZGP
void zgp_handle_dev_annce(zb_zdo_device_annce_t *da);
#endif /* ZB_ENABLE_ZGP */

#endif /* ZB_ROUTER_ROLE */

void zb_zdo_send_status_res(zb_uint8_t param, zb_uint8_t status)
{
  zb_apsde_data_indication_t *ind = (zb_apsde_data_indication_t *)ZB_BUF_GET_PARAM(param, zb_apsde_data_indication_t);
  zb_zdo_status_resp_t *resp;
  zb_uint16_t clusterid;
  zb_uint16_t dst_addr;
  zb_uint8_t tsn;
  zb_uint8_t need_secur = ZB_APS_FC_GET_SECURITY(ind->fc);

  TRACE_MSG(TRACE_ZDO2, ">> zb_zdo_send_status_res, param %hd, status %hd", (FMT__H_H, param, status));

  clusterid = ZB_ZDO_RESP_FROM_REQ_CLUSTER(ind->clusterid);
  dst_addr = ind->src_addr;
  tsn = ind->u.tsn;

  resp = zb_buf_initial_alloc(param, sizeof(zb_zdo_status_resp_t));
  resp->tsn = tsn;
  resp->status = status;

  zdo_send_resp_by_short(clusterid, param, dst_addr, ZB_U2B(need_secur));
  TRACE_MSG(TRACE_ZDO2, "<< zb_zdo_send_status_res", (FMT__0));
}

static void zb_zdo_common_response_handler(zb_uint8_t param, zb_uint8_t *skip_free_buf)
{
  zb_apsde_data_indication_t *ind = (zb_apsde_data_indication_t *)ZB_BUF_GET_PARAM(param, zb_apsde_data_indication_t);
  zb_uint16_t clusterid = ind->clusterid;
  zb_uint8_t status = 0;
  zb_ret_t ret = RET_OK;
#ifdef ZB_ROUTER_ROLE
  zb_uint16_t src = ind->src_addr;
#endif

  TRACE_MSG(TRACE_ZDO2, ">> zb_zdo_common_response_handler, param %hd, clusterid 0x%x", (FMT__H_D, param, clusterid));

  if (clusterid == ZDO_MGMT_LEAVE_RESP_CLID)
  {
    status = *((zb_uint8_t*)zb_buf_begin(param) + 1/*tsn*/);
  }

  if (clusterid == ZDO_NWK_ADDR_RESP_CLID
      || clusterid == ZDO_IEEE_ADDR_RESP_CLID)
  {
    /* Now we have both short and long for some device. Update
     * the address translation table (do not lock - just cache) */
    zb_zdo_nwk_addr_resp_head_t *resp = (zb_zdo_nwk_addr_resp_head_t*)(zb_buf_begin(param));

    if (resp->status == ZB_ZDP_STATUS_SUCCESS)
    {
      zb_address_ieee_ref_t addr_ref;
      zb_ieee_addr_t ieee_addr;
      zb_uint16_t nwk_addr;

      ZB_LETOH64(ieee_addr, resp->ieee_addr);
      ZB_LETOH16(&nwk_addr, &resp->nwk_addr);

      ZB_MEMCPY(resp->ieee_addr, ieee_addr, sizeof(zb_ieee_addr_t));
      ZB_MEMCPY(&resp->nwk_addr, &nwk_addr, sizeof(zb_uint16_t));

      TRACE_MSG(TRACE_ZDO3, "Got addr resp: long address " TRACE_FORMAT_64 " short 0x%x - update address translation table",
                (FMT__A_D, TRACE_ARG_64(resp->ieee_addr), resp->nwk_addr));

      if (ZB_NWK_IS_ADDRESS_BROADCAST(nwk_addr))
      {
        TRACE_MSG(TRACE_ERROR, "Broadcast address 0x%x received in nwk addr resp for device " TRACE_FORMAT_64,
                  (FMT__D_A, nwk_addr, TRACE_ARG_64(ieee_addr)));
        ret = RET_ERROR;
      }

      if (ret == RET_OK)
      {
        ret = zb_address_update(resp->ieee_addr, resp->nwk_addr, ZB_FALSE, &addr_ref);

        if (ret != RET_OK)
        {
          TRACE_MSG(TRACE_ERROR, "zb_address_update failed [%d]", (FMT__D, ret));
        }
      }
    }
    /* TODO: same for ZDO_MGMT_LQI_RESP_CLID */
  }

#ifdef APS_FRAGMENTATION
  if (ind->clusterid == ZDO_NODE_DESC_RESP_CLID)
  {
    /* Update max_in_trans_size for this short addr */
    zb_zdo_node_desc_resp_t *resp = (zb_zdo_node_desc_resp_t*)(zb_buf_begin(param));

    if (resp->hdr.status == (zb_zdp_status_t)ZB_ZDP_STATUS_SUCCESS)
    {
      zb_aps_add_max_trans_size(resp->hdr.nwk_addr,
                                resp->node_desc.max_incoming_transfer_size,
                                resp->node_desc.max_buf_size);
    }
  }
#endif

  if (ind->clusterid == ZDO_MGMT_PERMIT_JOINING_RESP_CLID)
  {
    /* [VK]: There are the following cases to get a permit joining response:
     * 1) when we send a permit joining request via broadcast after network formation;
     * 2) when we send a permit joining request via broadcast after network joining;
     * 3) when we get a ZDO Permit Joining Response packet.
     *
     * In case of 1 and 2 we use a buffer status field to store status.
     * It is required to do the same for the 3rd case.
     */
    zb_zdo_mgmt_permit_joining_resp_t *resp = (zb_zdo_mgmt_permit_joining_resp_t *)zb_buf_begin(param);
    zb_buf_set_status(param, resp->status);
  }

#ifndef ZB_COORDINATOR_ONLY
  if (ind->clusterid == ZDO_SECURITY_GET_AUTH_LEVEL_RESP_CLID)
  {
    zb_zdo_parse_get_auth_level_resp(param);
  }
#endif

  if (ind->clusterid == ZDO_SECURITY_GET_CONFIGURATION_RESP_CLID)
  {
    zb_zdo_parse_get_configuration_resp(param);
  }

  ret = zdo_af_resp(param);
  /* do not free buffer if callback was found */
  *skip_free_buf = ZB_B2U(ret == RET_OK);

#ifdef ZB_ROUTER_ROLE
  /* When received Leave Resp after LEAVE, device must be removed from the
   * neighbor: it is already gone. */
  if (clusterid == ZDO_MGMT_LEAVE_RESP_CLID
      && status == 0U)
  {
    zdo_handle_mgmt_leave_rsp(src);
  }
#else
  ZVUNUSED(status);
#endif /* ZB_ROUTER_ROLE */

#ifdef ZB_ENABLE_SE
  if (ind->clusterid == ZDO_MATCH_DESC_RESP_CLID && !ZB_U2B(*skip_free_buf)
      && ZDO_SELECTOR().match_desc_resp_handler != NULL)
  {
    *skip_free_buf = ZDO_SELECTOR().match_desc_resp_handler(param);
  }
#endif
  TRACE_MSG(TRACE_ZDO2, "<< zb_zdo_common_response_handler", (FMT__0));
}

static zb_bool_t zb_zdo_is_r23_cmd_id(zb_uint16_t clusterid)
{
  zb_bool_t ret = ZB_FALSE;
  if (clusterid == ZDO_MGMT_NWK_BEACON_SURVEY_REQ_CLID
      || clusterid == ZDO_SECURITY_SET_CONFIGURATION_REQ_CLID
      || clusterid == ZDO_SECURITY_GET_CONFIGURATION_REQ_CLID
      || clusterid == ZDO_SECURITY_DECOMMISSION_REQ_CLID
      || clusterid == ZDO_SECURITY_FRAME_CNT_CHALLENGE_REQ_CLID
      || clusterid == ZDO_SECURITY_START_KEY_NEGOTIATION_REQ_CLID
      || clusterid == ZDO_SECURITY_GET_AUTH_TOKEN_REQ_CLID
      || clusterid == ZDO_SECURITY_GET_AUTH_LEVEL_REQ_CLID
      || clusterid == ZDO_SECURITY_START_KEY_UPDATE_REQ_CLID)
  {
    ret = ZB_TRUE;
  }

  return ret;
}

static zb_bool_t zb_zdo_cmd_id_is_valid_for_device_interview(zb_uint16_t clusterid)
{
  zb_bool_t valid = ZB_FALSE;

  if (clusterid == ZDO_NWK_ADDR_REQ_CLID
       || clusterid == ZDO_IEEE_ADDR_REQ_CLID
       || clusterid == ZDO_NODE_DESC_REQ_CLID
       || clusterid == ZDO_POWER_DESC_REQ_CLID
       || clusterid == ZDO_SIMPLE_DESC_REQ_CLID
       || clusterid == ZDO_ACTIVE_EP_REQ_CLID
       || clusterid == ZDO_MATCH_DESC_REQ_CLID
      )
  {
    valid = ZB_TRUE;
  }

  return valid;
}


#if !defined(ZB_LITE_NO_ZDO_SYSTEM_SERVER_DISCOVERY)

static void zb_zdo_system_server_discovery_resp_handle(zb_uint8_t param, zb_uint8_t *skip_free_buf)
{
  zb_apsde_data_indication_t *ind = (zb_apsde_data_indication_t *)ZB_BUF_GET_PARAM(param, zb_apsde_data_indication_t);

  zb_zdo_system_server_discovery_resp_t *resp = (zb_zdo_system_server_discovery_resp_t*)zb_buf_begin(param);

  if (zb_buf_len(param) < sizeof(zb_zdo_system_server_discovery_resp_t))
  {
    TRACE_MSG(TRACE_ZDO1, "Malformed zb_zdo_system_server_discovery_resp_t packet", (FMT__0));
    *skip_free_buf = 0;
  }
  else
  {
    ZB_LETOH16_ONPLACE(resp->server_mask);

    TRACE_MSG(TRACE_ZDO1, "SERVER_DISCOVERY_RESP_CLID tsn %hd, disc_tsn %hd, server_mask 0x%x",
              (FMT__H_H_D, resp->tsn, ZDO_CTX().system_server_discovery_tsn, resp->server_mask));

    /* 2.4.4.2.10 System_Server_Discovery_rsp */
    /* If the Network Manager bit was set in the System_Server_Discovery_rsp,
     * then the Remote Device's NWK address SHALL be set into the nwkManagerAddr of the NIB. */
    if (ZB_BIT_IS_SET(resp->server_mask, ZB_NETWORK_MANAGER))
    {
      ZB_NIB_NWK_MANAGER_ADDR() = ind->src_addr;

      TRACE_MSG(TRACE_ZDO2, "Discovery resp from Network Manager, so assign nwkManagerAddr to 0x%x",
                (FMT__D, ZB_NIB_NWK_MANAGER_ADDR()));
    }

    if (resp->tsn == ZDO_CTX().system_server_discovery_tsn
        && ZDO_CTX().system_server_discovery_cb != NULL
      )
    {
      ZB_SCHEDULE_CALLBACK(ZDO_CTX().system_server_discovery_cb, param);
    }
    else
    {
      *skip_free_buf = 0;
    }
  }
}
#endif  /* !ZB_LITE_NO_ZDO_SYSTEM_SERVER_DISCOVERY */


void zb_zdo_data_indication(zb_uint8_t param)
{
  zb_apsde_data_indication_t *ind = (zb_apsde_data_indication_t *)ZB_BUF_GET_PARAM(param, zb_apsde_data_indication_t);
#ifdef ZB_ROUTER_ROLE
  zb_uint8_t *body;
#endif
  zb_uint8_t skip_free_buf = 1;
  zb_ret_t ret;
  zb_uint8_t fc;
  zb_uint8_t tsn;
  zb_uint16_t clusterid;
  ZB_TH_PUSH_PACKET(ZB_TH_ZDO_DATA, ZB_TH_PRIMITIVE_INDICATION, param);
  TRACE_MSG(TRACE_ZDO1, ">> zb_zdo_data_indication %hd clu 0x%hx", (FMT__H_H, param, ind->clusterid));
  fc = ind->fc; /* APS FC is needed in some response functions */
#ifdef ZB_ROUTER_ROLE
  body = zb_buf_begin(param);
#endif

  /* Put TSN to apsde_data_ind. */
  tsn = *(zb_uint8_t *)zb_buf_begin(param);
  ind->u.tsn = tsn;
  clusterid = ind->clusterid;

  /*cstat !MISRAC2012-Rule-14.3_b */
  /** @mdr{00015,8} */
  /* disable processing of sensitive ZDO commands that have not been encrypted using the
   * Trust Center Link key */
  ret = zb_wwah_check_zdo_command(ind);
  /*cstat !MISRAC2012-Rule-2.1_b */
  /*cstat !MISRAC2012-Rule-14.3_b */
  /** @mdr{00015,9} */
  if (ret == RET_ERROR)
  {
    /* WWAH Amazon */
    TRACE_MSG(TRACE_ZDO3, "Not authorized - disable processing, drop", (FMT__0));
    skip_free_buf = 0;
  }

  /*cstat !MISRAC2012-Rule-14.3_b */
  if (ret == RET_UNAUTHORIZED)
  {
    /* R23 All Hubs */
    TRACE_MSG(TRACE_ZDO3, "Not authorized - disable processing, send status", (FMT__0));
    zb_zdo_send_status_res(param, ZB_ZDP_STATUS_NOT_AUTHORIZED);
  }
  else if (ZB_ZDO_IS_CLI_CMD(clusterid) && (skip_free_buf == 1U))
  {
#ifdef ZB_CERTIFICATION_HACKS
    if (ZB_CERT_HACKS().pass_incoming_zdo_cmd_to_app)
    {
      if (ZB_CERT_HACKS().zdo_af_handler_cb &&
          ZB_CERT_HACKS().zdo_af_handler_cb &&
          ZB_CERT_HACKS().zdo_af_handler_cb(param, clusterid))
      {
        TRACE_MSG(TRACE_ZDO3, "Incoming ZDO command is handled by application", (FMT__0));
      }
    }
    else
#endif /* ZB_CERTIFICATION_HACKS */
    {
      zb_bool_t send_default_resp;
      zb_bool_t is_interview_active;
      zb_bool_t is_dev_interview_started;
      zb_uint8_t default_status = ZB_ZDP_STATUS_NOT_SUPPORTED;

      /* Check cmd_id for R22 GU mode */
      send_default_resp = ZB_R22_GU_BEHAVIOR_ENABLED() ? zb_zdo_is_r23_cmd_id(clusterid) : ZB_FALSE;
#ifdef ZB_COORDINATOR_ROLE
      is_interview_active = zb_tc_is_interview_active_for_device(ind->src_addr);
#else
      is_interview_active = ZB_FALSE;
#endif
#ifdef ZB_JOIN_CLIENT
      is_dev_interview_started = zb_is_device_interview_started_on_joiner();
#else
      is_dev_interview_started = ZB_FALSE;
#endif

      ZVUNUSED(is_interview_active);
      TRACE_MSG(TRACE_ZDO3, "is_interview_active %hd", (FMT__H, is_interview_active));

      /* Check cmd_id for device interview */
      if (!send_default_resp
          /*cstat -MISRAC2012-Rule-2.1_b*/
          && ((ZB_IS_DEVICE_ZC() && is_interview_active)
              || (!ZB_IS_DEVICE_ZC() && is_dev_interview_started))
          /** @mdr{00012,44} */
          /*cstat +MISRAC2012-Rule-2.1_b*/
          && (!zb_zdo_cmd_id_is_valid_for_device_interview(clusterid))
        )
      {
        send_default_resp = ZB_TRUE;
        default_status = ZB_ZDP_STATUS_NOT_AUTHORIZED;
      }

      if (!send_default_resp)
      {
        /* Process client commands */
        switch (clusterid)
        {
  #ifdef ZB_ROUTER_ROLE
          case ZDO_DEVICE_ANNCE_CLID:
            if (ZB_U2B(ZB_PIBCACHE_RX_ON_WHEN_IDLE()))
            {
              zdo_device_annce_srv(param, (void *)(body + 0));
            }
            else
            {
              zb_zdo_send_status_res(param, ZB_ZDP_STATUS_NOT_SUPPORTED);
            }
          break;

          case ZDO_PARENT_ANNCE_CLID:
            if (ZB_IS_DEVICE_ZC_OR_ZR())
            {
              ret = zb_buf_get_out_delayed_ext(zdo_parent_annce_handler, param, 0);
              if (ret != RET_OK)
              {
                skip_free_buf = 0;
                TRACE_MSG(TRACE_ERROR, "Failed zb_buf_get_out_delayed [%d]", (FMT__D, ret));
              }
            }
            else
            {
              zb_zdo_send_status_res(param, ZB_ZDP_STATUS_NOT_SUPPORTED);
            }
          break;
  #endif /* ZB_ROUTER_ROLE */

          case ZDO_NODE_DESC_REQ_CLID:
          case ZDO_POWER_DESC_REQ_CLID:
            zdo_send_desc_resp(param);
          break;

          case ZDO_SIMPLE_DESC_REQ_CLID:
            zdo_send_simple_desc_resp(param);
          break;

          case ZDO_NWK_ADDR_REQ_CLID:
            zdo_device_nwk_addr_res(param, fc);
          break;

          case ZDO_IEEE_ADDR_REQ_CLID:
            zdo_device_ieee_addr_res(param, fc);
          break;

          case ZDO_ACTIVE_EP_REQ_CLID:
            zdo_active_ep_res(param);
          break;

          case ZDO_MATCH_DESC_REQ_CLID:
            zdo_match_desc_res(param);
          break;

          /* Mgmt NWK update handlers were under ZB_ROUTER_ROLE ifdef,
           * but were switched on for all devices types (for WWAH, PICS item AZD514) */
          /*
            r22 PICS AZD802
            AZD36:
            FDT1: M
            FDT2: X
            FDT3: X

            The ability for a non Network Channel Manager to receive and process
            the Mgmt_NWK_Update_-req command is mandatory for the network manager
            and all routers and optional for end devices.
           */

          case ZDO_MGMT_NWK_UPDATE_REQ_CLID:
            zb_zdo_mgmt_nwk_update_handler(param);
          break;

          case ZDO_MGMT_NWK_ENHANCED_UPDATE_REQ_CLID:
            zb_zdo_mgmt_nwk_enhanced_update_handler(param);
          break;

  #if !defined(ZB_LITE_NO_ZDO_SYSTEM_SERVER_DISCOVERY)
          case ZDO_SYSTEM_SERVER_DISCOVERY_REQ_CLID:
            zdo_system_server_discovery_res(param);
          break;
  #endif /* !defined(ZB_LITE_NO_ZDO_SYSTEM_SERVER_DISCOVERY)   */

          case ZDO_MGMT_LQI_REQ_CLID:
            zdo_lqi_resp(param);
          break;

          case ZDO_MGMT_RTG_REQ_CLID:
            zdo_mgmt_rtg_resp(param);
          break;

          case ZDO_MGMT_BIND_REQ_CLID:
            zdo_mgmt_bind_resp(param);
          break;

          case ZDO_MGMT_LEAVE_REQ_CLID:
            zdo_mgmt_leave_srv(param);
          break;

          case ZDO_MGMT_NWK_BEACON_SURVEY_REQ_CLID:
            zdo_mgmt_beacon_survey_req_handler(param);
          break;

  #if (defined ZB_JOINING_LIST_SUPPORT) && defined(ZB_ROUTER_ROLE)
          case ZDO_MGMT_NWK_IEEE_JOINING_LIST_REQ_CLID:
            zdo_nwk_joining_list_resp(param);
          break;
  #endif /* (defined ZB_JOINING_LIST_SUPPORT) && defined(ZB_ROUTER_ROLE) */

          case ZDO_BIND_REQ_CLID:
            zb_zdo_bind_unbind_res(param, ZB_TRUE);
          break;

          case ZDO_UNBIND_REQ_CLID:
            zb_zdo_bind_unbind_res(param, ZB_FALSE);
          break;

          case ZDO_CLEAR_ALL_BIND_REQ_CLID:
            zb_zdo_clear_all_bind_res(param);
          break;

          case ZDO_SECURITY_SET_CONFIGURATION_REQ_CLID:
            zb_zdo_set_configuration_res(param);
          break;

          case ZDO_SECURITY_GET_CONFIGURATION_REQ_CLID:
            zb_zdo_get_configuration_res(param);
          break;

          case ZDO_SECURITY_DECOMMISSION_REQ_CLID:
            zb_zdo_decommission_res(param);
          break;

          case ZDO_SECURITY_FRAME_CNT_CHALLENGE_REQ_CLID:
            zb_zdo_secur_challenge_req_handle(param);
          break;

#ifndef R23_DISABLE_DEPRECATED_ZDO_CMDS
          case ZDO_END_DEVICE_BIND_REQ_CLID:
            zb_zdo_end_device_bind_handler(param);
          break;
#endif /* R23_DISABLE_DEPRECATED_ZDO_CMDS */

#ifdef ZB_FIXED_OPTIONAL_DESC_RESPONSES
          case ZDO_COMPLEX_DESC_REQ_CLID:
            zb_zdo_send_complex_desc_resp(param);
          break;

          case ZDO_USER_DESC_REQ_CLID:
            zb_zdo_send_user_desc_resp(param);
          break;

#ifndef R23_DISABLE_DEPRECATED_ZDO_CMDS
          case ZDO_USER_DESC_SET_CLID:
            zb_zdo_send_user_desc_conf(param);
          break;
#endif /* R23_DISABLE_DEPRECATED_ZDO_CMDS */
#endif /* ZB_FIXED_OPTIONAL_DESC_RESPONSES */

#ifdef ZB_ROUTER_ROLE
          case ZDO_MGMT_PERMIT_JOINING_CLID:
            if (ZB_IS_DEVICE_ZC_OR_ZR())
            {
              zb_zdo_mgmt_permit_joining_handle(param);
            }
          break;
#endif /* ZB_ROUTER_ROLE */

#ifdef ZB_COORDINATOR_ROLE
          case ZDO_SECURITY_START_KEY_NEGOTIATION_REQ_CLID:
             zb_zdo_secur_start_key_negotiation_req_handle(param);
          break;

          case ZDO_SECURITY_GET_AUTH_TOKEN_REQ_CLID:
#if defined ZB_CERTIFICATION_HACKS
            if (ZB_CERT_HACKS().zdo_disable_auth_token_rsp)
            {
              zb_buf_free(param);
            }
            else
#endif /* ZB_CERTIFICATION_HACKS */
            {
              zb_zdo_secur_get_authentication_token_req_handle(param);
            }
          break;
#endif /* ZB_COORDINATOR_ROLE */

          case ZDO_SECURITY_GET_AUTH_LEVEL_REQ_CLID:
            zb_zdo_secur_get_auth_level_req_handle(param);
          break;

#ifdef ZB_JOIN_CLIENT
          case ZDO_SECURITY_START_KEY_UPDATE_REQ_CLID:
            zb_zdo_secur_start_key_update_req_handle(param);
          break;
#endif  /* ZB_JOIN_CLIENT */

          default:
            /* Not supported command handling */
            send_default_resp = ZB_TRUE;
            break;
        } /* switch */
      }

      if (send_default_resp)
      {
        if(!ZB_NWK_IS_ADDRESS_BROADCAST(ind->dst_addr))
        {
          zb_zdo_send_status_res(param, default_status);
        }
        else
        {
          TRACE_MSG(TRACE_ZDO3, "Unsupported broadcast cli cmd - drop", (FMT__0));
          skip_free_buf = 0;
        }
      }
    }
  } /* if ZB_ZDO_IS_CLI_CMD(clusterid) */
  else
  {
    /* Process server commands */
#ifndef ZB_LITE_NO_ZDO_RESPONSE_VALIDATION
    if (!zb_zdo_validate_reponse(param, clusterid))
    {
      TRACE_MSG(TRACE_ZDO3, "dropped malformed zdo response", (FMT__0));
      skip_free_buf = 0;
    } else
#endif /* ZB_LITE_NO_ZDO_RESPONSE_VALIDATION */
    {
      switch (clusterid)
      {
        case ZDO_NODE_DESC_RESP_CLID:
        case ZDO_POWER_DESC_RESP_CLID:
        case ZDO_MGMT_PERMIT_JOINING_RESP_CLID:
        case ZDO_NWK_ADDR_RESP_CLID:
        case ZDO_ACTIVE_EP_RESP_CLID:
        case ZDO_IEEE_ADDR_RESP_CLID:
        case ZDO_MATCH_DESC_RESP_CLID:
        case ZDO_MGMT_LEAVE_RESP_CLID:
        case ZDO_MGMT_LQI_RESP_CLID:
        case ZDO_BIND_RESP_CLID:
        case ZDO_UNBIND_RESP_CLID:
        case ZDO_CLEAR_ALL_BIND_RESP_CLID:
        case ZDO_SECURITY_SET_CONFIGURATION_RESP_CLID:
        case ZDO_SECURITY_DECOMMISSION_RESP_CLID:
#ifndef R23_DISABLE_DEPRECATED_ZDO_CMDS
        case ZDO_END_DEVICE_BIND_RESP_CLID:
#endif /* R23_DISABLE_DEPRECATED_ZDO_CMDS */
        case ZDO_MGMT_RTG_RESP_CLID:
        case ZDO_MGMT_BIND_RESP_CLID:
        case ZDO_MGMT_NWK_ENHANCED_UPDATE_NOTIFY_CLID:
        case ZDO_SECURITY_GET_AUTH_LEVEL_RESP_CLID:
        case ZDO_SECURITY_START_KEY_UPDATE_RESP_CLID:
          zb_zdo_common_response_handler(param, &skip_free_buf);
          break;

        case ZDO_SECURITY_FRAME_CNT_CHALLENGE_RESP_CLID:
          zb_zdo_secur_challenge_resp_handle(param);
          break;

        case ZDO_MGMT_NWK_BEACON_SURVEY_RESP_CLID:
#if defined ZB_ROUTER_ROLE
          if (ZB_IS_DEVICE_ZC_OR_ZR())
          {
            /* Before calling user's callback analyze ZB_TLV_PANID_CONFLICT_REPORT TLV */
            zdo_beacon_survey_hook(param);
          }
#endif /* ZB_ROUTER_ROLE && ZB_BEACON_SURVEY */
          zb_zdo_beacon_survey_resp_handler(param);
          break;

        case ZDO_SECURITY_GET_CONFIGURATION_RESP_CLID:
#ifdef ZB_ROUTER_ROLE
          if (ZB_IS_DEVICE_ZC_OR_ZR())
          {
            /* Before calling user's callback analyze ZB_TLV_PANID_CONFLICT_REPORT TLV */
            zdo_secur_get_config_rsp_hook(param);
          }
#endif
          zb_zdo_common_response_handler(param, &skip_free_buf);
          break;

#ifdef ZB_ROUTER_ROLE
        case ZDO_PARENT_ANNCE_RESP_CLID:
          /* Call PARENT_ANNCE_RESP handler */
          zb_parent_annce_resp_handler(param,(void *)(body + 0));
        break;

        case ZDO_MGMT_NWK_UPDATE_NOTIFY_CLID:
        /* nwk update notify can be received without request, so zdo_af_resp()
         can return error - no callback for response */
          ret = zdo_af_resp(param);
          if (ret != RET_OK)
          {
            zb_zdo_mgmt_handle_unsol_nwk_update_notify(param);
          }
        break;
#endif /* ZB_ROUTER_ROLE */

#if defined ZB_JOINING_LIST_SUPPORT && defined ZB_ROUTER_ROLE
        case ZDO_MGMT_NWK_IEEE_JOINING_LIST_RESP_CLID:
          zb_nwk_ieee_joining_list_resp_handler(param);
        break;
#endif /* ZB_JOINING_LIST_SUPPORT && ZB_ROUTER_ROLE */

#if defined ZB_SUBGHZ_BAND_ENABLED && defined ZB_ROUTER_ROLE
        case ZDO_MGMT_NWK_UNSOLICITED_ENHANCED_UPDATE_NOTIFY_CLID:
          zb_zdo_mgmt_unsol_enh_nwk_update_notify_handler(param);
        break;
#endif /* (defined ZB_SUBGHZ_BAND_ENABLED) && defined(ZB_ROUTER_ROLE) */

        case ZDO_SIMPLE_DESC_RESP_CLID:
          /*  convert payload from ZibBee ZDO format to ZBOSS ZDO format */
          /* Skip response with malformed descriptor in payload */
          ret = zb_zdo_simple_desc_resp_convert_zboss(param);

          if (ret == RET_OK)
          {
            ret = RET_IGNORE;
            if(ZG->zdo.zb_zdo_responce_cb !=NULL)
            {
              ret = (ZG->zdo.zb_zdo_responce_cb)(param, clusterid);
            }

            if( ret != RET_OK)
            {
              ret = zdo_af_resp(param);
            }
          }

          /* do not free buffer if callback was found */
          skip_free_buf = ZB_B2U(ret == RET_OK);
        break;

#ifdef ZB_JOIN_CLIENT
        case ZDO_SECURITY_START_KEY_NEGOTIATION_RESP_CLID:
          zb_zdo_secur_start_key_negotiation_rsp_handle(param);
        break;

        case ZDO_SECURITY_GET_AUTHENTICATION_TOKEN_RESP_CLID:
          zb_zdo_secur_get_authentication_token_rsp_handle(param);
        break;
#endif /* ZB_JOIN_CLIENT */

#if !defined(ZB_LITE_NO_ZDO_SYSTEM_SERVER_DISCOVERY)
        case ZDO_SYSTEM_SERVER_DISCOVERY_RESP_CLID:
          zb_zdo_system_server_discovery_resp_handle(param, &skip_free_buf);
          break;
#endif  /* !ZB_LITE_NO_ZDO_SYSTEM_SERVER_DISCOVERY */

        default:
          TRACE_MSG(TRACE_ZDO1, "unhandl clu 0x%x - drop", (FMT__D, clusterid));
          skip_free_buf = 0;
          break;
      } /* switch */
    }
  }

  TRACE_MSG(TRACE_ZDO3, "skip_free_buf %hd", (FMT__H, skip_free_buf));
  if (!ZB_U2B(skip_free_buf))
  {
    zb_buf_free(param);
  }
}


void zb_zdo_register_device_annce_cb(zb_device_annce_cb_t cb)
{
  TRACE_MSG(TRACE_ZDO1, "zb_zdo_register_device_annce_cb cb %p", (FMT__P, cb));
  ZG->zdo.device_annce_cb = cb;
}

void zb_zdo_register_zb_zdo_responce_cb(zb_zdo_responce_cb_t cb)
{
  TRACE_MSG(TRACE_ZDO1, "zb_zdo_register_zb_zdo_responce_cb cb %p", (FMT__P, cb));
  ZG->zdo.zb_zdo_responce_cb = cb;
}

#if (defined ZB_JOINING_LIST_SUPPORT) && defined(ZB_ROUTER_ROLE)

/* handling mlme-set.confirm */
static void zb_nwk_ieee_joining_list_resp_handler_cont_cont(zb_uint8_t param)
{
  zb_mlme_set_confirm_t *set_confirm;

  TRACE_MSG(TRACE_ZDO2, ">> zb_nwk_ieee_joining_list_resp_handler_cont_cont %hd", (FMT__H, param));

  ZB_ASSERT(zb_buf_len(param) >= sizeof(*set_confirm));
  set_confirm = (zb_mlme_set_confirm_t *) zb_buf_begin(param);

  if (set_confirm->status == MAC_SUCCESS)
  {
    TRACE_MSG(TRACE_ZDO2, "list updated successfully %hd", (FMT__H, param));
  }
  else
  {
    zb_zdo_mgmt_nwk_ieee_joining_list_rsp_t * resp;
    /* setting failure status */
    resp = (zb_zdo_mgmt_nwk_ieee_joining_list_rsp_t *) zb_buf_begin(ZDO_CTX().joining_list_ctx.original_buffer);
    resp->status = ZB_ZDP_STATUS_NOT_PERMITTED;

    TRACE_MSG(TRACE_ZDO2, "mlme-set failed(%hd)", (FMT__H, set_confirm->status));
  }

  if (zdo_af_resp(ZDO_CTX().joining_list_ctx.original_buffer) != RET_OK)
  {
    zb_buf_free(ZDO_CTX().joining_list_ctx.original_buffer);
  }

  zb_buf_free(param);

  TRACE_MSG(TRACE_ZDO2, "<< zb_nwk_ieee_joining_list_resp_handler_cont_cont", (FMT__0));
}

/* Preparing mlme-set.req */
static void zb_nwk_ieee_joining_list_resp_handler_cont(zb_uint8_t param)
{
  zb_zdo_mgmt_nwk_ieee_joining_list_rsp_t *resp;
  zb_mlme_set_request_t *set_req;
  zb_mlme_set_ieee_joining_list_req_t *set_req_param;
  void *ptr;
  zb_uint8_t addr_list_size;

  TRACE_MSG(TRACE_ZDO2, ">> zb_nwk_ieee_joining_list_resp_handler_cont %hd", (FMT__H, param));
  TRACE_MSG(TRACE_ZDO2, "orig buffer: %hd", (FMT__H, ZDO_CTX().joining_list_ctx.original_buffer));

  resp = (zb_zdo_mgmt_nwk_ieee_joining_list_rsp_t *)zb_buf_begin(ZDO_CTX().joining_list_ctx.original_buffer);

  ZDO_CTX().joining_list_ctx.update_id = resp->ieee_joining_list_update_id;

  addr_list_size = resp->ieee_joining_count * (zb_uint8_t)sizeof(zb_ieee_addr_t);
  ptr = zb_buf_initial_alloc(param,
                             sizeof(*set_req) + sizeof(*set_req_param) + addr_list_size);

  set_req = (zb_mlme_set_request_t *)ptr;
  set_req->pib_attr = ZB_PIB_ATTRIBUTE_JOINING_IEEE_LIST;
  set_req->pib_length = (zb_uint8_t)sizeof(zb_mlme_set_ieee_joining_list_req_t) + addr_list_size;
  set_req->iface_id = ZB_NWK_MULTIMAC_ALL_INTERFACES;
  set_req->confirm_cb_u.cb = &zb_nwk_ieee_joining_list_resp_handler_cont_cont;

  set_req_param = (zb_mlme_set_ieee_joining_list_req_t *)(void *)(set_req + 1);
  set_req_param->op_type = (zb_uint8_t)ZB_MLME_SET_IEEE_JL_REQ_RANGE;
  set_req_param->param.range_params.joining_policy = resp->joining_policy;
  set_req_param->param.range_params.start_index = resp->start_index;
  set_req_param->param.range_params.list_size = resp->ieee_joining_list_total;
  set_req_param->param.range_params.items_count = resp->ieee_joining_count;

  ZB_MEMCPY((zb_uint8_t *)ptr + sizeof(*set_req) + sizeof(*set_req_param),
            (zb_uint8_t *)(resp + 1),
            addr_list_size);

  ZB_SCHEDULE_CALLBACK(zb_multimac_mlme_set_request_proxy, param);

  TRACE_MSG(TRACE_ZDO2, "<< zb_nwk_ieee_joining_list_resp_handler_cont", (FMT__0));
}

/*
 * @see 2.4.4.4.11 of r22 Zigbee spec
 */
static void zb_nwk_ieee_joining_list_resp_handler(zb_uint8_t param)
{
  zb_bool_t ret = ZB_TRUE;
  zb_uint8_t left_len;
  zb_zdo_mgmt_nwk_ieee_joining_list_rsp_t *resp;

  TRACE_MSG(TRACE_ZDO1, ">> zb_nwk_ieee_joining_list_resp_handler %hd", (FMT__H, param));

  resp = (zb_zdo_mgmt_nwk_ieee_joining_list_rsp_t *)zb_buf_begin(param);
  if (resp->status != (zb_uint8_t)ZB_ZDP_STATUS_SUCCESS)
  {
    TRACE_MSG(TRACE_ZDO3, "expected zdp status to be ZB_ZDP_STATUS_SUCCESS", (FMT__0));
    ret = ZB_FALSE;
  }
  else if (zb_buf_len(param) < sizeof(*resp))
  {
    /* otherwise the full zb_zdo_mgmt_nwk_ieee_joining_list_rsp_t is expected */
    ret = ZB_FALSE;
    TRACE_MSG(TRACE_ZDO3, "insufficient buffer length", (FMT__0));
  }
  else if (ZB_U2B(ZB_AIB().aps_designated_coordinator))
  {
    ret = ZB_FALSE;
    TRACE_MSG(TRACE_ZDO3, "coordinators are not supposed to handle this resp", (FMT__0));
  }
  else
  {
    /* MISRA rule 15.7 requires empty 'else' branch. */
  }

  if (ret)
  {
    zb_size_t u32len = zb_buf_len(param) - sizeof(*resp);
    left_len = (zb_uint8_t)u32len;

    /* checking payload */
    ret = (zb_bool_t)(left_len >= (resp->ieee_joining_count * sizeof(zb_ieee_addr_t)));

    /* checking new joining policy value */
    switch (resp->joining_policy)
    {
      case ZB_MAC_JOINING_POLICY_NO_JOIN:
      case ZB_MAC_JOINING_POLICY_ALL_JOIN:
      case ZB_MAC_JOINING_POLICY_IEEELIST_JOIN:
        /* ok */
        break;
      default:
        /* no such policy */
        ret = ZB_FALSE;
        break;
    }
  }

  if (ret)
  {
    /* in order to make mlme-set.req we need to get a new buffer */
    ZDO_CTX().joining_list_ctx.original_buffer = param;
    ret = zb_buf_get_out_delayed(zb_nwk_ieee_joining_list_resp_handler_cont) == RET_OK ? ZB_TRUE : ZB_FALSE;
    TRACE_MSG(TRACE_ZDO3, "preparing mlme-set", (FMT__0));
  }

  if (!ret)
  {
    TRACE_MSG(TRACE_ZDO3, "malformed response", (FMT__0));

    /* setting failure status */
    resp = (zb_zdo_mgmt_nwk_ieee_joining_list_rsp_t *) zb_buf_begin(param);
    if (resp->status == (zb_uint8_t)ZB_ZDP_STATUS_SUCCESS)
    {
      resp->status = ZB_ZDP_STATUS_NOT_PERMITTED;
    }

    /* passing to caller */
    if (zdo_af_resp(param) != RET_OK)
    {
      zb_buf_free(param);
    }
  }

  TRACE_MSG(TRACE_ZDO1, "<< zb_nwk_ieee_joining_list_resp_handler (res %hd)", (FMT__H, ret));
}

#endif /* (defined ZB_JOINING_LIST_SUPPORT) && defined(ZB_ROUTER_ROLE) */

#ifdef ZB_ROUTER_ROLE

void zdo_parent_annce_handler(zb_uint8_t param, zb_uint16_t param_req)
{
  zb_uint8_t status = (zb_uint8_t)ZB_ZDP_STATUS_SUCCESS;

  zb_neighbor_tbl_ent_t *nbt = NULL;
  zb_uindex_t i;
  zb_ieee_addr_t ieee_address_req;
  zb_ieee_addr_t *ieee_address_rsp;

  zb_apsde_data_indication_t ind;
  zb_uint8_t need_secur;
  zb_zdo_parent_annce_t req;
  zb_zdo_parent_annce_rsp_t *rsp;
  zb_uint8_t *aps_body;
  zb_uint8_t u8_param_req = (zb_uint8_t)param_req;

  TRACE_MSG(TRACE_ZDO1, ">> zdo_parent_annce_srv resp_buf  %d, req_buf %d", (FMT__D_D,param, param_req));

  if (zb_buf_len(u8_param_req) < sizeof(req))
  {
    TRACE_MSG(TRACE_ZDO1, "parent_annce: malformed packet", (FMT__0));
    zb_buf_free(u8_param_req);
    return;
  }

  aps_body = zb_buf_begin(u8_param_req);
  aps_body++;
  req.num_of_children = *aps_body;
  aps_body++;

  if (zb_buf_len(u8_param_req) < (sizeof(req) + sizeof(zb_ieee_addr_t)*req.num_of_children))
  {
    TRACE_MSG(TRACE_ZDO1, "parent_annce: malformed packet, broken ChildInfo array", (FMT__0));
    zb_buf_free(u8_param_req);
    return;
  }

  ZB_MEMCPY(&ind, ZB_BUF_GET_PARAM(u8_param_req, zb_apsde_data_indication_t), sizeof(ind));
  need_secur = ZB_APS_FC_GET_SECURITY(ind.fc);

/*      2.4.3.1.12 Parent_annce
-	Reset timer for our own Parent_annce, if any
-       A router shall construct an empty Parent_Annce_Rsp message with
        NumberOfChildren set to 0.
-       Examine each Extended Address present in the message and search
        its Neighbor Table for an Extended Address entry that matches. For each
        match, process as follows:
        1. If the Device Type is Zigbee End Device (0x02) and the Keepalive
           Received value is TRUE, do the following:
           a. It shall append to the Parent_annce_rsp frame the ChildInfo structure.
           b. Increment the NumberOfChildren by 1.
        2. If the Device Type is not Zigbee End Device (0x02) or the Keepalive
           Received value is FALSE, do not process any further. Continue to the
           next entry.

-       If the NumberOfChildren field value is 0, the local device shall discard
        the previously constructed Parent_Annce_rsp. No response message shall
        be sent.

-       If the NumberOfChildren field in the Parent_Annce_rsp is greater than 0,
        it shall unicast the message to the sender of the Parent_Annce message.

-	Send Parent_annce_rsp unicast to the Parent_annce sender; maybe, split
        to more than 1 message.
*/


  if (ZB_IS_DEVICE_ZC_OR_ZR())
  {
    if (zb_schedule_alarm_cancel(zdo_send_parent_annce,0, NULL) == RET_OK)
    {
      TRACE_MSG(TRACE_ZDO1, "Re-Schedule oun zdo_send_parent_annce ", (FMT__0));
      ZB_SCHEDULE_ALARM(zdo_send_parent_annce, 0, ZB_PARENT_ANNCE_JITTER());
    }

    rsp = zb_buf_initial_alloc(param, sizeof(zb_zdo_parent_annce_rsp_t));
    rsp->hdr.status = status;
    rsp->hdr.num_of_children = 0;

/*    Examine each Extended Address present in the message and search
      its Neighbor Table for an Extended Address entry that matches. For each
      match, process as follows:
*/

    for(i = 0; i < req.num_of_children; i++)
    {
      ZB_MEMCPY(&ieee_address_req, aps_body, sizeof(ieee_address_req));
      aps_body += sizeof(zb_ieee_addr_t);

      if (zb_nwk_neighbor_get_by_ieee(ieee_address_req, &nbt) == RET_OK)
      {
        TRACE_MSG(TRACE_NWK2, "device is in the neighbor table", (FMT__0));
/*
  If the Device Type is Zigbee End Device (0x02) and the Keepalive
  Received value is TRUE, do the following:
  a. It shall append to the Parent_annce_rsp frame the ChildInfo structure.
  b. Increment the NumberOfChildren by 1.
  If the Device Type is not Zigbee End Device (0x02) or the Keepalive
  Received value is FALSE, do not process any further. Continue to the
  next entry.
*/
        if (nbt->device_type == ZB_NWK_DEVICE_TYPE_ED)
        {
          if (ZB_U2B(nbt->dev.ed.keepalive_received))
          {
            rsp->hdr.num_of_children++;
            ieee_address_rsp = zb_buf_alloc_right(param, sizeof(zb_ieee_addr_t));
            zb_address_ieee_by_ref(*ieee_address_rsp, nbt->addr_ref);
            TRACE_MSG(TRACE_ZDO1, "Add entry %p in response", (FMT__P, nbt->addr_ref));
          }
          else
          {
/*Delete entry from the NBT*/
            zb_ret_t ret = zb_nwk_neighbor_delete(nbt->addr_ref);
            if (ret == RET_OK)
            {
              TRACE_MSG(TRACE_ZDO1, "Delete entry %p from the NBT", (FMT__P, nbt->addr_ref));
            }
            else
            {
              TRACE_MSG(TRACE_ERROR, "zb_nwk_neighbor_delete addr_ref not found [%d]", (FMT__D, ret));
              ZB_ASSERT(0);
            }
          }
        } /*If (nbt->device_type == ZB_NWK_DEVICE_TYPE_ED)*/
      } /*Found NBT entry with long address form the parent announce*/
    } /*For all instances from parent_annce*/
    if (rsp->hdr.num_of_children != 0U)
    {
      /*Send response*/
      zdo_send_resp_by_short(ZDO_PARENT_ANNCE_RESP_CLID, param, ind.src_addr, ZB_U2B(need_secur));
    }
    else
    {
      /*Don't send parent_annce_resp, free buffer*/
      zb_buf_free(param);
      TRACE_MSG(TRACE_ZDO1, "zb_parent_annce_resp is empty, does not send response", (FMT__0));
    }
    zb_buf_free(u8_param_req); /*Free request buffer*/
  } /*If we are a router or coordinator*/
  TRACE_MSG(TRACE_ZDO1, "<< zdo_parent_annce_srv", (FMT__0));
}


static void zb_parent_annce_resp_handler(zb_uint8_t param, void *dt)
{
  zb_neighbor_tbl_ent_t *nbt = NULL;
  zb_ieee_addr_t ieee_addr;
  zb_zdo_parent_annce_rsp_t rsp;
  zb_uint8_t *aps_body;
  zb_uindex_t i;

  /* Unused without trace. */
  ZVUNUSED(dt);
  TRACE_MSG(TRACE_ZDO1, ">> zb_parent_annce_resp_handler %p", (FMT__P, dt));

/* 2.4.4.2.22.2 On receipt of a Parent_annce_rsp, the device shall examine its
 * Neighbor Table for each extended address in the ChildInfo entry and do the
 * following.
 * If the entry matches and the Device Type is Zigbee End Device (0x02), it shall
 * delete the entry from the Neighbor table.
 * If the entry does not match, no more processing is performed on this ChildInfo
 * entry.
 * There is no message generated in response to a Parent_annce_rsp.
*/

  aps_body = zb_buf_begin(param);
  aps_body++;
  rsp.hdr.status = *aps_body;
  aps_body++;
  rsp.hdr.num_of_children = *aps_body;
  aps_body++;

  if (zb_buf_len(param) < (sizeof(rsp) + rsp.hdr.num_of_children * sizeof(zb_ieee_addr_t)))
  {
    TRACE_MSG(TRACE_ZDO1, "malformed packet", (FMT__0));
    zb_buf_free(param);
    return;
  }


  for(i = 0; i < rsp.hdr.num_of_children; i++)
    {
    ZB_MEMCPY(&ieee_addr, aps_body, sizeof(ieee_addr));
      aps_body += sizeof(zb_ieee_addr_t);

      if (zb_nwk_neighbor_get_by_ieee(ieee_addr, &nbt) == RET_OK)
      {
        TRACE_MSG(TRACE_NWK2, "device is in the neighbor table", (FMT__0));
        if (nbt->device_type == ZB_NWK_DEVICE_TYPE_ED)
        {
          zb_ret_t ret = zb_nwk_neighbor_delete(nbt->addr_ref);
          if (ret == RET_OK)
          {
            TRACE_MSG(TRACE_ZDO1, "Delete entry %p from the NBT", (FMT__P, nbt->addr_ref));
          }
          else
          {
            TRACE_MSG(TRACE_ERROR, "zb_nwk_neighbor_delete addr_ref not found [%d]", (FMT__D, ret));
            ZB_ASSERT(0);
          }
        }
      }
    }
  zb_buf_free(param);
  TRACE_MSG(TRACE_ZDO1, "<< zb_parent_annce_resp_handler", (FMT__0));
}

static void zdo_device_annce_srv(zb_uint8_t param, void *dt)
{
  zb_zdo_device_annce_t da;
  zb_nwk_neighbor_element_t ne = { 0 };
  zb_address_ieee_ref_t addr_ref;
  zb_bool_t unicast = ZB_FALSE;   /* assign initial value for static analyzers and/or very "smart" compilers */
  zb_bool_t neighbor = ZB_FALSE;

  TRACE_MSG(TRACE_ZDO1, ">> zdo_device_annce_srv %p", (FMT__P, dt));

  if (zb_buf_len(param) < sizeof(da))
  {
    TRACE_MSG(TRACE_ZDO1, "dev_annce: malformed packet", (FMT__0));
    zb_buf_free(param);
    return;
  }

  /* Device annce parameters are in the buffer head.
     Need to copy these parameters to the internal variable because
     at the end of the function we pack the DEVICE_ANNCE signal that
     performs the initial alloc of the buffer and parameters may be lost.
   */
  ZB_MEMCPY(&da, dt, sizeof(da));
  ZB_LETOH16_ONPLACE(da.nwk_addr);

  TRACE_MSG(TRACE_ZDO1, "zdo_device_annce_srv %d=0x%x ieee=" TRACE_FORMAT_64 " cap=%d ",
            (FMT__D_D_A_D, da.tsn, da.nwk_addr, TRACE_ARG_64(da.ieee_addr), da.capability));

  if (ZB_NWK_IS_ADDRESS_BROADCAST(da.nwk_addr))
  {
    TRACE_MSG(TRACE_ERROR, "Broadcast address 0x%x received in device annce for device " TRACE_FORMAT_64,
              (FMT__D_A, da.nwk_addr, TRACE_ARG_64(da.ieee_addr)));
    zb_buf_free(param);
    return;
  }

#ifdef ZB_ENABLE_ZGP
  zgp_handle_dev_annce(&da);
#endif /* ZB_ENABLE_ZGP */

#if defined ZB_PRO_STACK && defined ZB_ROUTER_ROLE
  /* #AT: cross stack compatibility */
  if (ZB_IS_DEVICE_ZC_OR_ZR())
  {
    /* Test for address conflict */
    if (zb_nwk_test_dev_annce(da.nwk_addr, da.ieee_addr) != RET_OK)
    {
      TRACE_MSG(TRACE_NWK1, "dev_annce: address conflict", (FMT__0));
      zb_buf_free(param);
      return;
    }
  }
#endif

  if (ZB_IS_DEVICE_ZC_OR_ZR())
  {
    zb_apsde_data_indication_t *ind = (zb_apsde_data_indication_t *)ZB_BUF_GET_PARAM(param, zb_apsde_data_indication_t);

    neighbor = (ind->mac_src_addr == da.nwk_addr)?(ZB_TRUE):(ZB_FALSE);
    unicast = ( (ind->mac_dst_addr != ZB_NWK_BROADCAST_ALL_DEVICES) )?(ZB_TRUE):(ZB_FALSE);

    TRACE_MSG(TRACE_ZDO1, "mac src addr 0x%x mac dst addr 0x%x addr 0x%x neighbor %hd unicast %hd",
              (FMT__D_D_D_H_H, ind->mac_src_addr, ind->mac_dst_addr, da.nwk_addr, neighbor, unicast));
  }

  /*
    First detect former child.
    For 2007 profile is is simple: short address is changed.
    No ideas for PRO: see 2.5.5.5.4.3:
    "ZDO shall arrange that any IEEE address to short
    address mappings which have become known to applications running on this
    device be updated. This behavior is mandatory, but the mechanism by which it is
    achieved is outside the scope of this specification."
  */

  /* There can be 0xFF..FF address - in this case it will be
   * impossible to find an entry */
  if (ZB_IS_DEVICE_ZC_OR_ZR()
      && !ZB_IEEE_ADDR_IS_UNKNOWN(da.ieee_addr))
  {
    if (zb_address_by_ieee(da.ieee_addr, ZB_FALSE, ZB_FALSE, &addr_ref) == RET_OK)
    {
      zb_uint8_t relationship;
      zb_uint16_t old_short;

      zb_address_short_by_ref(&old_short, addr_ref);
      relationship = zb_nwk_get_nbr_rel_by_short(old_short);
      if (old_short != (zb_uint16_t)~0U
          && (relationship == ZB_NWK_RELATIONSHIP_CHILD
              || relationship == ZB_NWK_RELATIONSHIP_UNAUTHENTICATED_CHILD))
      {
        if (old_short != da.nwk_addr
            /*
             * if we got broadcast device annonce from our child - ED, it means this is not our
             * child any more. It works for PRO as well.
             * It works because briadcasts about ED-child will be dropped at NWK as dups.
             */

            /*cstat -MISRAC2012-Rule-13.5 */
            /* After some investigation, the following violation of Rule 13.5 seems to be a false
             * positive. There are no side effects to 'zb_nwk_get_nbr_dvc_type_by_short()'.
             * This violation seems to be caused by the fact that this function is an external
             * function, which cannot be analyzed by C-STAT. */
            || (!unicast
                && zb_nwk_get_nbr_dvc_type_by_short(old_short) == ZB_NWK_DEVICE_TYPE_ED))
            /*cstat +MISRAC2012-Rule-13.5 */
        {
          /* It was our child, now its address has changed - it is previous child */
          /* Device remains on network - do not forget it (app data) */
          ZB_SCHEDULE_CALLBACK2(zdo_device_removed, addr_ref, ZB_FALSE);
          /* There was mark as previous child. It causes problems with routing and
           * really not used.
           * Remove neighbor entry.
           */
          TRACE_MSG(TRACE_ZDO1, "delete 0x%x from neighbor", (FMT__D, da.nwk_addr));
        }
      }
    }
  }

  if (zb_address_update(da.ieee_addr, da.nwk_addr, ZB_FALSE, &addr_ref) == RET_OK)
  {
    /* check if it's a neighbor mac_addr == nwk_addr */
    if (neighbor)
    {
      if (zb_nwk_get_neighbor_element(da.nwk_addr, ZB_TRUE, &ne) == RET_OK)
      {
        TRACE_MSG(TRACE_ZDO1, "update/add neighbor 0x%x", (FMT__D, da.nwk_addr));
      }
      else
      {
        neighbor = ZB_FALSE;
        TRACE_MSG(TRACE_ZDO1, "seems device %d is not our neighbor", (FMT__D, da.nwk_addr));
      }
    }
  }

  if (neighbor)
  {
    zb_ret_t ret;
    zb_bool_t was_unknown = (ne.device_type == ZB_NWK_DEVICE_TYPE_NONE);

    if (ne.device_type == ZB_NWK_DEVICE_TYPE_NONE
        || ne.relationship == ZB_NWK_RELATIONSHIP_PREVIOUS_CHILD)
    {
      ne.device_type = ZB_U2B(ZB_MAC_CAP_GET_DEVICE_TYPE(da.capability)) ? ZB_NWK_DEVICE_TYPE_ROUTER : ZB_NWK_DEVICE_TYPE_ED;
    }
    ne.rx_on_when_idle = ZB_U2B(ZB_MAC_CAP_GET_RX_ON_WHEN_IDLE(da.capability));
    /* It was our child, now its address has changed - it is previous child */
    if (ZB_IS_DEVICE_ZC_OR_ZR()
        && ne.relationship == ZB_NWK_RELATIONSHIP_NONE_OF_THE_ABOVE
        && ZB_U2B(ZB_MAC_CAP_GET_DEVICE_TYPE(da.capability)))
    {
      /* relationship was unknown, both our and remote device are Routers, we got this
       * packet - this is our sibling */
      ne.relationship = ZB_NWK_RELATIONSHIP_SIBLING;
    }
    if ((ne.relationship == ZB_NWK_RELATIONSHIP_CHILD
         || ne.relationship == ZB_NWK_RELATIONSHIP_UNAUTHENTICATED_CHILD))
    {
#ifndef ZB_PRO_STACK
      if (ZB_NIB().depth < ZB_NIB_MAX_DEPTH())
#endif
      {
        ne.depth = ZB_NIB().depth + 1U;
      }
    }
    if (ne.device_type == ZB_NWK_DEVICE_TYPE_ED)
    {
      ne.permit_joining = 0;
    }

    if (was_unknown)
    {
      zb_bool_t is_router = (ne.device_type == ZB_NWK_DEVICE_TYPE_ROUTER);

      /** It must be no longer unknown */
      ZB_ASSERT(ne.device_type != ZB_NWK_DEVICE_TYPE_NONE);

      /** Increments are symmetric to decrements in zb_nwk_neighbor_delete */
      if (ne.device_type == ZB_NWK_DEVICE_TYPE_ED)
      {
        zb_nwk_nbt_inc_child_num(is_router);
      }
      else
      {
        if (ne.relationship == ZB_NWK_RELATIONSHIP_CHILD ||
            ne.relationship == ZB_NWK_RELATIONSHIP_UNAUTHENTICATED_CHILD)
        {
          zb_nwk_nbt_inc_child_num(is_router);
        }
      }
    }

    TRACE_MSG(TRACE_ZDO3, "DEV_ANNCE: /0x%x ne %p dev_t %hd, rx.o.i %hd rel %hd ieee " TRACE_FORMAT_64,
        (FMT__A_D_P_H_H_H, da.nwk_addr, &ne, ne.device_type,
        ne.rx_on_when_idle, ne.relationship, TRACE_ARG_64(da.ieee_addr)));

    ret = zb_nwk_set_neighbor_element(da.nwk_addr, &ne);
    ZB_ASSERT(ret == RET_OK);
  }


  /* Device joined, delete dlk_ctx. ZC deletes dlk ctx after auth_token frame */
  if (ZB_IS_DEVICE_ZR() || ZB_IS_TC())
  {
    zb_secur_ecdhe_common_ctx_t *ecdhe_ctx = zb_zdo_ecdhe_common_ctx_get_by_ieee(da.ieee_addr);
    if (ecdhe_ctx != NULL)
    {
      // If device is zr then always delete ecdhe context, or delete on dlk finish.
      // Context shall have state ZB_SECUR_KEY_NEGOTIATION_COMPLETE or ZB_SECUR_DEVICE_INTERVIEW
      if (ZB_IS_DEVICE_ZR()
          || ecdhe_ctx->key_negotiation_state == ZB_SECUR_KEY_NEGOTIATION_COMPLETE
          || ecdhe_ctx->key_negotiation_state == ZB_SECUR_DEVICE_INTERVIEW) {
        (void)zb_zdo_ecdhe_common_ctx_delete_by_ref(ecdhe_ctx->ref);
      }
    }
  }

  if (ZG->zdo.device_annce_cb != NULL)
  {
    /* callback is used to inform App about receiving device_annce */
    ZG->zdo.device_annce_cb(&da);
  }
  else
  {
    zb_zdo_signal_device_annce_params_t *dev_annce_params =
      (zb_zdo_signal_device_annce_params_t *)zb_app_signal_pack(param,
                                                               ZB_ZDO_SIGNAL_DEVICE_ANNCE,
                                                               RET_OK,
                                                               (zb_uint8_t)sizeof(zb_zdo_signal_device_annce_params_t));
    dev_annce_params->device_short_addr = da.nwk_addr;
    ZB_IEEE_ADDR_COPY(dev_annce_params->ieee_addr, da.ieee_addr);
    dev_annce_params->capability = da.capability;
    ZB_SCHEDULE_CALLBACK(zb_signal_dispatch, param);
    param = 0;
  }

  if (param != 0U)
  {
    zb_buf_free(param);
  }

  TRACE_MSG(TRACE_ZDO1, "<< zdo_device_annce_srv", (FMT__0));
}

#endif

/*! @} */
