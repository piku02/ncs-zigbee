/* ZBOSS Zigbee software protocol stack
 *
 * Copyright (c) 2012-2020 DSR Corporation, Denver CO, USA.
 * www.dsr-zboss.com
 * www.dsr-corporation.com
 * All rights reserved.
 *
 * This is unpublished proprietary source code of DSR Corporation
 * The copyright notice does not evidence any actual or intended
 * publication of such source code.
 *
 * ZBOSS is a registered trademark of Data Storage Research LLC d/b/a DSR
 * Corporation
 *
 * Commercial Usage
 * Licensees holding valid DSR Commercial licenses may use
 * this file in accordance with the DSR Commercial License
 * Agreement provided with the Software or, alternatively, in accordance
 * with the terms contained in a written agreement between you and
 * DSR.
 */
/*  PURPOSE: ZBOSS core API
*/

#define ZB_TRACE_FILE_ID 59
#include "zb_common.h"
#include "zb_bdb_internal.h"
#include "zb_scheduler.h"
#include "zb_nwk.h"
#include "zboss_api.h"
#include "zb_zdo.h"
#include "zb_aps.h"

void zb_set_rx_on_when_idle(zb_bool_t rx_on)
{
  TRACE_MSG(TRACE_ZDO2, "zb_set_rx_on_when_idle, rx_on %d", (FMT__D, rx_on));
#ifndef ZB_ED_RX_OFF_WHEN_IDLE
  ZB_PIBCACHE_RX_ON_WHEN_IDLE() = rx_on;
#else
  ZVUNUSED(rx_on);
#endif
}

zb_bool_t zb_get_rx_on_when_idle()
{
  return (zb_bool_t)ZB_PIBCACHE_RX_ON_WHEN_IDLE();
}

void zb_set_channel_mask(zb_uint32_t channel_mask)
{
  zb_aib_channel_page_list_set_2_4GHz_mask(channel_mask);
}

zb_uint32_t zb_get_channel_mask(void)
{
  return zb_aib_channel_page_list_get_2_4GHz_mask();
}

#ifdef ZB_OSIF_CONFIGURABLE_TX_POWER
zb_ret_t zb_set_tx_power(zb_uint8_t tx_power)
{
  zb_uint8_t channel;
  channel = zb_get_current_channel();
  return zb_osif_set_transmit_power(channel, tx_power);
}
#endif


/*! \addtogroup zboss_general_api */
/*! @{ */

void zb_set_pan_id(zb_uint16_t pan_id)
{
  ZB_PIBCACHE_PAN_ID() = pan_id;
}

zb_uint16_t zb_get_pan_id(void)
{
  return ZB_PIBCACHE_PAN_ID();
}

void zb_set_node_descriptor_manufacturer_code_req(zb_uint16_t manuf_code, zb_set_manufacturer_code_cb_t cb)
{
  zdo_set_node_descriptor_manufacturer_code(manuf_code);

  if (cb != NULL)
  {
    cb(RET_OK);
  }
}

/**
   Set 64-bit long address

   @param addr - long address
*/
void zb_set_long_address(const zb_ieee_addr_t addr)
{
  ZB_IEEE_ADDR_COPY(ZB_PIBCACHE_EXTENDED_ADDRESS(), addr);
}

/**
   Get 64-bit long address

   @return 64-bit long address
*/
void zb_get_long_address(zb_ieee_addr_t addr)
{
  ZB_IEEE_ADDR_COPY(addr, ZB_PIBCACHE_EXTENDED_ADDRESS());
}

/**
   Set Extended Pan ID (apsUseExtendedPANID attribute)
   @param ext_pan_id - Long (64-bit) Extended Pan ID
*/
void zb_set_extended_pan_id(const zb_ext_pan_id_t ext_pan_id)
{
  ZB_EXTPANID_COPY(ZB_AIB().aps_use_extended_pan_id, ext_pan_id);
}

/**
   Get Extended Pan ID (nwkExtendedPANId attribute)
   @param ext_pan_id - pointer to memory where result will be stored

   @return Long (64-bit) Extended Pan ID
*/
void zb_get_extended_pan_id(zb_ext_pan_id_t ext_pan_id)
{
  ZB_EXTPANID_COPY(ext_pan_id, ZB_NIB_EXT_PAN_ID());
}


zb_uint8_t zb_get_primary_interface(void)
{
  return ZB_PIBCACHE_PRIMARY_IFACE();
}


zb_uint8_t zb_get_current_page(void)
{
  return ZB_PIBCACHE_CURRENT_PAGE();
}


zb_uint8_t zb_get_current_channel(void)
{
  return ZB_PIBCACHE_CURRENT_CHANNEL();
}

/*! @} */

#ifdef ZB_USE_NVRAM
void zb_set_nvram_erase_at_start(zb_bool_t erase)
{
  ZB_AIB().aps_nvram_erase_at_start = ZB_B2U(erase);
}
#endif

void zb_set_nwk_role_mode_common_ext(zb_nwk_device_type_t device_type,
                                              zb_channel_list_t channel_list,
                                              zb_commissioning_type_t mode)
{
  zb_uint8_t used_page;

  TRACE_MSG(TRACE_INFO1, "zb_set_nwk_role_mode_common_ext: device_type %hd, mode %hd", (FMT__H_H, device_type, mode));

  ZB_AIB().aps_designated_coordinator = ZB_B2U(device_type == ZB_NWK_DEVICE_TYPE_COORDINATOR);
  ZB_NIB().device_type = device_type;

  used_page = zb_channel_page_list_get_first_filled_page(channel_list);
  if (used_page != ZB_CHANNEL_PAGES_NUM)
  {
    /* Channel list is not empty. */
    zb_channel_page_list_copy(ZB_AIB().aps_channel_mask_list, channel_list);
  }

  COMM_CTX().commissioning_type = mode;

  if (device_type == ZB_NWK_DEVICE_TYPE_COORDINATOR)
  {
    /* update psk bitmask: ZC supports IC and PASSCODE by default */
    zb_enable_psk_secret(ZB_TLV_PSK_SECRET_PAKE_PASSCODE);
    zb_enable_psk_secret(ZB_TLV_PSK_SECRET_INSTALL_CODE);
  }
}

void zb_set_nwk_role_mode_common(zb_nwk_device_type_t device_type,
                                          zb_uint32_t channel_mask,
                                          zb_commissioning_type_t mode)
{
  zb_channel_list_t channel_list;
  zb_channel_list_init(channel_list);
  zb_channel_page_list_set_2_4GHz_mask(channel_list, channel_mask);
  zb_set_nwk_role_mode_common_ext(device_type, channel_list, mode);
}

/* this API is unused, looks old and non-functioning */
/* [VK]: no, it's not) We use it in some SE samples */
#if 1
#ifdef ZB_SE_COMMISSIONING

static void set_se_mm_mode_common(zb_channel_list_t channel_list)
{
  COMM_CTX().commissioning_type = ZB_COMMISSIONING_SE;
  ZB_TCPOL().update_trust_center_link_keys_required = ZB_FALSE;
  zb_channel_page_list_copy(ZB_AIB().aps_channel_mask_list, channel_list);
  se_commissioning_force_link();
}

/* Disable DLK for SE devices (Z23-225) */
static void disable_dlk(void)
{
  zb_uint8_t supported_key_methods_mask = 0;
  ZB_TLV_KEY_ECDHE_METHOD_ENABLE(supported_key_methods_mask, ZB_TLV_KEY_ECDHE_KEY_REQUEST_ZB_30);
  zb_set_supported_key_neg_method(supported_key_methods_mask);
  zb_set_supported_psk_secrets(0);
}

#ifdef ZB_COORDINATOR_ROLE
void zb_se_set_network_coordinator_role_select_device(zb_channel_list_t channel_list)
{
  ZB_AIB().aps_designated_coordinator = ZB_TRUE;
  ZB_NIB().device_type = ZB_NWK_DEVICE_TYPE_COORDINATOR;
  ZB_SET_SUBGHZ_SWITCH_MODE(0);
  set_se_mm_mode_common(channel_list);
  se_formation_force_link();
  disable_dlk();
}


void zb_se_set_network_coordinator_role_switch_device(zb_channel_list_t channel_list)
{
  ZB_AIB().aps_designated_coordinator = ZB_TRUE;
  ZB_NIB().device_type = ZB_NWK_DEVICE_TYPE_COORDINATOR;
  ZB_SET_SUBGHZ_SWITCH_MODE(1);
  set_se_mm_mode_common(channel_list);
  disable_dlk();
}
#endif


#ifdef ZB_ED_FUNC
void zb_se_set_network_ed_role_select_device(zb_channel_list_t channel_list)
{
  ZB_NIB().device_type = ZB_NWK_DEVICE_TYPE_ED;
  ZB_SET_SUBGHZ_SWITCH_MODE(0);
  set_se_mm_mode_common(channel_list);
  disable_dlk();
}
#endif

#endif  /*  ZB_SE_COMMISSIONING */

#endif /* !excluded SE funcs */

#ifdef ZB_ROUTER_ROLE

#ifdef ZB_CERTIFICATION_HACKS

void zb_set_max_joins(zb_uint8_t max_joins)
{
  ZB_CERT_HACKS().max_joins = max_joins;
}

zb_uint8_t zb_get_max_joins(void)
{
  return ZB_CERT_HACKS().max_joins;
}

#endif /*ZB_CERTIFICATION_HACKS */

#endif /* ZB_ROUTER_ROLE */

void zb_set_supported_key_neg_mthd(zb_uint8_t methods_mask)
{
  ZDO_CTX().supported_key_neg_methods = methods_mask;
}

void zb_enable_key_neg_method(zb_uint8_t method)
{
  ZB_TLV_KEY_ECDHE_METHOD_ENABLE(ZDO_CTX().supported_key_neg_methods, method);
}

void zb_disable_key_neg_method(zb_uint8_t method)
{
  ZB_TLV_KEY_ECDHE_METHOD_DISABLE(ZDO_CTX().supported_key_neg_methods, method);
}

void zb_set_supported_psk_secrets(zb_uint8_t secret_mask)
{
  ZDO_CTX().supported_psk_secrets = secret_mask;
}
void zb_set_supported_key_neg_mthd_direct(zb_uint16_t methods_mask)
{
  ZDO_CTX().supported_key_neg_methods_direct = methods_mask;
}

void zb_set_supported_psk_secrets_direct(zb_uint8_t secret_mask)
{
  ZDO_CTX().supported_psk_secrets_direct = secret_mask;
}

void zb_enable_psk_secret(zb_uint8_t secret)
{
  ZB_TLV_PSK_SECRET_ENABLE(ZDO_CTX().supported_psk_secrets, secret);
}

void zb_disable_psk_secret(zb_uint8_t secret)
{
  ZB_TLV_PSK_SECRET_DISABLE(ZDO_CTX().supported_psk_secrets, secret);
}

zb_uint8_t zb_get_supported_key_neg_mtd(void)
{
  return ZDO_CTX().supported_key_neg_methods;
}

zb_uint8_t zb_get_supported_psk_secrets(void)
{
  return ZDO_CTX().supported_psk_secrets;
}

zb_uint16_t zb_get_supported_key_neg_mtd_direct(void)
{
  return ZDO_CTX().supported_key_neg_methods_direct;
}

zb_uint8_t zb_get_supported_psk_secrets_direct(void)
{
  return ZDO_CTX().supported_psk_secrets_direct;
}

zb_ret_t zboss_start()
{
  return zdo_dev_start();
}

zb_ret_t zboss_start_no_autostart(void)
{
  return zb_zdo_start_no_autostart();
}

void zboss_start_continue(void)
{
  ZB_SCHEDULE_CALLBACK(zb_zdo_dev_start_cont, 0);
}


#ifdef ZB_ZBOSS_DEINIT
static void zboss_deinit_mac_reset_conf(zb_bufid_t param)
{
  zb_multimac_mac_deinit();

  /* Cancel all callbacks and alarms - just in case, again */
  zb_scheduler_start_shutting();

  (void)zb_app_signal_pack(param, ZB_SIGNAL_READY_TO_SHUT, 0u, 0);
  /* the call below shouldn't be re-scheduled, it is matter to call it directly
     because in some cases we are here with the scheduler that is already stopped */
  zboss_signal_handler(param);
}

#if defined ZB_MACSPLIT_HOST || defined ZB_EXTMAC
void zboss_shut_with_host_reset(zb_bufid_t param)
{
  /* ZBOSS deinit can't be implemented without a scheduler: it is necessary to
   * deinit MAC, switch off the radio etc.
   * MAC can be attached via MACsplit, so must use scheduler to work with it.
   *
   */

  TRACE_MSG(TRACE_ZDO1, "> zboss_shut_with_host_reset param %d", (FMT__D, param));

  /* Cancel all callbacks and alarms. After that call accept callbacks but not alarms. */
  zb_scheduler_start_shutting();

  /* This function is used when mlme-reset is unacceptable,
   * so just call zboss_deinit_mac_reset_conf
   */
  zboss_deinit_mac_reset_conf(param);
}
#endif /* #if defined ZB_MACSPLIT_HOST || defined ZB_EXTMAC */

void zboss_abort(void)
{
  TRACE_MSG(TRACE_INFO1, "> zboss_abort", (FMT__0));

   /* Cancel all callbacks and alarms. After that call accept callbacks but not alarms. */
  zb_scheduler_start_shutting();

  zb_multimac_mac_deinit();

  zboss_complete_shut();
}

void zboss_start_shut(zb_bufid_t param)
{
  /* ZBOSS deinit can't be implemented without a scheduler: it is necessary to
   * deinit MAC, switch off the radio etc.
   * MAC can be attached via MACsplit, so must use scheduler to work with it.
   *
   */
  TRACE_MSG(TRACE_ZDO1, "> zboss_start_shut param %d", (FMT__D, param));

  /* Cancel all callbacks and alarms. After that call accept callbacks but not alarms. */
  zb_scheduler_start_shutting();

  /* Then reset all mac interfaces. It effectively sets channel in "invalid" and
   * swicthes off the radio - see zb_mlme_reset_request_sync() and
   * zb_mac_change_channel().
   * It works ok with macsplit as well.
   * TODO: check that it works ok with alien MACs as well.
   */
  {
    zb_mlme_reset_request_t *req = ZB_BUF_GET_PARAM(param, zb_mlme_reset_request_t);

    TRACE_MSG(TRACE_ZDO1, "zboss_start_shut call zb_nlme_reset_request - cold start", (FMT__0));
    ZB_BZERO(req, sizeof(zb_mlme_reset_request_t));
    req->set_default_pib = ZB_TRUE;
    req->iface_id = ZB_NWK_MULTIMAC_ALL_INTERFACES;
    /* Schedule MAC reset. It ends up in
     * zb_nwk_handle_mlme_reset_confirm->zb_nlme_reset_confirm */
    ZG->zdo.nlme_reset_cb = zboss_deinit_mac_reset_conf;
    ZB_SCHEDULE_CALLBACK(zb_multimac_mlme_reset_request_proxy, param);
  }
}


void zboss_complete_shut(void)
{
  /* That function is to be called from the app, from the signal handler. */
  TRACE_MSG(TRACE_ZDO1, "zboss_complete_shut", (FMT__0));

  zdo_commissioning_init();
  /* Clear all the global contexts, free all buffers */
  zb_nvram_deinit();
  ZB_MAC_DEINIT();
  zb_globals_init();
  zb_sched_stop();
#ifdef ZB_TRACE_TO_FILE
  /* Note: it also closes the dump file. */
  zb_trace_deinit_file();
#endif
}
#endif  /* #ifdef ZB_ZBOSS_DEINIT */

#ifdef ZB_INTERPAN_PREINIT

static void zboss_preinit_intrp_step4(zb_bufid_t param)
{
  TRACE_MSG(TRACE_APP3, "zboss_preinit_intrp_step4 %hd", (FMT__H, param));
  (void)zb_app_signal_pack(param, ZB_SIGNAL_INTERPAN_PREINIT, 0u, 0);
  ZB_SCHEDULE_CALLBACK(zboss_signal_handler, param);
}

static void zboss_preinit_intrp_step3(zb_bufid_t param)
{
  zb_mlme_get_confirm_t *gconf = (zb_mlme_get_confirm_t *)zb_buf_begin(param);
  TRACE_MSG(TRACE_APP3, "zboss_preinit_intrp_step3 %hd", (FMT__H, param));
  ZB_IEEE_ADDR_COPY(ZB_PIBCACHE_EXTENDED_ADDRESS(), (gconf+1));
  ZB_SCHEDULE_CALLBACK(zboss_preinit_intrp_step4, param);
}

static void zboss_preinit_intrp_step2(zb_bufid_t param)
{
  TRACE_MSG(TRACE_APP3, "zboss_preinit_intrp_step2 %hd", (FMT__H, param));
  /* FIXME:TODO: It makes sense only in case when ZB_PIB_ATTRIBUTE_EXTEND_ADDRESS is filled already.
     For now it is a temporary solution. The better way to fix is to load PIB values into NIB
   */
  zb_nwk_pib_get(param, ZB_PIBCACHE_PRIMARY_IFACE(), ZB_PIB_ATTRIBUTE_EXTEND_ADDRESS, zboss_preinit_intrp_step3);
}


static void zboss_preinit_intrp_step1(zb_bufid_t param)
{
#ifndef ZB_SUBGHZ_ONLY_MODE
  /* Let's set current page to be 2.4 in MAC */
  zb_uint8_t pg = 0u;

  TRACE_MSG(TRACE_APP3, "zboss_preinit_intrp_step1 %hd", (FMT__H, param));

  ZB_PIBCACHE_CURRENT_PAGE() = 0u; /* 2.4 */
  (void)zb_buf_reuse(param);
  zb_nwk_pib_set(param, ZB_PIBCACHE_PRIMARY_IFACE(), ZB_PHY_PIB_CURRENT_PAGE, &pg, sizeof(pg), zboss_preinit_intrp_step2);
#else
  ZB_SCHEDULE_CALLBACK(zboss_preinit_intrp_step2, param);
#endif
}


void zboss_preinit_for_interpan(zb_bufid_t param)
{
  /* This pre-init is required to send inter-pan broadcast to reset ZLL bulbs before formation/join.
     It requires at least MAC reset.
  */
  zb_mlme_reset_request_t *req = ZB_BUF_GET_PARAM(param, zb_mlme_reset_request_t);

  TRACE_MSG(TRACE_ZDO1, "zboss_preinit_for_interpan call zb_nlme_reset_request - cold start", (FMT__0));
  ZB_BZERO(req, sizeof(zb_mlme_reset_request_t));
  req->set_default_pib = ZB_TRUE;
  req->iface_id = ZB_NWK_MULTIMAC_ALL_INTERFACES;
  /* Schedule MAC reset. It endfs up in
   * zb_nwk_handle_mlme_reset_confirm->zb_nlme_reset_confirm */
  ZG->zdo.nlme_reset_cb = zboss_preinit_intrp_step1;
  ZB_SCHEDULE_CALLBACK(zb_multimac_mlme_reset_request_proxy, param);
}

#endif  /* ZB_INTERPAN_BEFORE_INIT */

zb_commissioning_type_t zb_zdo_get_commissioning_type(void)
{
  return COMM_CTX().commissioning_type;
}

void zb_secur_set_tc_rejoin_enabled(zb_bool_t enable)
{
  ZB_TCPOL().allow_tc_rejoins = enable;
}

void zb_secur_set_ignore_tc_rejoin(zb_bool_t enable)
{
  ZB_TCPOL().ignore_unsecure_tc_rejoins = enable;
}

void zb_secur_set_unsecure_tc_rejoin_enabled(zb_bool_t enable)
{
  ZB_TCPOL().allow_unsecure_tc_rejoins = enable;
}

void zb_zdo_disable_network_mgmt_channel_update(zb_bool_t disable)
{
  ZDO_CTX().handle.channel_update_disabled = disable;
}

void zb_zdo_enable_tx_fail_debug(zb_bool_t enable)
{
  ZDO_CTX().handle.tx_fail_debug_enabled = enable;
}

#ifdef ZB_SECURITY_INSTALLCODES
void zb_tc_set_use_installcode(zb_uint8_t use_ic)
{
  ZB_TCPOL().require_installcodes = ZB_U2B(use_ic);
}
#endif /* ZB_SECURITY_INSTALLCODES */

#ifdef ZB_CONTROL4_NETWORK_SUPPORT
#ifdef ZB_ED_FUNC
void zb_permit_control4_network(void)
{
  ZB_TCPOL().permit_control4_network = 1;

#if defined ZB_JOIN_CLIENT
  /* Enable joining to distributed for control4 network */
  zb_enable_joining_to_distributed_network();
#endif /* ZB_JOIN_CLIENT */
}

zb_bool_t zb_control4_network_permitted(void)
{
  return ZB_TCPOL().permit_control4_network;
}
#endif /* ZB_ED_FUNC */

void zb_disable_control4_emulator(void)
{
    ZB_TCPOL().control4_network_emulator = 0;
}

void zb_enable_control4_emulator(void)
{
    ZB_TCPOL().control4_network_emulator = 1;
}
#endif /* ZB_CONTROL4_NETWORK_SUPPORT */

#ifdef ZB_ROUTER_ROLE
void zb_disable_transport_key_aps_encryption(void)
{
  ZB_TCPOL().aps_unencrypted_transport_key_join = ZB_TRUE;
}

void zb_enable_transport_key_aps_encryption(void)
{
  ZB_TCPOL().aps_unencrypted_transport_key_join = ZB_FALSE;
}

zb_bool_t zb_is_transport_key_aps_encryption_enabled(void)
{
  return (ZB_U2B(ZB_TCPOL().aps_unencrypted_transport_key_join)) ? ZB_FALSE : ZB_TRUE;
}
#endif

#ifdef ZB_COORDINATOR_ROLE
void zb_start_concentrator_mode(zb_uint8_t radius, zb_uint32_t disc_time)
{
  ZB_NIB_SET_IS_CONCENTRATOR(ZB_TRUE);
  ZB_NIB_SET_CONCENTRATOR_RADIUS(radius);
  ZB_NIB_SET_CONCENTRATOR_DISC_TIME(disc_time);
/* 10/22/2019 EE CR:MINOR Add check for device role: we can be compiled with ZC sup[port but start as ZR! */
#ifndef ZB_LITE_NO_SOURCE_ROUTING
  /* Start route discovery */
  zb_nwk_concentrator_start();
#endif /* ZB_LITE_NO_SOURCE_ROUTING */
}

void zb_stop_concentrator_mode(void)
{
  ZB_NIB_SET_IS_CONCENTRATOR(ZB_FALSE);
  ZB_NIB_SET_CONCENTRATOR_RADIUS(0);
  ZB_NIB_SET_CONCENTRATOR_DISC_TIME(0);
/* 10/22/2019 EE CR:MINOR Add check for device role: we can be compiled with ZC sup[port but start as ZR! */
#ifndef ZB_LITE_NO_SOURCE_ROUTING
  /* Stop route discovery */
  zb_nwk_concentrator_stop();
#endif /* ZB_LITE_NO_SOURCE_ROUTING */
}

#endif /* ZB_COORDINATOR_ROLE */

#ifdef ZB_SECURITY_INSTALLCODES
void zb_set_installcode_policy(zb_bool_t allow_ic_only)
{
  ZB_TCPOL().require_installcodes = allow_ic_only;
}
#endif /* ZB_SECURITY_INSTALLCODES */


void zb_set_use_extended_pan_id(const zb_ext_pan_id_t ext_pan_id)
{
  TRACE_MSG(TRACE_ZDO2, ">> zb_set_use_extended_pan_id, ext_pan_id " TRACE_FORMAT_64,
            (FMT__A, TRACE_ARG_64(ext_pan_id)));

  ZB_EXTPANID_COPY(ZB_AIB().aps_use_extended_pan_id, ext_pan_id);

  TRACE_MSG(TRACE_ZDO2, "<< zb_set_use_extended_pan_id", (FMT__0));
}

void zb_get_use_extended_pan_id(zb_ext_pan_id_t ext_pan_id)
{
  ZB_EXTPANID_COPY(ext_pan_id, ZB_AIB().aps_use_extended_pan_id);

  TRACE_MSG(TRACE_ZDO2, "zb_get_use_extended_pan_id: " TRACE_FORMAT_64,
            (FMT__A, TRACE_ARG_64(ext_pan_id)));
}

zb_uint16_t zb_get_short_address(void)
{
  return ZB_PIBCACHE_NETWORK_ADDRESS();
}


void zb_set_aps_enc_for_zdo_in_distrib_nwk(zb_bool_t val)
{
  ZB_TCPOL().use_aps_enc_for_zdo_in_distrib_nwk = ZB_B2U(val);
}


void zb_set_aps_enc_for_zdo_conf_cmd(zb_bool_t val)
{
  ZB_TCPOL().encrypt_zdo_conf_cmd = ZB_B2U(val);
}


#ifdef ZB_ENABLE_PTA
static void zb_send_pta_state(zb_uint8_t param, zb_uint16_t arg)
{
  zb_uint8_t st = (zb_uint8_t)arg;

  zb_nwk_pib_set(param,
                 ZB_PIBCACHE_PRIMARY_IFACE(),
                 ZB_PIB_ATTRIBUTE_PTA_STATE,
                 &st,
                 1u,
                 NULL); /* free the buf */
}

void zb_enable_pta(zb_uint8_t state)
{
  if (ZG->nwk.is_nwk_started == ZB_TRUE)
  {
    (void)zb_buf_get_out_delayed_ext(zb_send_pta_state, state, 0);
  }
  else
  {
    ZG->nwk.pta_state_at_start = state;
  }
}
#endif

#ifdef ZB_ALLOW_PROVISIONAL_KEY_AS_TCLK
void zb_allow_provisional_key_as_tclk(void)
{
  ZB_TCPOL().allow_provisional_key_as_tclk = ZB_TRUE;
}

void zb_disallow_provisional_key_as_tclk(void)
{
  ZB_TCPOL().allow_provisional_key_as_tclk = ZB_FALSE;
}
#endif /* ZB_ALLOW_PROVISIONAL_KEY_AS_TCLK */

/* Dummy body for obsolete panid conflict switch functions from pre-r23 */

/* API */
void zb_enable_panid_conflict_resolution(zb_bool_t status)
{
  /* Z23-227: No reasons to switch off conflict resolution logic at r23 */
  ZVUNUSED(status);
}


void zb_enable_auto_pan_id_conflict_resolution(zb_bool_t status)
{
  ZVUNUSED(status);
}

