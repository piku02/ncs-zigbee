/* ZBOSS Zigbee software protocol stack
 *
 * Copyright (c) 2012-2020 DSR Corporation, Denver CO, USA.
 * www.dsr-zboss.com
 * www.dsr-corporation.com
 * All rights reserved.
 *
 * This is unpublished proprietary source code of DSR Corporation
 * The copyright notice does not evidence any actual or intended
 * publication of such source code.
 *
 * ZBOSS is a registered trademark of Data Storage Research LLC d/b/a DSR
 * Corporation
 *
 * Commercial Usage
 * Licensees holding valid DSR Commercial licenses may use
 * this file in accordance with the DSR Commercial License
 * Agreement provided with the Software or, alternatively, in accordance
 * with the terms contained in a written agreement between you and
 * DSR.
 */
/* PURPOSE: ZDO network management functions, client side
*/

#define ZB_TRACE_FILE_ID 2099
#include "zb_common.h"
#include "zb_scheduler.h"
#include "zb_bufpool.h"
#include "zb_hash.h"
#include "zb_nwk.h"
#include "zb_aps.h"
#include "zb_zdo.h"
#include "zdo_common.h"
#include "zb_ncp.h"
#include "zdo_wwah_survey_beacons.h"

/*! \addtogroup ZB_ZDO */
/*! @{ */

#if defined ZB_ROUTER_ROLE

typedef ZB_PACKED_PRE struct zb_nlme_permit_joining_req_cli_s {
  zb_uint8_t permit_duration;
  zb_uint8_t tsn;
} ZB_PACKED_STRUCT zb_nlme_permit_joining_req_cli_t;

#endif /* ZB_ROUTER_ROLE */

static zb_uint8_t zdo_mgmt_leave_local(zb_uint8_t param, zb_callback_t cb);
static void mgmt_leave_to_unauth_chld(zb_uint8_t param);

zb_uint8_t zdo_mgmt_permit_joining_req_cli(zb_uint8_t param, zb_callback_t cb);

zb_uint8_t zb_zdo_mgmt_nwk_update_req(zb_uint8_t param, zb_callback_t cb)
{
  zb_zdo_mgmt_nwk_update_req_t *req_param;
  zb_zdo_mgmt_nwk_update_req_hdr_t *req;
  zb_uint8_t *payload;
  zb_uint8_t zdo_tsn;

  TRACE_MSG(TRACE_ZDO2, ">> zb_zdo_mgmt_nwk_update_req param %hd", (FMT__D, param));
  req_param = ZB_BUF_GET_PARAM(param, zb_zdo_mgmt_nwk_update_req_t);

  req = zb_buf_initial_alloc(param, sizeof(zb_zdo_mgmt_nwk_update_req_hdr_t));
  ZB_HTOLE32(&req->scan_channels, &req_param->hdr.scan_channels);
  req->scan_duration = req_param->hdr.scan_duration;

  if (req->scan_duration == ZB_ZDO_NEW_ACTIVE_CHANNEL ||
      req->scan_duration == ZB_ZDO_NEW_CHANNEL_MASK)
  {
    payload = zb_buf_alloc_right(param, sizeof(zb_uint8_t));

    TRACE_MSG(TRACE_ZDO2, "new act channel/mask", (FMT__0));
    *payload = ZB_NIB_UPDATE_ID();
    zb_buf_flags_clr(param, ZB_BUF_ZDO_CMD_NO_RESP);
    if (req->scan_duration == ZB_ZDO_NEW_CHANNEL_MASK)
    {
      TRACE_MSG(TRACE_ZDO2, "new mask", (FMT__0));
      payload = zb_buf_alloc_right(param, sizeof(zb_uint16_t));
      ZB_HTOLE16(payload, &req_param->manager_addr);
    }
  }
#ifndef ZB_LITE_NO_FULL_FUNCLIONAL_MGMT_NWK_UPDATE
  else if (req->scan_duration <= ZB_ZDO_MAX_SCAN_DURATION)
  {
    TRACE_MSG(TRACE_ZDO3, "ed scan req", (FMT__0));

    payload = zb_buf_alloc_right(param, sizeof(zb_uint8_t));
    *payload = req_param->scan_count;
  }
#endif
#ifdef ZB_CERTIFICATION_HACKS
  else if (ZB_CERT_HACKS().zdo_mgmt_nwk_update_force_scan_count)
  {
    TRACE_MSG(TRACE_ZDO3, "zdo_mgmt_nwk_update_force_scan_count cert hack", (FMT__0));

    payload = zb_buf_alloc_right(param, sizeof(zb_uint8_t));
    *payload = req_param->scan_count;
  }
#endif
#if !defined(ZB_LITE_NO_FULL_FUNCLIONAL_MGMT_NWK_UPDATE) || defined(ZB_CERTIFICATION_HACKS)
  else
  {
    TRACE_MSG(TRACE_ERROR, "Unexpected scan_duration %hd", (FMT__H, req->scan_duration));
    return ZB_ZDO_INVALID_TSN;
  }
#endif

  zdo_tsn = zdo_send_req_by_short(ZDO_MGMT_NWK_UPDATE_REQ_CLID, param, cb,
                                  req_param->dst_addr, ZB_ZDO_CB_DEFAULT_COUNTER);

  TRACE_MSG(TRACE_ZDO2, "<< zb_zdo_mgmt_nwk_update_req", (FMT__0));
  return zdo_tsn;
}



zb_uint8_t zb_zdo_mgmt_nwk_enh_update_req(zb_uint8_t param, zb_callback_t cb)
{
  zb_zdo_mgmt_nwk_enhanced_update_req_param_t *req_param_ptr;
  zb_zdo_mgmt_nwk_enhanced_update_req_param_t req_param;
  zb_zdo_mgmt_nwk_enhanced_update_req_hdr_t *hdr;
  zb_uint8_t zdo_tsn = ZB_ZDO_INVALID_TSN;
  zb_uint8_t *payload;
  zb_uindex_t i;

  TRACE_MSG(TRACE_ZDO1, ">> zb_zdo_mgmt_nwk_enh_update_req param %hd",
            (FMT__H, param));

  req_param_ptr = ZB_BUF_GET_PARAM(param, zb_zdo_mgmt_nwk_enhanced_update_req_param_t);
  ZB_MEMCPY(&req_param, req_param_ptr, sizeof(zb_zdo_mgmt_nwk_enhanced_update_req_param_t));

  hdr = zb_buf_initial_alloc(param, sizeof(zb_zdo_mgmt_nwk_enhanced_update_req_hdr_t));

  /* Find channel pages to be copied,
   * convert from ZBOSS internal representation to ZB spec */
  hdr->channel_page_count = 0;
  for (i = 0; i < ZB_CHANNEL_PAGES_NUM; i++)
  {
    zb_channel_page_t *channel_page = &req_param.channel_list[i];

    if (/*ZB_CHANNEL_PAGE_IS_SUB_GHZ(*channel_page) &&*/
        !ZB_CHANNEL_PAGE_IS_MASK_EMPTY(*channel_page))
    {
      payload = zb_buf_alloc_right(param, sizeof(zb_channel_page_t));
      ZB_HTOLE32(payload, channel_page);
      hdr->channel_page_count++;
    }
  }

#if defined ZB_CERTIFICATION_HACKS
  if (ZB_CERT_HACKS().place_extra_item_for_bv_37_b == 1u)
  {
    zb_channel_page_t channel_page = 0xb9ffffffu; /* 23u << 27u || 0x1FFFFFF */
    payload = zb_buf_alloc_right(param, sizeof(zb_channel_page_t));
    ZB_HTOLE32(payload, &channel_page);
    hdr->channel_page_count++;

    ZB_CERT_HACKS().place_extra_item_for_bv_37_b = 0;
  }
#endif

  TRACE_MSG(TRACE_ZDO3, "Channel page count %hd",
            (FMT__H, hdr->channel_page_count));

  /* Send the frame only if we have smth to send */
  if (hdr->channel_page_count != 0U)
  {
    payload = zb_buf_alloc_right(param, sizeof(zb_uint8_t));

    /* Scan Duration */
    *payload = req_param.scan_duration;

    if (req_param.scan_duration <= ZB_ZDO_MAX_SCAN_DURATION)
    {
      /* Scan count */
      payload = zb_buf_alloc_right(param, sizeof(zb_uint8_t));
      *payload = req_param.scan_count;
    }
#ifdef ZB_CERTIFICATION_HACKS
    else if (ZB_CERT_HACKS().zdo_mgmt_nwk_update_force_scan_count)
    {
      TRACE_MSG(TRACE_ZDO3, "zdo_mgmt_nwk_update_force_scan_count cert hack", (FMT__0));

      payload = zb_buf_alloc_right(param, sizeof(zb_uint8_t));
      *payload = req_param.scan_count;
    }
#endif
    else if (req_param.scan_duration == ZB_ZDO_NEW_ACTIVE_CHANNEL)
    {
      /* nwkUpdateID */
      payload = zb_buf_alloc_right(param, sizeof(zb_uint8_t));
      *payload = ZB_NIB_UPDATE_ID();
    }
    else if (req_param.scan_duration == ZB_ZDO_NEW_CHANNEL_MASK)
    {
      /* nwkUpdateID + nwkManagerAddr */
      payload = zb_buf_alloc_right(param, sizeof(zb_uint8_t) + sizeof(zb_uint16_t));
      *payload = ZB_NIB_UPDATE_ID();
      payload += sizeof(zb_uint8_t);
      ZB_HTOLE16(payload, &req_param.manager_addr);
    }
    else
    {
      /* Unexpected, but send frame as is */
      TRACE_MSG(TRACE_ERROR, "Unexpected scan_duration %hd", (FMT__H, param));
    }

    zdo_tsn = zdo_send_req_by_short(ZDO_MGMT_NWK_ENHANCED_UPDATE_REQ_CLID, param, cb,
                                    req_param.dst_addr, ZB_ZDO_CB_DEFAULT_COUNTER);
  }

  TRACE_MSG(TRACE_ZDO1, "<< zb_zdo_mgmt_nwk_enh_update_req tsn %hd",
            (FMT__H, zdo_tsn));

  return zdo_tsn;
}

#ifdef ZB_DEPRECATED_API

zb_uint8_t zb_zdo_mgmt_nwk_enhanced_update_req(zb_uint8_t param, zb_callback_t cb)
{
  return zb_zdo_mgmt_nwk_enh_update_req(param, cb);
}

#endif /* ZB_DEPRECATED_API */



#ifndef ZB_LITE_NO_ZDO_SYSTEM_SERVER_DISCOVERY
zb_uint8_t zb_zdo_system_server_discovery_req(zb_uint8_t param, zb_callback_t cb)
{
  zb_zdo_system_server_discovery_req_t *req;
  zb_zdo_system_server_discovery_param_t *req_param;

  req_param = ZB_BUF_GET_PARAM(param, zb_zdo_system_server_discovery_param_t);
  req = zb_buf_initial_alloc(param, sizeof(zb_zdo_system_server_discovery_param_t));

  ZB_HTOLE16(&req->server_mask, &req_param->server_mask);

  TRACE_MSG(TRACE_ZDO3, "zb_zdo_system_server_discovery_req server_mask %x", (FMT__D, req->server_mask));

  /* This request is handled with slightly different approach comparing to other ZDO requests:
   * the CB and TSN are stored in the particular variable and they are analysed separately.
   * Possibly, it is done because multiple responses are expected after broadcast request is sent.
   * TODO: handle it as all other ZDO requests (use internal ZDO context)
   */
  ZDO_CTX().system_server_discovery_cb = cb;
  ZDO_CTX().system_server_discovery_tsn =
    zdo_send_req_by_short(ZDO_SYSTEM_SERVER_DISCOVERY_REQ_CLID, param, NULL,
                          ZB_NWK_BROADCAST_RX_ON_WHEN_IDLE, ZB_ZDO_CB_UNICAST_COUNTER);
  return ZDO_CTX().system_server_discovery_tsn;
}
#endif


zb_uint8_t zb_zdo_mgmt_lqi_req(zb_uint8_t param, zb_callback_t cb)
{
  zb_zdo_mgmt_lqi_req_t *req;
  zb_zdo_mgmt_lqi_param_t *req_param;

  TRACE_MSG(TRACE_ZDO3, "zb_zdo_mgmt_lqi_req param %hd", (FMT__D, param));
  req_param = ZB_BUF_GET_PARAM(param, zb_zdo_mgmt_lqi_param_t);

  /* MA: Wrong struct for sizeof: zb_zdo_mgmt_nwk_update_req_hdr_t
   * update to zb_zdo_mgmt_lqi_req_t */
  req = zb_buf_initial_alloc(param, sizeof(zb_zdo_mgmt_lqi_req_t));
  req->start_index = req_param->start_index;

  return zdo_send_req_by_short(ZDO_MGMT_LQI_REQ_CLID, param, cb, req_param->dst_addr, ZB_ZDO_CB_DEFAULT_COUNTER);
}

zb_uint8_t zb_zdo_mgmt_rtg_req(zb_uint8_t param, zb_callback_t cb)
{
  zb_zdo_mgmt_rtg_req_t *req;
  zb_zdo_mgmt_rtg_param_t *req_param;

  TRACE_MSG(TRACE_ZDO3, "zb_zdo_mgmt_rtg_req param %hd", (FMT__D, param));
  req_param = ZB_BUF_GET_PARAM(param, zb_zdo_mgmt_rtg_param_t);

  req = zb_buf_initial_alloc(param, sizeof(zb_zdo_mgmt_rtg_req_t));
  req->start_index = req_param->start_index;

  return zdo_send_req_by_short(ZDO_MGMT_RTG_REQ_CLID, param, cb, req_param->dst_addr, ZB_ZDO_CB_DEFAULT_COUNTER);
}

zb_uint8_t zb_zdo_mgmt_bind_req(zb_uint8_t param, zb_callback_t cb)
{
  zb_zdo_mgmt_bind_req_t *req;
  zb_zdo_mgmt_bind_param_t *req_param;

  TRACE_MSG(TRACE_ZDO3, "zb_zdo_mgmt_bind_req param %hd", (FMT__D, param));
  req_param = ZB_BUF_GET_PARAM(param, zb_zdo_mgmt_bind_param_t);
  req = zb_buf_initial_alloc(param, sizeof(zb_zdo_mgmt_bind_req_t));
  req->start_index = req_param->start_index;

  return zdo_send_req_by_short(ZDO_MGMT_BIND_REQ_CLID, param, cb, req_param->dst_addr, ZB_ZDO_CB_DEFAULT_COUNTER);
}

zb_uint8_t zdo_mgmt_leave_req(zb_uint8_t param, zb_callback_t cb)
{
  zb_zdo_mgmt_leave_req_t *req;
  zb_zdo_mgmt_leave_param_t req_param;
  zb_uint8_t                zdo_tsn;
  ZB_MEMCPY(&req_param, ZB_BUF_GET_PARAM(param, zb_zdo_mgmt_leave_param_t), sizeof(req_param));
  TRACE_MSG(TRACE_ZDO3, ">> zdo_mgmt_leave_req param %hd", (FMT__D, param));

  /*
   * Is is possible to do zdo_mgmt_leave_req locally.
   * There is a problem (or not a problem?) in such case: we will got
   * response (callback call) really before our local LEAVE complete.
   * It may or may not be a problem.
   */
  req = zb_buf_initial_alloc(param, sizeof(zb_zdo_mgmt_leave_req_t));
  zb_buf_flags_clr(param, ZB_BUF_ZDO_CMD_NO_RESP);
  ZB_IEEE_ADDR_COPY(req->device_address, req_param.device_address);
  req->rejoin = req_param.rejoin;
  req->remove_children = ZB_FALSE;

  /* Check whether device should send Leave Request to itself
   * It is needed when short destination address is equal to local short address
   * or device_address is equal to local IEEE address.
   *
   * NOTE: the second condition is needed to handle case when
   * NCP host doesn't still know its short address, but should perform local leave
   * (e.g. in case of failed authorization after association)
   */
  if (req_param.dst_addr == ZB_PIBCACHE_NETWORK_ADDRESS() ||
      ZB_IEEE_ADDR_CMP(req_param.device_address, ZB_PIBCACHE_EXTENDED_ADDRESS()))
  {
    /* local leave mgmt request */
    TRACE_MSG(TRACE_ZDO3, "local leave mgmt req", (FMT__0));
    zdo_tsn = zdo_mgmt_leave_local(param, cb);
  }
  else                          /* not local */
  {
    /* Must use vars - Hi to MISRA */
    /* we are sending leave directly to the destination */
    zb_bool_t short_addr_equal = (zb_address_short_by_ieee(req_param.device_address) == req_param.dst_addr);
    /* Our destination is unauthenticated child */
    zb_bool_t rel_unauth_child = (zb_nwk_get_nbr_rel_by_short(req_param.dst_addr) == ZB_NWK_RELATIONSHIP_UNAUTHENTICATED_CHILD);
    TRACE_MSG(TRACE_ZDO3, "non-local mgmt leave to 0x%x " TRACE_FORMAT_64,
              (FMT__D_A, req_param.dst_addr, TRACE_ARG_64(req_param.device_address)));

    /* Check for the special case when application sends Mgmt Leave to the
       unauthenticated child.  In that case do not send it (the child has no NWK
       key, so we can't send).  Remove device from nbt immediately.
     */
    if (short_addr_equal && rel_unauth_child)
    {
      TRACE_MSG(TRACE_ZDO3, "App sends Mgmt Leave to unauthenticated child 0x%x", (FMT__D, req_param.dst_addr));
      /* zdo_mgmt_leave_local will recheck LEAVE to unauthenticated child and imitate receiving of NWK LEAVE with success. */
      zdo_tsn = zdo_mgmt_leave_local(param, cb);
    }
    else if (ZB_NWK_IS_ADDRESS_BROADCAST(req_param.dst_addr))
    {
      zdo_tsn = 0u;
      if (cb != NULL)
      {
        zb_zdo_callback_info_t *zdo_info_p = zb_buf_initial_alloc(param, sizeof(zb_zdo_callback_info_t));
        zdo_info_p->tsn = 0;
        zdo_info_p->status = ZB_ZDP_STATUS_DEVICE_NOT_FOUND;
        ZB_SCHEDULE_CALLBACK(cb, param);
      }
      else
      {
        ZB_ASSERT(!ZB_NWK_IS_ADDRESS_BROADCAST(req_param.dst_addr));
      }
    }
    else
    {
      TRACE_MSG(TRACE_ZDO3, "Send Mgmt LEAVE by unicast to 0x%x", (FMT__D, req_param.dst_addr));
      zdo_tsn = zdo_send_req_by_short(ZDO_MGMT_LEAVE_REQ_CLID, param, cb, req_param.dst_addr, ZB_ZDO_CB_UNICAST_COUNTER);
    }
  }
  TRACE_MSG(TRACE_ZDO3, "<< zdo_mgmt_leave_req", (FMT__0));
  return zdo_tsn;
}


static zb_uint8_t zdo_mgmt_leave_local(zb_uint8_t param, zb_callback_t cb)
{
  zb_ushort_t i;
  zb_zdo_mgmt_leave_req_t req;
  zb_uint8_t               zdo_tsn;
  zb_uint8_t               cb_tsn = ZB_ZDO_INVALID_TSN;

  TRACE_MSG(TRACE_ZDO3, ">>zdo_mgmt_leave_local %hd", (FMT__H, param));

  zdo_tsn = zdo_tsn_inc();

  /* add entry to the leave req table */
  for (i = 0 ;
       i < ZB_ZDO_PENDING_LEAVE_SIZE
         && ZB_U2B(ZB_IS_LEAVE_PENDING(i)) ;
       ++i)
  {
  }

  if (i == ZB_ZDO_PENDING_LEAVE_SIZE)
  {
    if (cb != NULL)
    {
      zb_zdo_callback_info_t *zdo_info_p;

      TRACE_MSG(TRACE_ERROR, "out of pending leave list send resp now!", (FMT__0));
      /* send resp just now. */

      zdo_info_p = zb_buf_initial_alloc(param, sizeof(zb_zdo_callback_info_t));
      zdo_info_p->tsn = zdo_tsn;
      zdo_info_p->status = ZB_ZDP_STATUS_INSUFFICIENT_SPACE;
      ZB_SCHEDULE_CALLBACK(cb, param);
    }
    else
    {
      zb_buf_free(param);
    }
  }
  else
  {
    zb_uint8_t rx_on_when_idle;

    ZB_MEMCPY(&req, zb_buf_begin(param), sizeof(zb_zdo_mgmt_leave_req_t));

    rx_on_when_idle = zb_nwk_get_nbr_rx_on_idle_by_ieee(req.device_address);
    if (rx_on_when_idle == ZB_NWK_NEIGHBOR_ERROR_VALUE)
    {
      rx_on_when_idle = ZB_FALSE;
    }

    cb_tsn = zdo_tsn;
    if (cb != NULL)
    {
      if (!register_zdo_cb(zdo_tsn, cb, 1, CB_TYPE_TSN, (zb_bool_t)rx_on_when_idle))
      {
        cb_tsn = ZB_ZDO_INVALID_TSN;
        TRACE_MSG(TRACE_ERROR, "failed to register ZDO callback!", (FMT__0));
      }
    }

    /* If cb_tsn == ZB_ZDO_INVALID_TSN, some issue occurred and leave process will stop */
    if (cb_tsn != ZB_ZDO_INVALID_TSN)
    {
    ZB_SET_LEAVE_PENDING(i);

    if (!ZB_U2B(ZB_PIBCACHE_RX_ON_WHEN_IDLE())
        /* Normally ZED can't send LEAVE, but just in case check that this is request for ourself */
        && ZB_IEEE_ADDR_CMP(req.device_address, ZB_PIBCACHE_EXTENDED_ADDRESS()))
    {
      TRACE_MSG(TRACE_COMMON1, "Stopping poll", (FMT__0));
      zb_zdo_pim_stop_poll(0);
    }
    TRACE_MSG(TRACE_ZDO3, "remember mgmt_leave at i %hd, tsn %hd, addr %d, buf_ref %hd",
              (FMT__H_H_D_H, i, ZG->nwk.leave_context.pending_list[i].tsn,
               ZG->nwk.leave_context.pending_list[i].src_addr,
               ZG->nwk.leave_context.pending_list[i].buf_ref));

    if (zb_nwk_get_nbr_rel_by_ieee(req.device_address) == ZB_NWK_RELATIONSHIP_UNAUTHENTICATED_CHILD)
    {
      ZB_SCHEDULE_CALLBACK(mgmt_leave_to_unauth_chld, param);
    }
    else
    /* Now locally call LEAVE.request */
    /* Note: it can be either local LEAVE, or NWK LEAVE req to remote device. */
    {
      zb_nlme_leave_request_t *lr;

      ZB_SET_LEAVE_PENDING(i);

      ZG->nwk.leave_context.pending_list[i].tsn = zdo_tsn;
      ZG->nwk.leave_context.pending_list[i].src_addr = ZB_PIBCACHE_NETWORK_ADDRESS();
      ZG->nwk.leave_context.pending_list[i].buf_ref = param;

      lr = ZB_BUF_GET_PARAM(param, zb_nlme_leave_request_t);
      /* Let's zero our long address in case when device leaves itself.
       * Table 3-26 says that for NLME-LEAVE.request
       * The 64-bit IEEE address of the entity ... NULL if the device removes itself from the network.
       */
      if (ZB_IEEE_ADDR_CMP(req.device_address, ZB_PIBCACHE_EXTENDED_ADDRESS()))
      {
        ZB_IEEE_ADDR_ZERO(req.device_address);
      }
      ZB_IEEE_ADDR_COPY(lr->device_address, req.device_address);
      lr->rejoin = req.rejoin;
      ZB_SCHEDULE_CALLBACK(zb_nlme_leave_request, param);
    }
  }
  }
  TRACE_MSG(TRACE_ZDO3, "<<zdo_mgmt_leave_local tsn: %hd, cb tsn: %hd", (FMT__H_H, zdo_tsn, cb_tsn));
  return cb_tsn;
}


static void mgmt_leave_to_unauth_chld(zb_uint8_t param)
{
  zb_zdo_mgmt_leave_req_t req;
  zb_nlme_leave_indication_t *li;

  ZB_MEMCPY(&req, zb_buf_begin(param), sizeof(req));
  li = ZB_BUF_GET_PARAM(param, zb_nlme_leave_indication_t);
  ZB_IEEE_ADDR_COPY(li->device_address, req.device_address);
  li->rejoin = 0;
  TRACE_MSG(TRACE_ZDO1, "mgmt_leave_to_unauth_chld: locally calling zb_nlme_leave_indication for dev " TRACE_FORMAT_64,
            (FMT__A, TRACE_ARG_64(li->device_address)));
  ZB_SCHEDULE_CALLBACK(zb_nlme_leave_indication, param);
}


zb_uint8_t zb_zdo_mgmt_permit_joining_req(zb_uint8_t param, zb_callback_t cb)
{
  zb_zdo_mgmt_permit_joining_req_t *req;
  zb_zdo_mgmt_permit_joining_req_param_t req_param;
  zb_uint8_t zdo_tsn;

  TRACE_MSG(TRACE_ZDO3, ">> zb_zdo_mgmt_permit_joining_req param %hd cb %p", (FMT__H_P, param, cb));

  ZB_MEMCPY(&req_param, ZB_BUF_GET_PARAM(param, zb_zdo_mgmt_permit_joining_req_param_t), sizeof(req_param));

#if defined ZB_ROUTER_ROLE
  if (req_param.dest_addr == ZB_PIBCACHE_NETWORK_ADDRESS())
  {
    TRACE_MSG(TRACE_ZDO3, "req to itself: permit_duration %hd", (FMT__H, req_param.permit_duration));
    zdo_tsn = zdo_mgmt_permit_joining_req_cli(param, cb);
    if (zdo_tsn == ZB_ZDO_INVALID_TSN)
    {
      /* An invalid TSN means that the permit joining request failed */
      TRACE_MSG(TRACE_ERROR, "zdo_mgmt_permit_joining_req_cli failed, aborting zb_zdo_mgmt_permit_joining_req", (FMT__0));
    }
  }
  else
#endif
  {
    zb_uint8_t resp_counter = ZB_ZDO_CB_DEFAULT_COUNTER;

    TRACE_MSG(TRACE_ZDO3, "send permit_joining_req to 0x%x permit_duration %hu", (FMT__D_H, req_param.dest_addr, req_param.permit_duration));

    req = zb_buf_initial_alloc(param, sizeof(zb_zdo_mgmt_permit_joining_req_t));
    /* [MM]: It isn't defined explicitly if the following actions should
     * be done on command TX, but lets fill the parameters as they
     * are expected on the RX side (according to r21, 2.4.3.3.7.2 Effect
     * on Receipt)
     */
    req->permit_duration = (req_param.permit_duration == 0xFFU) ? (0xFEU) : req_param.permit_duration;
#ifdef ZB_CERTIFICATION_HACKS
    if (ZB_CERT_HACKS().override_tc_significance_flag)
    {
      req->tc_significance = req_param.tc_significance;
    }
    else
#endif
    {
      req->tc_significance = 1;
    }


    /*
      Need mgmt_permit_joining callback to be called after command is sent,
      Don't wait response because in EZ-Mode this command is broadcast and
      no response may be received
    */
    if (ZB_NWK_IS_ADDRESS_BROADCAST(req_param.dest_addr))
    {
      zb_buf_flags_or(param, ZB_BUF_ZDO_CMD_NO_RESP);
      resp_counter = ZB_ZDO_CB_UNICAST_COUNTER;
    }

    /*cstat -MISRAC2012-Rule-2.1_b*/
    if (ZB_IS_TC())
    {
      if (!ZB_R22_GU_BEHAVIOR_ENABLED())
      {
        /** @mdr{00012,44} */
        /*cstat +MISRAC2012-Rule-2.1_b*/
        zb_zdo_encapsulation_put_tlv(param, NULL);
      }
    }

    zdo_tsn = zdo_send_req_by_short(ZDO_MGMT_PERMIT_JOINING_CLID, param, cb, req_param.dest_addr, resp_counter);
  }

  TRACE_MSG(TRACE_ZDO3, "<< zb_zdo_mgmt_permit_joining_req", (FMT__0));
  return zdo_tsn;
}

#if defined ZB_ROUTER_ROLE

zb_uint8_t zdo_mgmt_permit_joining_req_cli(zb_uint8_t param, zb_callback_t cb)
{
  zb_nlme_permit_joining_req_cli_t *req;
  zb_zdo_mgmt_permit_joining_req_param_t req_param;
  zb_uint8_t zdo_tsn;
  zb_uint8_t cb_tsn;

  TRACE_MSG(TRACE_ZDO2, ">> zdo_mgmt_permit_joining_cli param %hd cb %p", (FMT__H_P, param, cb));

  zdo_tsn = zdo_tsn_inc();
  cb_tsn = zdo_tsn;

  if (cb != NULL)
  {
    zb_bool_t ret_zdo_cb = register_zdo_cb(zdo_tsn, cb, 1, CB_TYPE_TSN, ZB_TRUE);

    if (!ret_zdo_cb)
    {
      cb_tsn = ZB_ZDO_INVALID_TSN;
      TRACE_MSG(TRACE_ERROR, "register_zdo_cb failed", (FMT__0));
    }
  }

  /* If cb_tsn == ZB_ZDO_INVALID_TSN, some issue occurred and permit joining process will stop */
  if (cb_tsn != ZB_ZDO_INVALID_TSN)
  {
  ZB_MEMCPY(&req_param, ZB_BUF_GET_PARAM(param, zb_zdo_mgmt_permit_joining_req_param_t),
            sizeof(zb_zdo_mgmt_permit_joining_req_param_t));

    req = ZB_BUF_GET_PARAM(param, zb_nlme_permit_joining_req_cli_t);
    ZB_BZERO(req, sizeof(zb_nlme_permit_joining_req_cli_t));
  req->permit_duration = req_param.permit_duration;
    req->tsn = cb_tsn;

    if (zb_zdo_joined())
    {
  ZB_SCHEDULE_CALLBACK(zb_nlme_permit_joining_request, param);
  }
  else
  {
    zb_buf_set_status(param, ZB_NWK_STATUS_INVALID_REQUEST);
    ZB_SCHEDULE_CALLBACK(zdo_mgmt_permit_joining_resp_cli, param);
  }
  }

  TRACE_MSG(TRACE_ZDO2, "<< zdo_mgmt_permit_joining_cli", (FMT__0));

  return cb_tsn;
}

void zdo_mgmt_permit_joining_resp_cli(zb_uint8_t param)
{
  zb_nlme_permit_joining_req_cli_t req;
  zb_zdo_mgmt_permit_joining_resp_t *resp;

  ZB_MEMCPY(&req, ZB_BUF_GET_PARAM(param, zb_nlme_permit_joining_req_cli_t), sizeof(req));
  
  /* [VK]: Permit joining response behaviour should be the same.
   * Payload is placed in the buf begin in case of a ZDO packet,
   * so let's do the same in case of itself request.
   */
  resp = (zb_zdo_mgmt_permit_joining_resp_t *)zb_buf_begin(param);

  /* Repack the status to parameters and call the upper layer callback */
  resp->tsn = req.tsn;
  resp->status = (zb_uint8_t)zb_buf_get_status(param);

  TRACE_MSG(TRACE_ZDO2, ">> zdo_mgmt_permit_joining_resp_cli status %d", (FMT__D, resp->status));

  if (zdo_af_resp(param) != RET_OK)
  {
    /* DD: here was an NCP signal. But it was generated when some other device sent us
       a permit joining request. So it useless for host as we didn't tell permit join request
       parameters. */

    zb_buf_free(param);
  }

  TRACE_MSG(TRACE_ZDO2, "<< zdo_mgmt_permit_joining_resp_cli", (FMT__0));
}
#endif

#if defined ZB_JOINING_LIST_SUPPORT

zb_uint8_t zb_zdo_mgmt_nwk_ieee_joining_list_req(zb_uint8_t param, zb_callback_t cb)
{
  zb_zdo_mgmt_nwk_ieee_joining_list_req_t *req;
  zb_zdo_mgmt_nwk_ieee_joining_list_param_t *req_param;

  TRACE_MSG(TRACE_ZDO3, "zb_zdo_mgmt_nwk_ieee_joining_list_req param %hd", (FMT__D, param));
  req_param = ZB_BUF_GET_PARAM(param, zb_zdo_mgmt_nwk_ieee_joining_list_param_t);

  req = zb_buf_initial_alloc(param, sizeof(zb_zdo_mgmt_nwk_ieee_joining_list_req_t));
  req->start_index = req_param->start_index;

  return zdo_send_req_by_short(ZDO_MGMT_NWK_IEEE_JOINING_LIST_REQ_CLID, param, cb, req_param->dst_addr, ZB_ZDO_CB_DEFAULT_COUNTER);
}

#endif /* ZB_JOINING_LIST_SUPPORT */


zb_uint8_t zdo_mgmt_beacon_survey_req(zb_uint8_t param, zb_callback_t cb)
{
  zb_uint8_t *req;
  zb_zdo_mgmt_beacon_survey_param_t req_param;

  TRACE_MSG(TRACE_ZDO3, "zdo_mgmt_beacon_survey_req param %hd", (FMT__D, param));
  req_param = *(ZB_BUF_GET_PARAM(param, zb_zdo_mgmt_beacon_survey_param_t));
  req = zb_buf_initial_alloc(param, 0);
  (void)req;

  zb_zdo_beacon_survey_put_configuration_tlv(param,
                                             req_param.channel_page_cnt,
                                             req_param.channel_page_list,
                                             req_param.config_mask);

  return zdo_send_req_by_short(ZDO_MGMT_NWK_BEACON_SURVEY_REQ_CLID, param, cb, req_param.dst_addr, ZB_ZDO_CB_DEFAULT_COUNTER);
}


void zb_zdo_beacon_survey_resp_handler(zb_uint8_t param)
{
  /* Convert the packet data into zb_zdo_beacon_survey_resp_params_t, then call user cb with zb_zdo_beacon_survey_resp_params_t in data section */
  /* assign ind so can use space of params section */
  zb_ret_t ret;
  zb_apsde_data_indication_t ind = *ZB_BUF_GET_PARAM(param, zb_apsde_data_indication_t);
  zb_uint16_t panid_conflict_count = 0u;
  zb_uint8_t *tlv_ptr = zb_buf_begin(param);
  zb_uint8_t tlv_len = (zb_uint8_t)zb_buf_len(param) - 2U /*tsn + status*/;
  zb_uint8_t tsn = tlv_ptr[0];
  zb_uint8_t status = tlv_ptr[1];
  zb_zdo_beacon_survey_results_t results;
  zb_zdo_beacon_survey_resp_params_t *resp;

  TRACE_MSG(TRACE_ZDO3, "zb_zdo_beacon_survey_resp_handler param %hd status %hd tlv_len %hd",
            (FMT__H_H_H, param, status, tlv_len));

  if (status != 0u)
  {
    ret = RET_ERROR;
  }
  else
  {
    tlv_ptr += 2;               /* skip tsn and status */
    /* zb_zdo_beacon_survey_potential_parents_t size is 50 bytes. We have MAC,
     * NWK, APS headers cut here, so can use that space in the buffer */

    ret = zb_tlv_general_tlv_processing(tlv_ptr, tlv_len);
  }
  if (ret == RET_OK)
  {
    /* Panid conflict report may be absent - that is not a error */
    (void)zb_tlv_parse_panid_conflict_report_tlv(tlv_ptr, tlv_len, &panid_conflict_count);
  }
  if (ret == RET_OK)
  {
    ret = zb_tlv_parse_beacon_survey_results_tlv(tlv_ptr, tlv_len, &results);
  }
  if (ret == RET_OK)
  {
#define FIRST_SURV_PART_SIZE ZB_OFFSETOF(zb_zdo_beacon_survey_resp_params_t, results)
    /* Use the i/o buf begin as a spece for the result */
    resp = zb_buf_alloc_left(param, FIRST_SURV_PART_SIZE);
    /* Old buffer data can be moved, so re-assign tlv ptr. Note that tlv_len is unchanged */
    tlv_ptr = zb_buf_begin(param);
    tlv_ptr += FIRST_SURV_PART_SIZE + 2u;
    ret = zb_tlv_parse_beacon_survey_parents_tlv(tlv_ptr, tlv_len, &resp->parents);
  }
  if (ret == RET_OK)
  {
    /* we now have part of resp (status and parents) at buf begin, the packet data at buffer end. */
    zb_buf_cut_right(param, (zb_uint_t)tlv_len + 2u);
    /* cur the original data and allocate space for the rest of zb_zdo_beacon_survey_resp_params_t */
    (void)zb_buf_alloc_right(param, sizeof(zb_zdo_beacon_survey_resp_params_t) - FIRST_SURV_PART_SIZE);
    /* reassign just in case */
    resp = zb_buf_begin(param);
    ZB_MEMCPY(&resp->results, &results, sizeof(results));
    resp->panid_conflict_count = panid_conflict_count;
    resp->status = 0u;
  }
  else
  {
    if (status == 0u)
    {
      /* some status to indicate invalid tlv */
      status = ZB_ZDP_STATUS_INVALID_INDEX;
    }
    resp = zb_buf_initial_alloc(param, sizeof(*resp));
    ZB_BZERO(resp, sizeof(*resp));
    resp->status = status;
  }
  /* zdo_af_resp supposes tsn at buf begin */
  resp->tsn = tsn;
  /* restore data ind parameters */
  ZB_MEMCPY(ZB_BUF_GET_PARAM(param, zb_apsde_data_indication_t), &ind, sizeof(ind));
  ret = zdo_af_resp(param);
  /* do not free buffer if callback was found */
  if (ret != RET_OK)
  {
    zb_buf_free(param);
  }
  TRACE_MSG(TRACE_ZDO3, "zb_zdo_beacon_survey_resp_handler ret %d status %hd", (FMT__D_H, ret, status));
}



/*! @} */
