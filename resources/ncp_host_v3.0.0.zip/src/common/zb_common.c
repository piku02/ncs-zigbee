/* ZBOSS Zigbee software protocol stack
 *
 * Copyright (c) 2012-2021 DSR Corporation, Denver CO, USA.
 * www.dsr-zboss.com
 * www.dsr-corporation.com
 * All rights reserved.
 *
 * This is unpublished proprietary source code of DSR Corporation
 * The copyright notice does not evidence any actual or intended
 * publication of such source code.
 *
 * ZBOSS is a registered trademark of Data Storage Research LLC d/b/a DSR
 * Corporation
 *
 * Commercial Usage
 * Licensees holding valid DSR Commercial licenses may use
 * this file in accordance with the DSR Commercial License
 * Agreement provided with the Software or, alternatively, in accordance
 * with the terms contained in a written agreement between you and
 * DSR.
 */

#define ZB_TRACE_FILE_ID 135

#include "zb_common.h"

#if !defined(ZB_MINIMAL_CONTEXT)

/**
 * @brief Generates EUI-64 address from MAC address
 *
 * @param [in]  mac_address MAC address, byte array of length 6, position 0 is the MSB and
 *                          position 5 is the LSB
 * @param [out] eui_64      Generated EUI-64 address, byte array of length 8, position 0
 *                          is the LSB and position 7 is the MSB
 * @return zb_ret_t
 *          - RET_OK on success
 *          - RET_INVALID_PARAMETER if NULL pointers are used
 */
zb_ret_t zbd_generate_eui64_from_mac_address(const zb_uint8_t *mac_address, zb_ieee_addr_t eui_64)
{
    ZB_ASSERT(mac_address != NULL);
    ZB_ASSERT(eui_64 != NULL);

    if (mac_address == NULL) { return RET_INVALID_PARAMETER; }
    if (eui_64 == NULL)      { return RET_INVALID_PARAMETER; }

    eui_64[7] = mac_address[0] ^ 0x02U;
    eui_64[6] = mac_address[1];
    eui_64[5] = mac_address[2];
    eui_64[4] = 0xFFU;
    eui_64[3] = 0xFEU;
    eui_64[2] = mac_address[3];
    eui_64[1] = mac_address[4];
    eui_64[0] = mac_address[5];

    return RET_OK;
}

#endif /* !ZB_MINIMAL_CONTEXT */
