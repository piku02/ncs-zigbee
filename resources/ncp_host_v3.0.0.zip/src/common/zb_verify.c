/* ZBOSS Zigbee software protocol stack
 *
 * Copyright (c) 2012-2020 DSR Corporation, Denver CO, USA.
 * www.dsr-zboss.com
 * www.dsr-corporation.com
 * All rights reserved.
 *
 * This is unpublished proprietary source code of DSR Corporation
 * The copyright notice does not evidence any actual or intended
 * publication of such source code.
 *
 * ZBOSS is a registered trademark of Data Storage Research LLC d/b/a DSR
 * Corporation
 *
 * Commercial Usage
 * Licensees holding valid DSR Commercial licenses may use
 * this file in accordance with the DSR Commercial License
 * Agreement provided with the Software or, alternatively, in accordance
 * with the terms contained in a written agreement between you and
 * DSR.
 */
/* PURPOSE: Verification functions, to possibly raise error in ZBOSS and interrupt application
*/

#define ZB_TRACE_FILE_ID 2146
#include "zboss_api_core.h"
#include "zb_error_indication.h"

ZB_NORETURN void zb_verify(zb_uint16_t file_id, zb_int_t line_number, zb_ret_t error_code, void *additional_info)
{
  zb_verify_additional_info_t internal_additional_info;

  internal_additional_info.file_id = file_id;
  internal_additional_info.line_number = line_number;
  internal_additional_info.caller_additional_info = additional_info;

  TRACE_MSG(TRACE_ERROR,
            "Verification failed ZB_TRACE_FILE_ID %d line %d additional_info 0x%p",
            (FMT__D_D_P, file_id, line_number, additional_info)
  );

  ZB_ERROR_RAISE(ZB_ERROR_SEVERITY_FATAL,
                 error_code,
                 &internal_additional_info
  );
#ifdef USE_ASSERT
  ZB_ASSERT(0);
#else
  TRACE_MSG(TRACE_ERROR, "Verification failed - aborting...", (FMT__0));
  ZB_ABORT();
#endif
  while (1)
  {
  }
}
