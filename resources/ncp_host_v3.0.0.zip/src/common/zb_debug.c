/* ZBOSS Zigbee software protocol stack
 *
 * Copyright (c) 2012-2020 DSR Corporation, Denver CO, USA.
 * www.dsr-zboss.com
 * www.dsr-corporation.com
 * All rights reserved.
 *
 * This is unpublished proprietary source code of DSR Corporation
 * The copyright notice does not evidence any actual or intended
 * publication of such source code.
 *
 * ZBOSS is a registered trademark of Data Storage Research LLC d/b/a DSR
 * Corporation
 *
 * Commercial Usage
 * Licensees holding valid DSR Commercial licenses may use
 * this file in accordance with the DSR Commercial License
 * Agreement provided with the Software or, alternatively, in accordance
 * with the terms contained in a written agreement between you and
 * DSR.
 */
/* PURPOSE: debug stuff
*/

#define ZB_TRACE_FILE_ID 2144
#include "zboss_api_core.h"
#include "zboss_api_buf.h"
#include "zb_common.h"
#include "zb_secur.h"


/*! \addtogroup ZB_DEBUG */
/*! @{ */

#if (defined USE_ASSERT || defined DOXYGEN)

#if !defined ZB_TOOL && !defined ZB_MACSPLIT_DEVICE
#include "zb_common.h"
#endif

/**
   Abort execution in system-specific manner.

   Write trace message before abort.
 */
/** [abort] */
void zb_abort(char *caller_file, int caller_line)
{
  ZVUNUSED(caller_file);
  ZVUNUSED(caller_line);
#if !defined UNIX && !defined ZB_PLATFORM_LINUX
  TRACE_MSG (TRACE_ERROR, "Abort from %d ", (FMT__D, (int)caller_line));
#else
  TRACE_MSG (TRACE_ERROR, "Abort from %s:%d ", (FMT__P_D, caller_file, (int)caller_line));
#endif
  ZB_ABORT();
}

#ifndef ZB_BINARY_TRACE
ZB_NORETURN void zb_assert(const zb_char_t *file_name, zb_int_t line_number)
{
  ZVUNUSED(file_name);
  ZVUNUSED(line_number);
#if !defined UNIX && !defined ZB_PLATFORM_LINUX && !defined ZB_WINDOWS
  TRACE_MSG (TRACE_ERROR, "Assertion failed %d", (FMT__D, line_number));
#else
  TRACE_MSG (TRACE_ERROR, "Assertion failed %s:%d", (FMT__P_D, file_name, line_number));
#endif

#if defined (ZB_TRACE_TO_FILE)
  zb_trace_file_flush();
#endif

  ZB_ABORT();
}
/** [abort] */

#else /* !ZB_BINARY_TRACE */

ZB_NORETURN void zb_assert(zb_uint16_t file_id, zb_int_t line_number)
{
  ZVUNUSED(file_id);
  ZVUNUSED(line_number);
  TRACE_MSG(TRACE_ERROR, "Assertion failed ZB_TRACE_FILE_ID %d line %d", (FMT__D_D, file_id, line_number));
#ifdef ZB_TRACE_CPU_STATE
  ZB_TRACE_CPU_STATE();
#endif /* ZB_TRACE_CPU_STATE */
#if !defined ZB_TOOL && !defined ZB_MACSPLIT_DEVICE && !defined ZB_DISABLE_ASSERT_INDICATION
  if (ZDO_CTX().assert_indication_cb)
  {
    (ZDO_CTX().assert_indication_cb)(file_id, line_number);
  }
#endif

#if defined (ZB_TRACE_TO_FILE)
  zb_trace_file_flush();
#endif

#if defined ZB_RESET_AT_ASSERT
  zb_reset(0);
#else
  ZB_ABORT();
#endif /* ZB_RESET_AT_ASSERT */

  while(1)
  {
  }
}
#endif /* !ZB_BINARY_TRACE */

void lwip_zb_assert(zb_uint16_t file_id, zb_int_t line_number)
{
  ZVUNUSED(file_id);
  ZVUNUSED(line_number);
  TRACE_MSG(TRACE_ERROR, "LWIP assert failed file_id %d line %d", (FMT__D_D, file_id, line_number));

#if defined (ZB_TRACE_TO_FILE)
  zb_trace_file_flush();
#endif
}
#else  /* DEBUG */

ZB_WEAK_PRE void ZB_WEAK zb_assert(const zb_char_t *file_name, zb_int_t line_number)
{
	ZVUNUSED(file_name);
	ZVUNUSED(line_number);
	return;
}

zb_uint8_t g_traf_dump = 0;     /* Disabled by default */

#include "zb_osif.h"

ZB_WEAK_PRE zb_osif_file_t * ZB_WEAK zb_trace_dump_file()
{
  return (zb_osif_file_t *)NULL;
}

#endif  /* DEBUG */


#define HEX_ARG(n) buf[i+n]

#if defined(ZB_TRACE_LEVEL) && defined(ZB_TRACE_TRAFFIC)
void dump_traf(const zb_uint8_t *buf, zb_ushort_t len)
{
#if TRACE_ENABLED(TRACE_MAC3)
  zb_ushort_t i;

  TRACE_MSG(TRACE_MAC3, "len %hd", (FMT__H, len));

  for (i = 0 ; i < len ; i += 8U)
  {
    zb_ushort_t tmp = len - i;
    if (tmp >= 8U)
    {
      TRACE_MSG(TRACE_MAC3, "%hx %hx %hx %hx %hx %hx %hx %hx",
                (FMT__H_H_H_H_H_H_H_H,
                 HEX_ARG(0), HEX_ARG(1), HEX_ARG(2), HEX_ARG(3),
                 HEX_ARG(4), HEX_ARG(5), HEX_ARG(6), HEX_ARG(7)));
    }
    else
    {
      switch (tmp)
      {
        case 7:
          TRACE_MSG(TRACE_MAC3, "%hx %hx %hx %hx %hx %hx %hx",
                    (FMT__H_H_H_H_H_H_H,
                     HEX_ARG(0), HEX_ARG(1), HEX_ARG(2), HEX_ARG(3),
                     HEX_ARG(4), HEX_ARG(5), HEX_ARG(6)));
          break;
        case 6:
          TRACE_MSG(TRACE_MAC3, "%hx %hx %hx %hx %hx %hx",
                    (FMT__H_H_H_H_H_H,
                     HEX_ARG(0), HEX_ARG(1), HEX_ARG(2), HEX_ARG(3),
                     HEX_ARG(4), HEX_ARG(5)));
          break;
        case 5:
          TRACE_MSG(TRACE_MAC3, "%hx %hx %hx %hx %hx",
                    (FMT__H_H_H_H_H,
                     HEX_ARG(0), HEX_ARG(1), HEX_ARG(2), HEX_ARG(3),
                     HEX_ARG(4)));
          break;
        case 4:
          TRACE_MSG(TRACE_MAC3, "%hx %hx %hx %hx",
                    (FMT__H_H_H_H,
                     HEX_ARG(0), HEX_ARG(1), HEX_ARG(2), HEX_ARG(3)));
          break;
        case 3:
          TRACE_MSG(TRACE_MAC3, "%hx %hx %hx",
                    (FMT__H_H_H,
                     HEX_ARG(0), HEX_ARG(1), HEX_ARG(2)));
          break;
        case 2:
          TRACE_MSG(TRACE_MAC3, "%hx %hx",
                    (FMT__H_H,
                     HEX_ARG(0), HEX_ARG(1)));
          break;
        case 1:
          TRACE_MSG(TRACE_MAC3, "%hx",
                    (FMT__H,
                     HEX_ARG(0)));
          break;
        default:
          break;
      }
      /* Exit for loop */
      break;
    }
  }
#else
  ZVUNUSED(buf);
  ZVUNUSED(len);
#endif /* TRACE_ENABLED(TRACE_MAC3) */
}

void dump_usb_traf(zb_uint8_t *buf, zb_ushort_t len)
{
#if TRACE_ENABLED(TRACE_USB3)
  zb_ushort_t i;

  TRACE_MSG(TRACE_USB3, "len %hd", (FMT__H, len));

  for (i = 0 ; i < len ; i += 8U)
  {
    zb_ushort_t tmp = len - i;
    if (tmp >= 8U)
    {
      TRACE_MSG(TRACE_USB3, "%02hx %02hx %02hx %02hx %02hx %02hx %02hx %02hx",
                (FMT__H_H_H_H_H_H_H_H,
                 HEX_ARG(0), HEX_ARG(1), HEX_ARG(2), HEX_ARG(3),
                 HEX_ARG(4), HEX_ARG(5), HEX_ARG(6), HEX_ARG(7)));
    }
    else
    {
      switch (tmp)
      {
        case 7:
          TRACE_MSG(TRACE_USB3, "%02hx %02hx %02hx %02hx %02hx %02hx %02hx",
                    (FMT__H_H_H_H_H_H_H,
                     HEX_ARG(0), HEX_ARG(1), HEX_ARG(2), HEX_ARG(3),
                     HEX_ARG(4), HEX_ARG(5), HEX_ARG(6)));
          break;
        case 6:
          TRACE_MSG(TRACE_USB3, "%02hx %02hx %02hx %02hx %02hx %02hx",
                    (FMT__H_H_H_H_H_H,
                     HEX_ARG(0), HEX_ARG(1), HEX_ARG(2), HEX_ARG(3),
                     HEX_ARG(4), HEX_ARG(5)));
          break;
        case 5:
          TRACE_MSG(TRACE_USB3, "%02hx %02hx %02hx %02hx %02hx",
                    (FMT__H_H_H_H_H,
                     HEX_ARG(0), HEX_ARG(1), HEX_ARG(2), HEX_ARG(3),
                     HEX_ARG(4)));
          break;
        case 4:
          TRACE_MSG(TRACE_USB3, "%02hx %02hx %02hx %02hx",
                    (FMT__H_H_H_H,
                     HEX_ARG(0), HEX_ARG(1), HEX_ARG(2), HEX_ARG(3)));
          break;
        case 3:
          TRACE_MSG(TRACE_USB3, "%02hx %02hx %02hx",
                    (FMT__H_H_H,
                     HEX_ARG(0), HEX_ARG(1), HEX_ARG(2)));
          break;
        case 2:
          TRACE_MSG(TRACE_USB3, "%02hx %02hx",
                    (FMT__H_H,
                     HEX_ARG(0), HEX_ARG(1)));
          break;
        case 1:
          TRACE_MSG(TRACE_USB3, "%02hx",
                    (FMT__H,
                     HEX_ARG(0)));
          break;
        default:
          break;
      }
      /* Exit for loop */
      break;
    }
  }
#else
  ZVUNUSED(buf);
  ZVUNUSED(len);
#endif /* TRACE_ENABLED(TRACE_USB3) */
}


/* TODO: where will it be better to place such functions?
 * They will break shared objects building if they are placed here */
#ifndef ZB_CONTEXTS_IN_SEPARATE_FILE
typedef struct zb_debug_trace_buffer_param_struct_s
{
  zb_uint8_t data[32];
}
zb_debug_trace_buffer_param_struct_t;

void zb_debug_trace_buffer(zb_uint8_t buf_id, zb_uint16_t label)
{
  #define ZB_DEBUG_TRACE_BUFFER_FLAG(flag)                  \
    if ((flags & (flag)) != 0U)                             \
    {                                                       \
      TRACE_MSG(TRACE_MAC3, "  " # flag, (FMT__0));         \
    }

  zb_uint_t flags;

  TRACE_MSG(TRACE_MAC3, "zb_debug_trace_buffer: buf_id %hd, size %hd, buf_label %d",
    (FMT__H_H_H, buf_id, zb_buf_len(buf_id), label));
  TRACE_MSG(TRACE_MAC3, "Payload:", (FMT__0));

  dump_traf(zb_buf_begin(buf_id), zb_buf_len(buf_id));

  TRACE_MSG(TRACE_MAC3, "Flags:", (FMT__0));

  flags = zb_buf_flags_get(buf_id);

  ZB_DEBUG_TRACE_BUFFER_FLAG(ZB_BUF_IS_IN);
  ZB_DEBUG_TRACE_BUFFER_FLAG(ZB_BUF_SECUR_NWK_ENCR);
  ZB_DEBUG_TRACE_BUFFER_FLAG(ZB_BUF_SECUR_APS_ENCR);
  ZB_DEBUG_TRACE_BUFFER_FLAG(ZB_BUF_SECUR_MAC_ENCR);
  ZB_DEBUG_TRACE_BUFFER_FLAG(ZB_BUF_USE_SAME_KEY);
  ZB_DEBUG_TRACE_BUFFER_FLAG(ZB_BUF_ZDO_CMD_NO_RESP);
  ZB_DEBUG_TRACE_BUFFER_FLAG(ZB_BUF_HAS_APS_PAYLOAD);
  ZB_DEBUG_TRACE_BUFFER_FLAG(ZB_BUF_HAS_APS_USER_PAYLOAD);

  TRACE_MSG(TRACE_MAC3, "Last %hd bytes of the param:", (FMT__H, sizeof(zb_debug_trace_buffer_param_struct_t)));

  dump_traf((zb_uint8_t*)ZB_BUF_GET_PARAM(buf_id, zb_debug_trace_buffer_param_struct_t), sizeof(zb_debug_trace_buffer_param_struct_t));
}

void zb_debug_trace_nwk_header(const zb_uint8_t *payload_ptr, zb_uint16_t label)
{
  zb_uint16_t frame_control;
  static const char *frame_type_labels[] = {
    /* ZB_NWK_FRAME_TYPE_DATA 0U */
    "data",
    /* ZB_NWK_FRAME_TYPE_COMMAND 1U */
    "command"
  };

  const zb_nwk_hdr_t *nwk_hdr = (const zb_nwk_hdr_t*)payload_ptr;
  ZB_MEMCPY(&frame_control, &nwk_hdr->frame_control, sizeof(frame_control));
  TRACE_MSG(TRACE_MAC3, ">> zb_debug_trace_nwk_header, label %d, ptr %p", (FMT__D_P, label, payload_ptr));
  TRACE_MSG(TRACE_MAC3, "  frame_control 0x%x", (FMT__D, frame_control));
  TRACE_MSG(TRACE_MAC3, "    frame_type %hd (%s)",
    (FMT__H_P, ZB_NWK_FRAMECTL_GET_FRAME_TYPE(nwk_hdr->frame_control), frame_type_labels[ZB_NWK_FRAMECTL_GET_FRAME_TYPE(nwk_hdr->frame_control)]));
  TRACE_MSG(TRACE_MAC3, "    protocol_version %hd", (FMT__H, ZB_NWK_FRAMECTL_GET_PROTOCOL_VERSION(nwk_hdr->frame_control)));
  TRACE_MSG(TRACE_MAC3, "    discover_route %hd", (FMT__H, ZB_NWK_FRAMECTL_GET_DISCOVER_ROUTE(nwk_hdr->frame_control)));
  TRACE_MSG(TRACE_MAC3, "    multicast %hd", (FMT__H, ZB_NWK_FRAMECTL_GET_MULTICAST_FLAG(nwk_hdr->frame_control)));
  TRACE_MSG(TRACE_MAC3, "    security %hd", (FMT__H, ZB_NWK_FRAMECTL_GET_SECURITY(nwk_hdr->frame_control)));
  TRACE_MSG(TRACE_MAC3, "    source_route %hd", (FMT__H, ZB_NWK_FRAMECTL_GET_SOURCE_ROUTE(nwk_hdr->frame_control)));
  TRACE_MSG(TRACE_MAC3, "    extended_destination %hd", (FMT__H, ZB_NWK_FRAMECTL_GET_DESTINATION_IEEE(nwk_hdr->frame_control)));
  TRACE_MSG(TRACE_MAC3, "    extended_source %hd", (FMT__H, ZB_NWK_FRAMECTL_GET_SOURCE_IEEE(nwk_hdr->frame_control)));
  TRACE_MSG(TRACE_MAC3, "  radius %hd", (FMT__H, nwk_hdr->radius));
  TRACE_MSG(TRACE_MAC3, "  nwk_seq_num %hd", (FMT__H, nwk_hdr->seq_num));

  TRACE_MSG(TRACE_MAC3, "  src_short 0x%x", (FMT__D, nwk_hdr->src_addr));

  if (ZB_NWK_FRAMECTL_GET_SOURCE_IEEE(nwk_hdr->frame_control))
  {
    TRACE_MSG(TRACE_MAC3, "  src_ieee " TRACE_FORMAT_64,
      (FMT__A, TRACE_ARG_64(nwk_hdr->src_ieee_addr)));
  }

  TRACE_MSG(TRACE_MAC3, "  dst_short 0x%x", (FMT__D, nwk_hdr->dst_addr));

  if (ZB_NWK_FRAMECTL_GET_DESTINATION_IEEE(nwk_hdr->frame_control))
  {
    TRACE_MSG(TRACE_MAC3, "  dst_ieee " TRACE_FORMAT_64,
      (FMT__A, TRACE_ARG_64(nwk_hdr->dst_ieee_addr)));
  }

  if (ZB_NWK_FRAMECTL_GET_SECURITY(nwk_hdr->frame_control))
  {
    const zb_nwk_aux_frame_hdr_t *aux_hdr = (const zb_nwk_aux_frame_hdr_t*)(payload_ptr + ZB_NWK_HDR_SIZE(nwk_hdr) - sizeof(zb_nwk_aux_frame_hdr_t));

    TRACE_MSG(TRACE_MAC3, "  NWK_AUX header, ptr %p", (FMT__P, aux_hdr));
    TRACE_MSG(TRACE_MAC3, "    control_field 0x%hx", (FMT__H, aux_hdr->secur_control));
    TRACE_MSG(TRACE_MAC3, "      source_route %hd", (FMT__H, ZB_SECUR_GET_SECURITY_LEVEL(aux_hdr->secur_control)));
    TRACE_MSG(TRACE_MAC3, "      key_id %hd", (FMT__H, ZB_SECUR_AUX_HDR_GET_KEY_TYPE(aux_hdr->secur_control)));
    TRACE_MSG(TRACE_MAC3, "      extended_nonce %hd", (FMT__H, ZB_SECUR_GET_SECURITY_NONCE(aux_hdr->secur_control)));
    TRACE_MSG(TRACE_MAC3, "    frame_counter %hd", (FMT__H, aux_hdr->frame_counter));
    TRACE_MSG(TRACE_MAC3, "    key_seq_number %hd", (FMT__H, aux_hdr->key_seq_number));
    TRACE_MSG(TRACE_MAC3, "    src_ieee " TRACE_FORMAT_64, (FMT__A, TRACE_ARG_64(aux_hdr->source_address)));
  }
  else
  {
    TRACE_MSG(TRACE_MAC3, "  No NWK_AUX header", (FMT__0));
  }

  TRACE_MSG(TRACE_MAC3, "<< zb_debug_trace_nwk_header", (FMT__0));
}
#endif /* !ZB_CONTEXTS_IN_SEPARATE_FILE */

#endif /* defined(ZB_TRACE_LEVEL) && defined(ZB_TRACE_TRAFFIC) */


#ifdef DEBUG
void dump_hex_data(zb_uint_t trace_mask, zb_uint8_t trace_level,
                  const zb_uint8_t *buf, zb_ushort_t len)
{
  zb_ushort_t i;
  ZVUNUSED(buf);

#define TRACE_DUMP     trace_mask, trace_level

  TRACE_MSG(TRACE_DUMP, "len %hd", (FMT__H, len));

  for (i = 0 ; i < len ; i += 8U)
  {
    zb_ushort_t tmp = len - i;
    if (tmp >= 8U)
    {
      TRACE_MSG(TRACE_DUMP, "0x%hx 0x%hx 0x%hx 0x%hx 0x%hx 0x%hx 0x%hx 0x%hx",
                (FMT__H_H_H_H_H_H_H_H,
                 HEX_ARG(0), HEX_ARG(1), HEX_ARG(2), HEX_ARG(3),
                 HEX_ARG(4), HEX_ARG(5), HEX_ARG(6), HEX_ARG(7)));
    }
    else
    {
      switch (tmp)
      {
        case 7:
          TRACE_MSG(TRACE_DUMP, "0x%hx 0x%hx 0x%hx 0x%hx 0x%hx 0x%hx 0x%hx",
                    (FMT__H_H_H_H_H_H_H,
                     HEX_ARG(0), HEX_ARG(1), HEX_ARG(2), HEX_ARG(3),
                     HEX_ARG(4), HEX_ARG(5), HEX_ARG(6)));
          break;
        case 6:
          TRACE_MSG(TRACE_DUMP, "0x%hx 0x%hx 0x%hx 0x%hx 0x%hx 0x%hx",
                    (FMT__H_H_H_H_H_H,
                     HEX_ARG(0), HEX_ARG(1), HEX_ARG(2), HEX_ARG(3),
                     HEX_ARG(4), HEX_ARG(5)));
          break;
        case 5:
          TRACE_MSG(TRACE_DUMP, "0x%hx 0x%hx 0x%hx 0x%hx 0x%hx",
                    (FMT__H_H_H_H_H,
                     HEX_ARG(0), HEX_ARG(1), HEX_ARG(2), HEX_ARG(3),
                     HEX_ARG(4)));
          break;
        case 4:
          TRACE_MSG(TRACE_DUMP, "0x%hx 0x%hx 0x%hx 0x%hx",
                    (FMT__H_H_H_H,
                     HEX_ARG(0), HEX_ARG(1), HEX_ARG(2), HEX_ARG(3)));
          break;
        case 3:
          TRACE_MSG(TRACE_DUMP, "0x%hx 0x%hx 0x%hx",
                    (FMT__H_H_H,
                     HEX_ARG(0), HEX_ARG(1), HEX_ARG(2)));
          break;
        case 2:
          TRACE_MSG(TRACE_DUMP, "0x%hx 0x%hx",
                    (FMT__H_H,
                     HEX_ARG(0), HEX_ARG(1)));
          break;
        case 1:
          TRACE_MSG(TRACE_DUMP, "0x%hx",
                    (FMT__H,
                     HEX_ARG(0)));
          break;
        default:
          break;
      }
      /* Exit for loop */
      break;
    }
  }
}

static void trace_arr(zb_uint8_t *ptr, zb_bool_t format)
{
  if (format)
  {
    TRACE_MSG(TRACE_ERROR, TRACE_FORMAT_128, (FMT__A_A, TRACE_ARG_128(ptr)));
  }
  else
  {
    TRACE_MSG(TRACE_ERROR, TRACE_FORMAT_64, (FMT__A, TRACE_ARG_64(ptr)));
  }
}

void trace_hex_data_func(const zb_uint8_t *ptr, zb_short_t size, zb_bool_t format)
{
  zb_uint8_t buf[16];
  zb_uint16_t i, mod, div;
  zb_uint16_t bytes_per_line;

  ZB_ASSERT(ptr != NULL);
  ZB_ASSERT(size > 0);

  bytes_per_line = format ? 16U : 8U;

  div = ((zb_uint16_t)size) / bytes_per_line;
  mod = ((zb_uint16_t)size) % bytes_per_line;

  for (i = 0; i < div; ++i)
  {
    ZB_MEMCPY(buf, ptr + i*bytes_per_line, bytes_per_line);
    trace_arr(buf, format);
  }

  if (ZB_U2B(mod))
  {
    ZB_BZERO(buf, sizeof(buf));
    ZB_MEMCPY(buf, ptr + div*bytes_per_line, mod);
    trace_arr(buf, format);
  }
}

#endif /* DEBUG */

/*! @} */
