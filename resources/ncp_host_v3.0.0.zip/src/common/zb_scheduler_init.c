/* ZBOSS Zigbee software protocol stack
 *
 * Copyright (c) 2012-2020 DSR Corporation, Denver CO, USA.
 * www.dsr-zboss.com
 * www.dsr-corporation.com
 * All rights reserved.
 *
 * This is unpublished proprietary source code of DSR Corporation
 * The copyright notice does not evidence any actual or intended
 * publication of such source code.
 *
 * ZBOSS is a registered trademark of Data Storage Research LLC d/b/a DSR
 * Corporation
 *
 * Commercial Usage
 * Licensees holding valid DSR Commercial licenses may use
 * this file in accordance with the DSR Commercial License
 * Agreement provided with the Software or, alternatively, in accordance
 * with the terms contained in a written agreement between you and
 * DSR.
 */
/* PURPOSE: Zigbee scheduler: init
*/

/*! \addtogroup ZB_BASE */
/*! @{ */

#define ZB_TRACE_FILE_ID 125
#include "zb_common.h"


void zb_sched_init()
{
  zb_uint8_t i;

  ZB_POOLED_LIST8_INIT(ZG->sched.tm_freelist);
  ZB_POOLED_LIST8_INIT(ZG->sched.tm_queue);
  for (i = 0 ; i < ZB_SCHEDULER_Q_SIZE ; ++i)
  {
    ZB_POOLED_LIST8_INSERT_HEAD(ZG->sched.tm_buffer, ZG->sched.tm_freelist, next, i);
  }
}

zb_bool_t zb_scheduler_is_stop()
{
  if (ZB_OSIF_IS_EXIT())
  /*cstat !MISRAC2012-Rule-2.1_b */
  /** @mdr{00011,0} */
  {
    return ZB_TRUE;
  }

  if (ZG->sched.stop)
  {
    return ZB_TRUE;
  }
  return ZB_FALSE;
}

zb_bool_t zb_scheduler_is_going_to_stop()
{
  if (ZG->sched.stopping)
  {
    return ZB_TRUE;
  }
  return zb_scheduler_is_stop();
}


void zb_scheduler_set_cb_checker(zb_sched_stopping_cb_checker_t checker)
{
#ifdef ZB_ZBOSS_DEINIT
  ZG->sched.stopping_cb_checker = checker;
#else
  ZVUNUSED(checker);
#endif
}

void zb_sched_stop()
{
  TRACE_MSG(TRACE_ERROR, ">> zb_sched_stop", (FMT__0));
  ZG->sched.stop = ZB_TRUE;
}



/*! @} */
