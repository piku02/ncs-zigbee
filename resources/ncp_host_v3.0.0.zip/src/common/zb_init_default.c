/* ZBOSS Zigbee software protocol stack
 *
 * Copyright (c) 2012-2020 DSR Corporation, Denver CO, USA.
 * www.dsr-zboss.com
 * www.dsr-corporation.com
 * All rights reserved.
 *
 * This is unpublished proprietary source code of DSR Corporation
 * The copyright notice does not evidence any actual or intended
 * publication of such source code.
 *
 * ZBOSS is a registered trademark of Data Storage Research LLC d/b/a DSR
 * Corporation
 *
 * Commercial Usage
 * Licensees holding valid DSR Commercial licenses may use
 * this file in accordance with the DSR Commercial License
 * Agreement provided with the Software or, alternatively, in accordance
 * with the terms contained in a written agreement between you and
 * DSR.
 */
/* PURPOSE: ZBOSS initialization
*/

#define ZB_TRACE_FILE_ID 119
#include "zb_common.h"

#include "zb_bufpool.h"
#include "zb_ringbuffer.h"
#include "zb_scheduler.h"
#include "zb_mac_transport.h"
#ifndef ZB_MACSPLIT_DEVICE
#include "zb_aps.h"
#endif
#ifndef ZB_ALIEN_MAC
#include "zb_mac_globals.h"
#endif
#include "zb_bdb_internal.h"
#include "zb_nwk_mm.h"
#include "zb_trace_common.h"

/*! \addtogroup ZB_BASE */
/*! @{ */


#ifdef ZB_ENABLE_ZGP
void zb_zgp_init(void);
zb_uint16_t zb_zgp_ctx_size(void);
#endif /* ZB_ENABLE_ZGP */

static void trace_context_sizes(void);

#ifdef ZB_INIT_HAS_ARGS
void zb_init(zb_char_t *trace_comment)
#else
void zb_init(void)
#endif
{
  zb_uint8_t iface_idx;

#ifdef ZB_INIT_HAS_ARGS
  ZVUNUSED(trace_comment);
#endif
/*Init ZBOSS global context*/

  zb_globals_init();

#ifdef ZB_CHECK_OOM_STATUS
  ZG->oom_check_enabled = 1;
#endif

  ZB_PLATFORM_INIT();

  /* Note: for trace over GP hal must call trace init later, in Application_Init() */
#ifdef ZB_INIT_HAS_ARGS
  TRACE_INIT(trace_comment);
#else
  TRACE_INIT("");
#endif
#if defined ZB_USE_NVRAM
#ifdef ZB_INIT_HAS_ARGS
  zb_osif_nvram_init(trace_comment);
#else
  zb_osif_nvram_init("");
#endif
#endif

#ifdef ZB_USE_NVRAM
  ZB_AIB().aps_use_nvram = 1;
#endif

  ZB_ENABLE_ALL_INTER();

  zb_init_buffers();
/* macsplit device doesn't use NVRAM */
#ifndef ZB_MACSPLIT_DEVICE
  zb_ib_set_defaults((char*)"");
#endif

/* Set it to default value if it isn't set */
#ifdef ZB_CERTIFICATION_HACKS
/* Set it to max possible value if it is not initialized by user.
   Also max value used as is indication that this counter
   SHOULDN'T be taken into account at any time.
*/
if (ZB_CERT_HACKS().max_joins == 0)
{
  ZB_CERT_HACKS().max_joins = ZB_MAX_JOINS_UNINITIALIZED;
}

#endif /* ZB_CERTIFICATION_HACKS */

  zb_sched_init();
  /* some init of 8051 HW moved to zb_low_level_init() */
  /* This is preliminary MAC init. Mode init done in MLME-START.request */
  ZB_MAC_INIT();

#if !defined ZB_DIRECT_ZVD_ONLY
  zb_mac_transport_init();
#endif

#if !defined ZB_MACSPLIT_DEVICE && !defined ZB_ZGPD_ROLE
  zb_nwk_init();
#endif

#ifdef ZB_USE_SLEEP
  zb_sleep_init();
#endif

#ifdef ZB_USE_NVRAM
/*  zb_config_from_nvram();
  zb_read_up_counter();
  zb_rexoad_security_key();
  zb_read_formdesc_data();*/
#endif

#if !defined ZB_MACSPLIT_DEVICE && !defined ZB_ZGPD_ROLE
  zb_aps_init();
  zb_zdo_init();
  zdo_secur_init();

  #ifdef ZB_ENABLE_ZCL
  zb_zcl_init();
  #endif
#endif

#if defined ZB_ENABLE_ZLL
  zll_init();
#endif /* defined ZB_ENABLE_ZLL */

  for (iface_idx = 0U; iface_idx < ZB_NWK_MAC_IFACE_TBL_SIZE; iface_idx++)
  {
    SEC_CTX().encryption_buf[iface_idx] = zb_buf_get_any();
    TRACE_MSG(TRACE_MAC2, "encryption_buf: iface_idx %hd, buf_id %hd", (FMT__H_H, iface_idx, SEC_CTX().encryption_buf[iface_idx]));

/* MAC-split host is not considered as alien MAC in multi-MAC configuration, but
 * it also requires second encryption buffer */
#if defined ZB_ALIEN_MAC || defined ZB_ENABLE_ZGP_SECUR || (!defined ZB_MAC_INTERFACE_SINGLE && defined ZB_MACSPLIT_HOST)
    SEC_CTX().encryption_buf2[iface_idx] = zb_buf_get(ZB_TRUE, 0);
    TRACE_MSG(TRACE_MAC2, "encryption_buf2: iface_idx %hd, buf_id %hd", (FMT__H_H, iface_idx, SEC_CTX().encryption_buf[iface_idx]));
#endif
  }

#ifdef SNCP_MODE
  SEC_CTX().accept_partner_lk = ZB_TRUE;
#endif

#ifdef ZB_ENABLE_ZGP
  zb_zgp_init();
#endif /* ZB_ENABLE_ZGP */

  trace_context_sizes();
}

static void trace_context_sizes(void)
{
#ifdef ZB_CONFIGURABLE_MEM
  extern zb_uint_t gc_use_defaults;

  /* Unused without trace. */
  ZVUNUSED(gc_use_defaults);
#endif
  /* Note: data size is not informative for "configurable mem" builds. */
#ifdef ZB_ED_ROLE
  TRACE_MSG(TRACE_INFO1, "ED build", (FMT__0));
#else
  TRACE_MSG(TRACE_INFO1, "FFD build", (FMT__0));
#endif
#ifndef ZB_MACSPLIT_DEVICE
  TRACE_MSG(TRACE_INFO1, "sizes: g_zb %d sched %d bpool %d nwk %d aps %d addr %d zdo %d",
            (FMT__D_D_D_D_D_D_D, (zb_uint16_t)sizeof(g_zb), (zb_uint16_t)sizeof(g_zb.sched),
             (zb_uint16_t)sizeof(g_zb.bpool), (zb_uint16_t)sizeof(g_zb.nwk),
             (zb_uint16_t)sizeof(g_zb.aps), (zb_uint16_t)sizeof(g_zb.addr),
             (zb_uint16_t)sizeof(g_zb.zdo)));
#else
  TRACE_MSG(TRACE_INFO1, "sizes: g_zb %d sched %d bpool %d",
            (FMT__D_D_D, (zb_uint16_t)sizeof(g_zb), (zb_uint16_t)sizeof(g_zb.sched),
             (zb_uint16_t)sizeof(g_zb.bpool)));
#endif /* !ZB_MACSPLIT_DEVICE */
  TRACE_MSG(TRACE_INFO1, "sec %d", (FMT__D, (zb_uint16_t)sizeof(g_zb.sec)));
#ifdef ZB_ENABLE_ZCL
  TRACE_MSG(TRACE_INFO1, "zcl %d", (FMT__D, (zb_uint16_t)sizeof(g_zb.zcl)));
#endif
#ifdef ZB_ENABLE_ZLL
  TRACE_MSG(TRACE_INFO1, "zll %d", (FMT__D, (zb_uint16_t)sizeof(g_zb.zll)));
#endif
#ifdef ZB_ENABLE_ZGP
  TRACE_MSG(TRACE_INFO1, "zgp %d", (FMT__D, zb_zgp_ctx_size()));
#endif
#ifdef ZB_USE_NVRAM
  TRACE_MSG(TRACE_INFO1, "nvram %d", (FMT__D, (zb_uint16_t)sizeof(g_zb.nvram)));
#endif
#ifdef ZB_USE_BUTTONS
  TRACE_MSG(TRACE_INFO1, "buttons %d", (FMT__D, (zb_uint16_t)sizeof(g_zb.button)));
#endif
  TRACE_MSG(TRACE_INFO1, "err_ind %d", (FMT__D, (zb_uint16_t)sizeof(g_zb.err_ind)));
#ifdef USE_ZB_WATCHDOG
  TRACE_MSG(TRACE_INFO1, "watchdog %d", (FMT__D, (zb_uint16_t)sizeof(g_zb.watchdog)));
#endif

  TRACE_MSG(TRACE_INFO1, "scheduler q size %d",
            (FMT__D, (zb_uint16_t)ZB_SCHEDULER_Q_SIZE));

#ifndef ZB_ALIEN_MAC
  TRACE_MSG(TRACE_INFO1, "g_mac %d g_imac %d", (FMT__D_D, sizeof(g_mac), sizeof(g_imac)));
#endif

#ifdef ZB_CONFIGURABLE_MEM
  TRACE_MSG(TRACE_INFO1, "Configurable mem build, use ZBOSS lib defaults = %d", (FMT__D, gc_use_defaults));
#endif

#ifndef ZB_MACSPLIT_DEVICE
#ifndef ZB_ALIEN_MAC
  TRACE_MSG(TRACE_INFO1, "ZB_IOBUF_POOL_SIZE %d ZB_NWK_IN_Q_SIZE %d ZB_MAC_PENDING_QUEUE_SIZE %d ZB_APS_DST_BINDING_TABLE_SIZE %d ZB_APS_BIND_TRANS_TABLE_SIZE %d ZB_N_APS_RETRANS_ENTRIES %d",
            (FMT__D_D_D_D_D_D,
             ZB_IOBUF_POOL_SIZE,
             ZB_NWK_IN_Q_SIZE,
             ZB_MAC_PENDING_QUEUE_SIZE,
             ZB_APS_DST_BINDING_TABLE_SIZE,
             ZB_APS_BIND_TRANS_TABLE_SIZE,
             ZB_N_APS_RETRANS_ENTRIES));
#else
    TRACE_MSG(TRACE_INFO1, "ZB_IOBUF_POOL_SIZE %d ZB_NWK_IN_Q_SIZE %d ZB_APS_DST_BINDING_TABLE_SIZE %d ZB_APS_BIND_TRANS_TABLE_SIZE %d ZB_N_APS_RETRANS_ENTRIES %d",
            (FMT__D_D_D_D_D,
             ZB_IOBUF_POOL_SIZE,
             ZB_NWK_IN_Q_SIZE,
             ZB_APS_DST_BINDING_TABLE_SIZE,
             ZB_APS_BIND_TRANS_TABLE_SIZE,
             ZB_N_APS_RETRANS_ENTRIES));
#endif
#else
  TRACE_MSG(TRACE_INFO1, "ZB_IOBUF_POOL_SIZE %d ZB_MAC_PENDING_QUEUE_SIZE %d",
            (FMT__D_D,
             ZB_IOBUF_POOL_SIZE,
             ZB_MAC_PENDING_QUEUE_SIZE));
#endif  /* ZB_MACSPLIT_DEVICE */

#ifdef ZB_ROUTER_ROLE
#define ROUTING_TABLE_SIZE ZB_NWK_ROUTING_TABLE_SIZE
#else
#define ROUTING_TABLE_SIZE 0
#endif

  TRACE_MSG(TRACE_INFO1, "ZB_N_APS_KEY_PAIR_ARR_MAX_SIZE %d ZB_IEEE_ADDR_TABLE_SIZE %d ZB_NEIGHBOR_TABLE_SIZE %d ZB_NWK_ROUTING_TABLE_SIZE %d ZB_APS_DUPS_TABLE_SIZE %d",
            (FMT__D_D_D_D_D,
             ZB_N_APS_KEY_PAIR_ARR_MAX_SIZE, ZB_IEEE_ADDR_TABLE_SIZE, ZB_NEIGHBOR_TABLE_SIZE,
             ROUTING_TABLE_SIZE, ZB_APS_DUPS_TABLE_SIZE));

  /* TODO: trace sizes of all configurable components (ok, ok, we can just look into .map file) */
}


void zb_multimac_mac_init(void)
{
  zb_ret_t init_ret;
  zb_uint8_t last_iface_id = ZB_NWK_MAC_IFACE_TBL_SIZE;

  TRACE_MSG(TRACE_MAC1, ">> zb_multimac_mac_init", (FMT__0));

#if defined(ZB_MACSPLIT_HOST)
  init_ret = zb_mm_macsplit_host_register_and_enable_instance(&last_iface_id);
  ZB_ASSERT(init_ret == RET_OK);
#endif /* ZB_MACSPLIT_HOST */

#if defined ZB_MAC_MONOLITHIC || defined(ZB_MACSPLIT_DEVICE)
  init_ret = zb_mac_monolithic_register_and_enable_instance(&last_iface_id);
  ZB_ASSERT(init_ret == RET_OK);
#endif /* ZB_MAC_MONOLITHIC || ZB_MACSPLIT_DEVICE */

#ifdef ZB_EXTMAC
  zb_mac_init_extmac();
#endif

  ZB_ASSERT(last_iface_id != ZB_NWK_MAC_IFACE_TBL_SIZE);

#if !defined(ZB_MAC_INTERFACE_SINGLE) && !defined(ZB_MACSPLIT_DEVICE)
  ZB_PIBCACHE_PRIMARY_IFACE() = last_iface_id;
#endif /* ZB_MAC_INTERFACE_SINGLE*/

  TRACE_MSG(TRACE_MAC1, "<< zb_multimac_mac_init", (FMT__0));
}


void zb_multimac_mac_deinit(void)
{
#ifdef ZB_MACSPLIT_HOST
  zb_mac_macsplit_host_deinit_instance();
#endif /* ZB_MACSPLIT_HOST */
#ifdef ZB_EXTMAC
  zb_mac_deinit_extmac();
#endif
}


/*! @} */
