/* ZBOSS Zigbee software protocol stack
 *
 * Copyright (c) 2012-2020 DSR Corporation, Denver CO, USA.
 * www.dsr-zboss.com
 * www.dsr-corporation.com
 * All rights reserved.
 *
 * This is unpublished proprietary source code of DSR Corporation
 * The copyright notice does not evidence any actual or intended
 * publication of such source code.
 *
 * ZBOSS is a registered trademark of Data Storage Research LLC d/b/a DSR
 * Corporation
 *
 * Commercial Usage
 * Licensees holding valid DSR Commercial licenses may use
 * this file in accordance with the DSR Commercial License
 * Agreement provided with the Software or, alternatively, in accordance
 * with the terms contained in a written agreement between you and
 * DSR.
 */
/* PURPOSE: global structures declarations
*/

#define ZB_TRACE_FILE_ID 12199
#include "zb_common.h"

#ifdef ZB_CONTEXTS_IN_SEPARATE_FILE
zb_intr_globals_t g_izb;
zb_globals_t g_zb;
#endif

#ifdef ZB_STACK_REGRESSION_TESTING_API
zb_reg_api_t *zb_get_regression_tests_api(void)
{
  return &(ZG->reg_api);
}
#endif  /* ZB_STACK_REGRESSION_TESTING_API */
