/* ZBOSS Zigbee software protocol stack
 *
 * Copyright (c) 2012-2022 DSR Corporation, Denver CO, USA.
 * www.dsr-zboss.com
 * www.dsr-corporation.com
 * All rights reserved.
 *
 * This is unpublished proprietary source code of DSR Corporation
 * The copyright notice does not evidence any actual or intended
 * publication of such source code.
 *
 * ZBOSS is a registered trademark of Data Storage Research LLC d/b/a DSR
 * Corporation
 *
 * Commercial Usage
 * Licensees holding valid DSR Commercial licenses may use
 * this file in accordance with the DSR Commercial License
 * Agreement provided with the Software or, alternatively, in accordance
 * with the terms contained in a written agreement between you and
 * DSR.
 */
/* PURPOSE: ZBOSS global pointers assignment
*/

/*
  Define it here, before any includes, so stuff in zb_vendor.h and
  zb_mem_config_context.h implements default memory configurations
  using weak symbols.

  If no memory configuration feature compiled it, it will be just ignored.
 */
#define ZB_CONFIG_DEFAULT_KERNEL_DEFINITION

#define ZB_TRACE_FILE_ID 108
#include "zb_common.h"

#include "zb_bufpool.h"
#include "zb_ringbuffer.h"
#include "zb_scheduler.h"
#include "zb_mac_transport.h"
#ifndef ZB_MACSPLIT_DEVICE
#include "zb_aps.h"
#endif
#ifndef ZB_ALIEN_MAC
#include "zb_mac_globals.h"
#endif
#include "zb_bdb_internal.h"

#if defined ZB_CONFIGURABLE_MEM

#include "zb_mem_config_common.h"
#include "zb_mem_config_context.h"


/**
 * Global pointers assignment for configurable memory feature.
 * Split from zb_init_configurable_mem
 *  to enable compiling with optimization flags.
 */
void zb_assign_global_pointers(void)
{
  zb_uindex_t i;
  zb_uint8_t *ptr;

  ZG->bpool.pool = gc_iobuf_pool;
  ZG->bpool.busy_bufs_bitmap = gc_bufs_busy_bitmap;

#ifdef ZB_BUF_SHIELD
  ZG->bpool.buf_in_use = gc_iobuf_buf_in_use;
#endif /* ZB_BUF_SHIELD */

  /* input_q is a ring buffer of bytes. Declare single-byte ring buffer to
   * define its header.
   *
   * Regression tests notes:
   * Do not use sizeof to calculate zb_byte_array_t size as it is not packed.
   */
  ZG->nwk.handle.input_q = (zb_byte_array_t *)&gc_nwk_in_q;

  ZG->zdo.nwk_addr_req_pending_tsns = gc_nwk_addr_req_pending_tsns;
  ZG->zdo.nwk_addr_req_pending_mask = gc_nwk_addr_req_pending_mask;

#ifdef APS_FRAGMENTATION
  ZG->zdo.node_desc_req_pending_mask = gc_node_desc_req_pending_mask;
#endif /* APS_FRAGMENTATION */

#ifdef ZB_COMPILE_MAC_MONOLITHIC
#ifdef ZB_ROUTER_ROLE
  ZIG->pending_data_queue = gc_mac_pending_data_queue;
#endif /* ZB_ROUTER_ROLE */
#endif /* ZB_COMPILE_MAC_MONOLITHIC */

#ifdef ZB_MAC_SOFTWARE_PB_MATCHING
  MAC_CTX().child_hash_table = gc_child_hash_table;
  MAC_CTX().pending_bitmap = gc_pending_bitmap;
#ifdef ZB_MAC_POLL_INDICATION_CALLS_REDUCED
  MAC_CTX().poll_timestamp_table = gc_poll_timestamp_table;
#endif /* ZB_MAC_POLL_INDICATION_CALLS_REDUCED */
#endif /* ZB_MAC_SOFTWARE_PB_MATCHING */

#ifdef ZB_MACSPLIT
#ifdef ZB_MACSPLIT_DEVICE
  MACSPLIT_CTX().specific_ctx.msdu_handles = gc_msdu_handles;
#else
  MACSPLIT_CTX().specific_ctx.confirm_cb     = gc_confirm_cb;
  MACSPLIT_CTX().specific_ctx.recv_cfm       = gc_recv_cfm;
#endif
  MACSPLIT_CTX().tx_queue = (zb_byte_array_t *)&gc_macsplit_queue;
  MACSPLIT_CTX().tx_calls_table = gc_tx_calls_table;
#endif

  ZG->aps.binding.src_table = gc_aps_bind_src_table;
  ZG->aps.binding.dst_table = gc_aps_bind_dst_table;
  ZG->aps.binding.trans_table = gc_trans_table;

  ptr = (zb_uint8_t *)(gc_trans_index_buf);
  for (i = 0 ; i < ZB_APS_DST_BINDING_TABLE_SIZE ; ++i)
  {
    ZG->aps.binding.dst_table[i].trans_index = (zb_uint8_t *)(ptr + ZB_SINGLE_TRANS_INDEX_SIZE*i);
  }

  ZG->aps.retrans.hash = gc_aps_retrans;

  /* Regression tests notes:
   * Do not use sizeof to calculate zb_byte_array_t size as it is not packed.
   */
  ZG->sched.cb_q = (zb_cb_q_t *)&gc_cb_q;
  ZG->sched.tm_buffer = gc_tm_buf;
  ZG->sched.cb_flag_bm = gc_cb_flag_bm;

#if defined ZB_COORDINATOR_ROLE && defined ZB_SECURITY_INSTALLCODES
  ZG->aps.aib.installcodes_table = gc_installcodes_table;
#endif /* ZB_COORDINATOR_ROLE && ZB_SECURITY_INSTALLCODES */

  ZG->aps.aib.aps_device_key_pair_storage.key_pair_set = gc_key_pair_set;

  ZG->addr.addr_map = gc_addr_map;
  ZG->addr.short_sorted = gc_short_sorted;
  ZG->nwk.neighbor.addr_to_neighbor = gc_addr_to_neighbor;
  ZG->nwk.neighbor.neighbor = gc_neighbor;
  ZG->nwk.neighbor.disc_table = gc_ext_neighbor;
  ZG->zdo.key_negotiation_ctx = gc_key_negotiation_ctx;


#ifdef ZB_ROUTER_ROLE
  ptr = (zb_uint8_t *)(gc_passive_ack);
  for (i = 0 ; i < ZB_NWK_BRR_TABLE_SIZE ; ++i)
  {
    ZG->nwk.handle.brrt[i].passive_ack = (zb_uint8_t *)(ptr + ZB_NWK_BRCST_PASSIVE_ACK_ARRAY_SIZE*i);
  }
#endif /* ZB_ROUTER_ROLE */

#ifdef ZB_ROUTER_ROLE
  ZB_NIB().routing_table = gc_routing_table;
  ZB_NIB().nwk_src_route_tbl = gc_src_routing_table;
  ZB_NIB().route_disc_table = gc_nwk_route_disc_table;
#endif /* ZB_ROUTER_ROLE */

  ZG->aps.dups.dups_table = gc_dups_table;

#if defined NCP_MODE && !defined NCP_MODE_HOST
  ZB_NCP_CTX_CALLS() = gc_ncp_pending_calls;
#endif /* NCP_MODE && !NCP_MODE_HOST */
}

#endif /* ZB_CONFIGURABLE_MEM */
