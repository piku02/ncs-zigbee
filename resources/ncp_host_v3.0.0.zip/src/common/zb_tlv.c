/* ZBOSS Zigbee software protocol stack
 *
 * Copyright (c) 2012-2020 DSR Corporation, Denver CO, USA.
 * www.dsr-zboss.com
 * www.dsr-corporation.com
 * All rights reserved.
 *
 * This is unpublished proprietary source code of DSR Corporation
 * The copyright notice does not evidence any actual or intended
 * publication of such source code.
 *
 * ZBOSS is a registered trademark of Data Storage Research LLC d/b/a DSR
 * Corporation
 *
 * Commercial Usage
 * Licensees holding valid DSR Commercial licenses may use
 * this file in accordance with the DSR Commercial License
 * Agreement provided with the Software or, alternatively, in accordance
 * with the terms contained in a written agreement between you and
 * DSR.
 */

/* PURPOSE: TLV API
*/

#define ZB_TRACE_FILE_ID 3522

#include "zb_common.h"
#include "zb_secur.h"
#include "zb_tlv.h"

/**
 * TLV Tag IDs. Mapped on zb_tlv_tag_t
 */
static const zb_uint8_t s_tlv_id_by_tag[ZB_TLV_RESERVED_MAX] =
{
  /* 2.4.3.4.1.2 Key Update Req/Rsp Selected Key Negotiation Method TLV (ID=0) */
  0,  /* ZB_TLV_KEY_UPD_SELECTED_KEY_NEGOTIATION_METHOD,    */

  /* 2.4.3.4.1.2 Key Negotiation Req/Rsp Curve25519 Public Point TLV (ID=0)         */
  0,  /* ZB_TLV_KEY_NEG_CURVE25519_PUBLIC_POINT,            */

  /* 2.4.3.4.2.2 Requested Authentication Token ID TLV (ID=0)                   */
  0, /* ZB_TLV_REQUESTED_AUTHENTICATION_TOKEN_ID,               */


  /* 2.4.3.2.12.2 Clear All Bindings Req EUI64 TLV (ID=0) */
  0, /* ZB_TLV_CLEAR_ALL_BIND_REQ_EUI64 */

  /* 2.4.3.4.7.2 Security Decommission Req EUI64 TLV (ID=0) */
  0, /* ZB_TLV_SECUR_DECOMMISSION_REQ_EUI64 */

  0, /* ZB_TLV_DIRECT_KEY_NEG_METHOD */
  1, /* ZB_TLV_DIRECT_KEY_NEG_P256_PUBLIC_POINT */
  2, /* ZB_TLV_DIRECT_KEY_NEG_C25519_PUBLIC_POINT */
  3, /* ZB_TLV_DIRECT_NWK_KEY_SEQ_NUM */
  4, /* ZB_TLV_DIRECT_MAC_TAG_P256 */
  4, /* ZB_TLV_DIRECT_MAC_TAG_C25519 */

  0, /* ZB_TLV_DIRECT_EXT_PAN_ID, */
  1, /* ZB_TLV_DIRECT_SHORT_PAN_ID, */
  2, /* ZB_TLV_DIRECT_NWK_CHANNEL, */
  3, /* ZB_TLV_DIRECT_NWK_KEY, */
  4, /* ZB_TLV_DIRECT_LINK_KEY, */
  5, /* ZB_TLV_DIRECT_DEVICE_TYPE, */
  6, /* ZB_TLV_DIRECT_NWK_ADDR, */
  7, /* ZB_TLV_DIRECT_JOINING_METHOD, */
  8, /* ZB_TLV_DIRECT_IEEE_ADDR, */
  9, /* ZB_TLV_DIRECT_TC_ADDR, */
  10, /* ZB_TLV_DIRECT_NWK_STATUS, */
  11, /* ZB_TLV_DIRECT_NWK_UPDATE_ID, */
  12, /* ZB_TLV_DIRECT_NWK_ACTIVE_KEY_SEQ_NUM, */
  13, /* ZB_TLV_DIRECT_DISTRIBUTED_SEC_ADMIN_KEY, */
  14, /* ZB_TLV_DIRECT_STATUS_CODE */
  0, /* ZB_TLV_DIRECT_MANAGE_JOINERS_PROVISIONAL_LINK_KEY */
  1, /* ZB_TLV_DIRECT_MANAGE_JOINERS_IEEE_ADDRESS */
  2, /* ZB_TLV_DIRECT_MANAGE_JOINERS_CMD */

  /* 7.7.3.5 of the Zigbee Direct spec, Payload format */
  0, /* ZB_TLV_DIRECT_TUNNEL_NPDU */

/* 2.4.3.3.12.1 Beacon Survey Configuration TLV (ID=0) */
  0, /* ZB_TLV_BEACON_SURVEY_CONFIGURATION */

  /* 2.4.4.3.13.1 Beacon Survey Results TLV (ID=1) */
  1, /* ZB_TLV_BEACON_SURVEY_RESULTS */

  /* 2.4.4.3.13.2 Beacon Survey Potential Parents TLV (ID=2) */
  2,  /* ZB_TLV_POTENTIAL_PARENTS                 */

  /* 2.4.3.4.8.2 APS Frame Counter Challenge Req TLV (ID=0) */
  0, /* ZB_TLV_APS_FRAME_CNT_CHALLENGE_REQ */

  /* 2.4.4.4.8.2 APS Frame Counter Challenge Rsp TLV (ID=0) */
  0, /* ZB_TLV_APS_FRAME_CNT_CHALLENGE_RSP */

  /* 2.4.3.4.3.2 Target IEEE Address local TLV (ID=0)*/
  0, /* ZB_TLV_TARGET_IEEE_ADDR */

  /* 2.4.4.4.3.2 Device auth level local TLV (ID=0)*/
  0, /* ZB_TLV_DEVICE_AUTH_LEVEL */

  /* 4.4.12.10.2 Relay Message local TLV (ID=0)*/
  0, /* ZB_TLV_RELAY_MESSAGE */

  /* 4.4.11.1.4.1 Link-Key Features and Capabilities TLV (ID = 0)*/
  0, /* ZB_TLV_LINK_KEY_CAPABILITIES */

  /* 2.4.4.4.4.1.1 Processing status TLV */
  0,

  /* I.6 Global TLV IDs */
  64,  /* ZB_TLV_MANUFACTURER_SPECIFIC             */
  65,  /* ZB_TLV_SUPPORTED_KEY_NEGOTIATION_METHODS */
  66,  /* ZB_TLV_PANID_CONFLICT_REPORT */
  67,  /* ZB_TLV_NEXT_PAN_ID                       */
  68,  /* ZB_TLV_NEXT_CANNEL_CHANGE                */
  69,  /* ZB_TLV_SYMMETRIC_PASSPHRASE              */
  70,  /* ZB_TLV_ROUTER_INFORMATION                */
  71,  /* ZB_TLV_FRAGMENTATION_PARAMETRS           */
  72,  /* ZB_TLV_JOINER_ENCAPSULATION,             */
  73,  /* ZB_TLV_BEACON_APPENDIX_ENCAPSULATION,    */
  75,  /* ZB_TLV_CONFIGURATION_MODE_PARAMETERS     */
  76,  /* ZB_TLV_DEVICE_CAPABILITY_EXTENSION       */
};


/**
 * TLV Tag size. Mapped on zb_tlv_tag_t
 */
static const zb_uint8_t s_tlv_size_by_tag[ZB_TLV_RESERVED_MAX] =
{
  /* 2.4.3.4.1.2 Key Update Req/Rsp Selected Key Negotiation Method TLV (ID=0) */
  10,  /* ZB_TLV_KEY_UPD_SELECTED_KEY_NEGOTIATION_METHOD */

  /* 2.4.3.4.1.2 Key Negotiation Req/Rsp Curve25519 Public Point TLV (ID=0) */
  40, /* ZB_TLV_KEY_NEG_CURVE25519_PUBLIC_POINT */

  /* 2.4.3.4.2.2 Requested Authentication Token ID TLV (ID=0) */
  1,  /* ZB_TLV_REQUESTED_AUTHENTICATION_TOKEN_ID */

  /* 2.4.3.2.12.2 Clear All Bindings Req EUI64 TLV (ID=0) */
  0, /* ZB_TLV_CLEAR_ALL_BIND_REQ_EUI64 */

  /* 2.4.3.4.7.2 Security Decommission Req EUI64 TLV (ID=0) */
  0, /* ZB_TLV_SECUR_DECOMMISSION_REQ_EUI64 */

  2,  /* ZB_TLV_DIRECT_KEY_NEG_METHOD */
  72, /* ZB_TLV_DIRECT_KEY_NEG_P256_PUBLIC_POINT */
  40, /* ZB_TLV_DIRECT_KEY_NEG_C25519_PUBLIC_POINT */
  1,  /* ZB_TLV_DIRECT_NWK_KEY_SEQ_NUM */
  32, /* ZB_TLV_DIRECT_MAC_TAG_P256 */
  16, /* ZB_TLV_DIRECT_MAC_TAG_C25519 */

  8, /* ZB_TLV_DIRECT_EXT_PAN_ID, */
  2, /* ZB_TLV_DIRECT_SHORT_PAN_ID, */
  4, /* ZB_TLV_DIRECT_NWK_CHANNEL, */
  16, /* ZB_TLV_DIRECT_NWK_KEY, */
  17, /* ZB_TLV_DIRECT_LINK_KEY, */
  1, /* ZB_TLV_DIRECT_DEVICE_TYPE, */
  2, /* ZB_TLV_DIRECT_NWK_ADDR, */
  1, /* ZB_TLV_DIRECT_JOINING_METHOD, */
  8, /* ZB_TLV_DIRECT_IEEE_ADDR, */
  8, /* ZB_TLV_DIRECT_TC_ADDR, */
  1, /* ZB_TLV_DIRECT_NWK_STATUS, */
  1, /* ZB_TLV_DIRECT_NWK_UPDATE_ID, */
  1, /* ZB_TLV_DIRECT_NWK_ACTIVE_KEY_SEQ_NUM, */
  16, /* ZB_TLV_DIRECT_DISTRIBUTED_SEC_ADMIN_KEY, */
  2, /* ZB_TLV_DIRECT_STATUS_CODE */
  16, /* ZB_TLV_DIRECT_MANAGE_JOINERS_PROVISIONAL_LINK_KEY */
  8, /* ZB_TLV_DIRECT_MANAGE_JOINERS_IEEE_ADDRESS */
  1, /* ZB_TLV_DIRECT_MANAGE_JOINERS_CMD */

  /* 7.7.3.5 of the Zigbee Direct spec, Payload format */
  0, /* ZB_TLV_DIRECT_TUNNEL_NPDU */

  /* 2.4.3.3.12.1 Beacon Survey Configuration TLV (ID=0) */
  0, /* ZB_TLV_BEACON_SURVEY_CONFIGURATION */

  /* 2.4.4.3.13.1 Beacon Survey Results TLV (ID=1) */
  4, /* ZB_TLV_BEACON_SURVEY_RESULTS */

  /* 2.4.4.3.13.2 Beacon Survey Potential Parents TLV (ID=2) */
  0,  /* ZB_TLV_POTENTIAL_PARENTS */

  /* 2.4.3.4.8.2 APS Frame Counter Challenge Req TLV (ID=0) */
  16, /* ZB_TLV_APS_FRAME_CNT_CHALLENGE_REQ */

  /* 2.4.4.4.8.2 APS Frame Counter Challenge Rsp TLV (ID=0) */
  32, /* ZB_TLV_APS_FRAME_CNT_CHALLENGE_RSP */

  /* 2.4.3.4.3.2 Target IEEE Address local TLV (ID=0)*/
  8, /* ZB_TLV_TARGET_IEEE_ADDR */

  /* 2.4.4.4.3.2 Device auth level local TLV (ID=0)*/
  10, /* ZB_TLV_DEVICE_AUTH_LEVEL */

  /* 4.4.12.10.2 Relay Message local TLV (ID=0)*/
  0, /* ZB_TLV_RELAY_MESSAGE */

  /* 4.4.11.1.4.1 Link-Key Features and Capabilities TLV (ID = 0)*/
  1, /* ZB_TLV_LINK_KEY_CAPABILITIES */

  /* 2.4.4.4.4.1.1 Processing status TLV */
  0,

  /* I.6 Global TLV IDs */
  2,  /* ZB_TLV_MANUFACTURER_SPECIFIC             */
  10, /* ZB_TLV_SUPPORTED_KEY_NEGOTIATION_METHODS */
  2,  /* ZB_TLV_PANID_CONFLICT_REPORT             */
  2,  /* ZB_TLV_NEXT_PAN_ID                       */
  4,  /* ZB_TLV_NEXT_CANNEL_CHANGE                */
  16, /* ZB_TLV_SYMMETRIC_PASSPHRASE              */
  2,  /* ZB_TLV_ROUTER_INFORMATION                */
  5,  /* ZB_TLV_FRAGMENTATION_PARAMETRS           */
  1,  /* ZB_TLV_JOINER_ENCAPSULATION              */
  1,  /* ZB_TLV_BEACON_APPENDIX_ENCAPSULATION     */
  2,  /* ZB_TLV_CONFIGURATION_MODE_PARAMETERS     */
  2,  /* ZB_TLV_DEVICE_CAPABILITY_EXTENSION       */
};

void zb_tlv_put_tlv_hdr(zb_uint8_t **ptr, zb_tlv_tag_t tlv_tag)
{
  zb_tlv_hdr_t tlv_hdr;

  tlv_hdr.tlv_id = zb_tlv_get_id(tlv_tag);
  tlv_hdr.length = zb_tlv_get_size(tlv_tag);

  ZB_ASSERT(tlv_hdr.length > 0U);

  tlv_hdr.length -= 1U; /* because length of "tlv_val" == "tlv_len" + 1 */

  ZB_MEMCPY(*ptr, &tlv_hdr, sizeof(tlv_hdr));
  *ptr += sizeof(zb_tlv_hdr_t);
}

zb_uint8_t *zb_tlv_put_next(zb_uint8_t param, zb_tlv_tag_t tlv_tag)
{
  zb_uint8_t *buf_ptr;

  TRACE_MSG(TRACE_COMMON1, ">> zb_tlv_put_next param %hd tlv_tag %hd",
            (FMT__H_H_P, param, tlv_tag));

  buf_ptr = zb_buf_alloc_right(param, sizeof(zb_tlv_hdr_t) + zb_tlv_get_size(tlv_tag));

  if (buf_ptr != NULL)
  {
    /* Put TLV HDR */
    zb_tlv_put_tlv_hdr(&buf_ptr, tlv_tag);
  }

  TRACE_MSG(TRACE_COMMON1, "<< zb_tlv_put_next ptr %p", (FMT__P, buf_ptr));

  return buf_ptr;
}

zb_ret_t zb_tlv_status_append(zb_uint8_t param, zb_tlv_tag_t tag, zb_uint8_t status)
{
  zb_tlv_status_t *tlv_status;
  zb_ret_t ret = RET_ERROR;

  tlv_status = zb_buf_alloc_right(param, sizeof(zb_tlv_status_t));

  if (tlv_status != NULL)
  {
    tlv_status->id = zb_tlv_get_id(tag);
    tlv_status->status = status;

    ret = RET_OK;
  }

  return ret;
}

void zb_tlv_put_value_supported_key_neg_methods(zb_uint8_t param,
                                                zb_ieee_addr_t ieee_addr,
                                                zb_uint8_t *supported_key_methods,
                                                zb_uint8_t *supported_secrets)

{
  zb_uint8_t *ptr;
  zb_uint8_t offset = 0;

  /*
   * Supported Key Negotiations Global TLV
   *
   * 1                                  | 1                                   | 8
   * Key Negotiation Protocols Bitmask  | Key Negotiation PSK Secrets Bitmask | Source Device EUI64
   */

  ZB_ASSERT(ieee_addr);
  ZB_ASSERT(supported_key_methods);

  ptr = zb_tlv_put_next(param, ZB_TLV_SUPPORTED_KEY_NEGOTIATION_METHODS);

  ptr[offset] = *supported_key_methods;
  offset += 1U;

  ptr[offset] = *supported_secrets;
  offset += 1U;

  ZB_HTOLE64(ptr + offset, ieee_addr);
}

void zb_tlv_put_value_fragmentation_parameters(zb_uint8_t param,
                                               zb_uint16_t node_id,
                                               zb_uint16_t transfer_size)
{
  zb_uint8_t *ptr;
  zb_uint8_t opt = 0u;
  /*
   * Fragmentation Parameters Global TLV
   *
   * Octets: 2 | 1                     | 2
   * Node_ID   | Fragmentation Options | Maximum Reassembled
   *           |                       | Input Buffer Size
   */

  ptr = zb_tlv_put_next(param, ZB_TLV_FRAGMENTATION_PARAMETERS);

  ZB_HTOLE16(ptr, &node_id);

#if defined APS_FRAGMENTATION
  opt |= (1U << ZB_TLV_FRAGMENTATION_OPT_APS_FRAG_SUPPORT);
#endif
  ptr[2] = opt;

  ZB_HTOLE16(ptr + 3, &transfer_size);
}

#if defined ZB_ROUTER_ROLE
void zb_tlv_put_value_router_information(zb_uint8_t param)
{
  zb_uint8_t *ptr;
  zb_uint16_t router_info = 0u;

  /*
   * Router Information Global TLV
   *
   * This TLV is 2-bytes in length and is a bitmask indicating data about the local router.
   *
   * Bits | Name
   * 0    | Hub Connectivity
   * 1    | Uptime
   * 2    | Preferred parent
   * 3    | Battery Backup
   * 4    | Enhanced Beacon Request Support
   * 5    | MAC Data Poll Keep alive Support
   * 6    | End Device Keepalive Support
   * 7    | Power Negotiation Support
   * 8-16 | Reserved. These bits SHALL be set to 0.
   */


  ptr = zb_tlv_put_next(param, ZB_TLV_ROUTER_INFORMATION);

  /* Aggregate different router information into this TLV */

  if (ZB_U2B(ZB_NIB().nwk_preferred_parent))
  {
    router_info |= (1u << ZB_TLV_ROUTER_INFORMATION_PREFERRED_PARENT);
  }

  if (ZB_U2B(ZB_NIB().nwk_keepalive_modes & MAC_DATA_POLL_KEEPALIVE))
  {
    router_info |= (1u << ZB_TLV_ROUTER_INFORMATION_MAC_DATA_POLL_KEEPALIVE_SUPPORT);
  }

  if (ZB_U2B(ZB_NIB().nwk_keepalive_modes & ED_TIMEOUT_REQUEST_KEEPALIVE))
  {
    router_info |= (1u << ZB_TLV_ROUTER_INFORMATION_END_DEVICE_KEEPALIVE_SUPPORT);
  }

  router_info |= ((zb_uint16_t)ZB_NIB().nwk_hub_connectivity << ZB_TLV_ROUTER_INFORMATION_HUB_CONNECTIVITY);
  router_info |= ((zb_uint16_t)ZB_NIB().nwk_long_uptime << ZB_TLV_ROUTER_INFORMATION_UPTIME);

#ifdef ZB_ENHANCED_BEACON_SUPPORT
  router_info |= (1u << ZB_TLV_ROUTER_INFORMATION_ENHANCED_BEACON_REQ_SUPPORT);
#endif
#ifdef ZB_MAC_POWER_CONTROL
  router_info |= (1u << ZB_TLV_ROUTER_INFORMATION_POWER_NEGOTIATION_SUPPORT);
#endif

  ZB_HTOLE16(ptr, &router_info);
}
#endif

void zb_tlv_put_value_device_capability_extension(zb_uint8_t param, zb_uint16_t dev_capability_ext_value)
{
  zb_uint8_t *ptr;

  /*
   * Device Capability Extension Global TLV
   *
   * This TLV is 2-bytes in length and is a bitmask indicating extra information
   * about the device capabilities next to the Capability Information Bit-fields (as known from the
   * MAC Association command, and re-listed in [R4]).
   *
   * Bits | Name
   * 0    | Zigbee Direct Virtual Device
   *        (0 = Device is IEEE 802.15.4 based device 1 = Device is Zigbee Direct Virtual Device)
   * 1-15 | Reserved.
   */

  ptr = zb_tlv_put_next(param, ZB_TLV_DEVICE_CAPABILITY_EXTENSION);

  ZB_HTOLE16(ptr, &dev_capability_ext_value);
}

void zb_tlv_put_value_selected_key_neg_method(zb_uint8_t param,
                                              zb_ieee_addr_t ieee_addr,
                                              zb_uint8_t *selected_key_neg_method,
                                              zb_uint8_t *selected_psk_secret)
{
  zb_uint8_t *ptr;

  /*
   * Key Negotiation Req Selected Key Negotiation Method TLV (ID=01)
   *
   * This indicates the key negotiated method that the sending device would like to negotiate with
   * the receiver.
   *
   * Selected Key Enumeration              |
   * Selected Preshared Secret Enumeration |
   * Device ieee addr
   */

  ZB_ASSERT(selected_key_neg_method);

  ptr = zb_tlv_put_next(param, ZB_TLV_KEY_UPD_SELECTED_KEY_NEGOTIATION_METHOD);

  *ptr = *selected_key_neg_method;
  ptr++;

  *ptr = *selected_psk_secret;
  ptr++;

  ZB_PUT_NEXT_IEEE(ptr, ieee_addr);

  /* to avoid a MISRA violation of the MISRAC2012-Rule-2.2_c:
   * value assigned to a variable is never used.
   */
  ZVUNUSED(ptr);
}

#if defined ZB_COORDINATOR_ROLE || defined ZB_ROUTER_ROLE

void zb_tlv_put_value_symmetric_passphrase(zb_uint8_t param, zb_uint8_t *passphrase)
{
  zb_uint8_t *ptr;

  /*
   * 128-bit Symmetric Passphrase Global TLV (ID 69)
   *
   * This TLV is 16-bytes in length and indicates a 128-bit Symmetric Passphrase.
   */

  ZB_ASSERT(passphrase);

  ptr = zb_tlv_put_next(param, ZB_TLV_SYMMETRIC_PASSPHRASE);

  ZB_MEMCPY(ptr, passphrase, ZB_CCM_KEY_SIZE);
}

#endif /* ZB_COORDINATOR_ROLE || ZB_ROUTER_ROLE */

void put_val_start_k_neg_rq_rsp(zb_uint8_t param,
                                zb_ieee_addr_t ieee_addr,
                                zb_uint8_t *public_point)
{
  zb_tlv_put_value_start_key_neg_req_rsp_public_point_common(param, ieee_addr, public_point, ZB_ECC_CURVE_25519, ZB_TRUE);
}

void put_val_start_k_neg_rq_rsp_cmn(zb_uint8_t param,
                                    zb_ieee_addr_t ieee_addr,
                                    zb_uint8_t *public_point,
                                    zb_uint8_t curve_id,
                                    zb_bool_t is_dlk)
{
  zb_uint8_t *ptr;

  /*
   * Key Negotiation Req/Rsp Curve25519 Public Point TLV
   *
   * Format of the Key Negotiation Req Curve25519 Public Point TLV
   *
   * Octets: 8    | 32
   * Device EUI64 | Public Point
   *
   *
   * Format of the Key Negotiation Rsp Public Point TLV
   *
   * Octets: 8    | 32
   * Device EUI64 | Public Point
   */

  ZB_ASSERT(ieee_addr);
  ZB_ASSERT(public_point);

  if (is_dlk)
  {
    ptr = zb_tlv_put_next(param, ZB_TLV_KEY_NEG_CURVE25519_PUBLIC_POINT);
    curve_id = ZB_ECC_CURVE_25519;
  }
  else
  {
    ptr = zb_tlv_put_next(param, ZB_TLV_DIRECT_KEY_NEG_PUBLIC_POINT(curve_id));
  }

  ZB_PUT_NEXT_IEEE(ptr, ieee_addr);
  ZB_MEMCPY(ptr, public_point, ZB_DLK_PUB_KEY_LEN(curve_id));
}

#if defined ZB_JOIN_CLIENT

void zb_tlv_put_value_authentication_token(zb_uint8_t param)
{
  zb_uint8_t *ptr;

  /*
   * Requested Authentication Token ID TLV (ID=0)
   *
   * The Global TLV Type ID being requested for an authentication token.
   *
   * Octets: 1   |
   * TLV Type ID |
   */

  ptr = zb_tlv_put_next(param, ZB_TLV_REQUESTED_AUTHENTICATION_TOKEN_ID);

  *ptr = ZB_TLV_SUPPORTED_AUTHENTICATION_TOKEN;
}

#endif /* ZB_JOIN_CLIENT */

zb_uint8_t zb_tlv_get_id(zb_tlv_tag_t tlv_tag)
{
  ZB_ASSERT(tlv_tag < ZB_TLV_RESERVED_MAX);

  return s_tlv_id_by_tag[tlv_tag];
}


zb_tlv_tag_t zb_tlv_get_tag(zb_tlv_tag_t tlv_tag, zb_uint8_t tlv_id)
{
  zb_tlv_tag_t i;

  for (i = tlv_tag; i < ZB_TLV_RESERVED_MAX; ++i)
  {
    if (tlv_id == s_tlv_id_by_tag[i])
    {
      break;
    }
  }

  if (i == ZB_TLV_NOT_FOUND)
  {
    TRACE_MSG(TRACE_ERROR, "zb_tlv_get_tag: TLV ID %d is not supported", (FMT__D, tlv_id));
  }

  return i;
}

zb_uint8_t zb_tlv_get_size(zb_tlv_tag_t tlv_tag)
{
  ZB_ASSERT(tlv_tag < ZB_TLV_RESERVED_MAX);

  return s_tlv_size_by_tag[tlv_tag];
}

zb_ret_t zb_tlv_get_next(zb_uint8_t const **buf_ptr, zb_uint8_t *buf_len)
{
  zb_tlv_hdr_t tlv;
  zb_ret_t ret = RET_OK;

  TRACE_MSG(TRACE_COMMON1, ">> zb_tlv_get_next, buf_ptr %p, buf_len %hd", (FMT__P_H, *buf_ptr, *buf_len));

  if (*buf_ptr != NULL)
  {
    zb_uint16_t full_tlv_len;

    ZB_MEMCPY(&tlv, *buf_ptr, sizeof(zb_tlv_hdr_t));
    /* because length of "tlv_value" == "tlv_len" + 1*/
    full_tlv_len = (zb_uint16_t)sizeof(zb_tlv_hdr_t) + tlv.length + 1U;

    if (*buf_len >= full_tlv_len)
    {
      /*
       * According to r23 spec I.4.4 we should ignore unknown TLVs and no processing should be
       * done for them, so let's consider that tlv_ptr->length is correct.
       * Moreover, in case of bad tlv_ptr->length we can't detect other TLVs properly, so it will
       * cause the error(no processing too) for the last TLV (see zb_tlv_general_tlv_processing()).
       */
      *buf_ptr += full_tlv_len;
      *buf_len -= (zb_uint8_t)full_tlv_len;
    }
    else
    {
      TRACE_MSG(TRACE_COMMON3, "buf_len %hd full_tlv_len %hd - malformed tlv!",
                (FMT__H_H, *buf_len, full_tlv_len));
      ret = RET_ERROR;
    }
  }

  TRACE_MSG(TRACE_COMMON1, "<< zb_tlv_get_next ret %d, buf_ptr %p, buf_len %d",
            (FMT__D_P_D, ret, *buf_ptr, *buf_len));

  return ret;
}

zb_ret_t zb_tlv_general_tlv_processing(zb_uint8_t const *tlv_ptr, zb_uint8_t tlv_data_len)
{
  zb_ret_t ret = RET_NOT_FOUND;
  zb_tlv_hdr_t tlv_hdr;
  zb_tlv_tag_t tlv_tag;
  /* I.4.8: 2. Check for any duplicate TLV tag IDs */
  zb_uint8_t duplicate_check_list[ZB_TLV_RESERVED_MAX];

  if (ZB_R22_GU_BEHAVIOR_ENABLED())
  {
    return RET_NOT_FOUND;
  }

  ZB_ASSERT(tlv_ptr);

  TRACE_MSG(TRACE_COMMON1, ">> zb_tlv_general_tlv_processing, tlv_ptr %hd, tlv_data_len %hd",
            (FMT__H_H, *tlv_ptr, tlv_data_len));

  ZB_BZERO(duplicate_check_list, sizeof(duplicate_check_list));

  while (tlv_data_len > 0U)
  {
    ZB_MEMCPY(&tlv_hdr, tlv_ptr, sizeof(zb_tlv_hdr_t));
    ret = zb_tlv_get_next(&tlv_ptr, &tlv_data_len);

    if (ret != RET_OK)
    {
      /* TLV is malformed. Stop processing.*/
      TRACE_MSG(TRACE_ERROR, "zb_tlv_general_tlv_processing: tlv is malformed", (FMT__0));
      ret = RET_INVALID_FORMAT;
      break;
    }

    /*
     * Always start from the minimal local TLV as here it's needed only for duplicate check.
     * Minimal size should be checked while searching certain local TLV.
     */
    tlv_tag = zb_tlv_get_tag(ZB_TLV_TAG_LOCAL_MIN, tlv_hdr.tlv_id);
    /*
     * I.4.4
     * An Unknown Tag is defined as one where the Tag ID is neither a defined global ID nor is the
     * ID a Local ID defined for the specific command or datagram containing the TLV.
     * Receiving devices SHALL ignore all unknown Tag IDs and no processing SHALL be done for them.
     */
    if (tlv_tag == ZB_TLV_NOT_FOUND)
    {
      continue;
    }

    if (!ZB_U2B(duplicate_check_list[tlv_tag]))
    {
      duplicate_check_list[tlv_tag] = 1U;
    }
    else if (tlv_tag != ZB_TLV_MANUFACTURER_SPECIFIC)
    {
      /* TLV ID is duplicated. Stop processing.*/
      TRACE_MSG(TRACE_ERROR, "zb_tlv_general_tlv_processing: TLV ID is duplicated", (FMT__0));
      ret = RET_INVALID_FORMAT;
      break;
    }
    else
    {
      /* MISRA rule 15.7 requires empty 'else' branch. */
    }

    /* 04/17/2020 EE CR:MAJOR add check for encapsulation TLVs and minimal TLV length according to I.4.8	General TLV processing */
  }

  TRACE_MSG(TRACE_COMMON1, "<< zb_tlv_general_tlv_processing ret %d", (FMT__D, ret));

  return ret;
}


zb_tlv_hdr_t* zb_tlv_get_tlv_ptr(zb_tlv_tag_t tlv_tag,
                                 zb_uint8_t const *tlv_ptr,
                                 zb_uint8_t tlv_data_len)
{
  /* Initialize by 0, else you can return a garbage if tlv_data_len == 0 */
  void *res_ptr = NULL;
  zb_tlv_hdr_t tlv_hdr_parsed;

  ZB_ASSERT(tlv_ptr);

  TRACE_MSG(TRACE_COMMON1, ">> zb_tlv_get_tlv_ptr, tlv_id %hd, tlv_ptr %hd, tlv_data_len %hd",
            (FMT__H_H_H, zb_tlv_get_id(tlv_tag), *tlv_ptr, tlv_data_len));

  while (tlv_data_len > 0U)
  {
    ZB_MEMCPY(&tlv_hdr_parsed, tlv_ptr, sizeof(zb_tlv_hdr_t));
    ZB_MEMCPY(&res_ptr, &tlv_ptr, sizeof(zb_tlv_hdr_t*));

    if (zb_tlv_get_next(&tlv_ptr, &tlv_data_len) != RET_OK)
    {
      /* TLV is malformed. Stop processing.*/
      TRACE_MSG(TRACE_ERROR, "zb_tlv_get_tlv_ptr: TLV is malformed", (FMT__0));
      res_ptr = NULL;
      break;
    }

    if (zb_tlv_get_id(tlv_tag) == tlv_hdr_parsed.tlv_id)
    {
      TRACE_MSG(TRACE_COMMON1, "zb_tlv_get_tlv_ptr: TLV is found", (FMT__0));
      break;
    }

    res_ptr = NULL;
  }

  TRACE_MSG(TRACE_COMMON1, "<< zb_tlv_get_tlv_ptr, res_ptr %p", (FMT__P, res_ptr));

  return (zb_tlv_hdr_t*)res_ptr;
}

zb_ret_t zb_tlv_parse_value_supported_key_neg_methods(zb_uint8_t *tlv_ptr,
                                                      zb_uint8_t tlv_data_len,
                                                      zb_ieee_addr_t ieee_addr,
                                                      zb_uint8_t *supported_key_methods,
                                                      zb_uint8_t *supported_secrets)
{
  zb_ret_t ret = RET_OK;
  zb_tlv_hdr_t *tlv_hdr_ptr;
  zb_uint8_t *tlv_ieee_addr_ptr;

  TRACE_MSG(TRACE_COMMON1, ">> zb_tlv_parse_value_supported_key_neg_methods, tlv_data_len %hd", (FMT__H, tlv_data_len));
  /*
   * Supported Key Negotiations Global TLV
   *
   *  1                                  | 1                                     | 8
   *  Key Negotiation Protocols Bitmask  | Supported Pre-shared Secrets Bitmask  | Source Device EUI64
   */

  ZB_ASSERT(tlv_ptr != NULL);

  tlv_hdr_ptr = zb_tlv_get_tlv_ptr(ZB_TLV_SUPPORTED_KEY_NEGOTIATION_METHODS, tlv_ptr, tlv_data_len);

  if (tlv_hdr_ptr == NULL)
  {
    ret = RET_NOT_FOUND;
  }

  if ((ret == RET_OK)
        && (ieee_addr != NULL)
        && (supported_key_methods != NULL)
        && (supported_secrets != NULL))
  {
    *supported_key_methods = *ZB_TLV_GET_BODY_PTR(tlv_hdr_ptr);
    *supported_secrets = ZB_TLV_GET_BODY_PTR(tlv_hdr_ptr)[sizeof(zb_uint8_t)];

    tlv_ieee_addr_ptr = &ZB_TLV_GET_BODY_PTR(tlv_hdr_ptr)[sizeof(zb_uint8_t) + sizeof(zb_uint8_t)];
    ZB_IEEE_ADDR_COPY(ieee_addr, tlv_ieee_addr_ptr);
  }
  else
  {
    ret = RET_ERROR;
  }

  TRACE_MSG(TRACE_COMMON1, "<< zb_tlv_parse_value_supported_key_neg_methods, ret %hd", (FMT__H, ret));
  return ret;
}

zb_ret_t zb_tlv_parse_value_fragmentation_parameters(zb_uint8_t *tlv_ptr,
                                                     zb_uint8_t tlv_data_len,
                                                     zb_uint16_t *short_addr,
                                                     zb_uint8_t *frag_opt,
                                                     zb_uint16_t *max_incoming_transfer_size)
{
  zb_ret_t ret = RET_OK;
  zb_tlv_hdr_t *tlv_hdr_ptr;
  zb_uint8_t *tlv_short_addr_ptr;
  zb_uint8_t *tlv_max_incoming_transfer_size_ptr;

  /*
   * Fragmentation Parameters Global TLV
   *
   * Octets: 2 | 1                     | 2
   * Node_ID   | Fragmentation Options | Maximum Reassembled
   *           |                       | Input Buffer Size
   */

  tlv_hdr_ptr = zb_tlv_get_tlv_ptr(ZB_TLV_FRAGMENTATION_PARAMETERS, tlv_ptr, tlv_data_len);

  if (tlv_hdr_ptr == NULL)
  {
    ret = RET_NOT_FOUND;
  }

  if ((ret == RET_OK) && (short_addr != NULL) && (frag_opt != NULL) && (max_incoming_transfer_size != NULL))
  {
    tlv_short_addr_ptr = ZB_TLV_GET_BODY_PTR(tlv_hdr_ptr);
    ZB_LETOH16(short_addr, tlv_short_addr_ptr);

    *frag_opt = ZB_TLV_GET_BODY_PTR(tlv_hdr_ptr)[sizeof(zb_uint16_t)];

    tlv_max_incoming_transfer_size_ptr = &(ZB_TLV_GET_BODY_PTR(tlv_hdr_ptr)[sizeof(zb_uint16_t) + sizeof(zb_uint8_t)]);
    ZB_LETOH16(max_incoming_transfer_size, tlv_max_incoming_transfer_size_ptr);
  }
  else
  {
    ret = RET_ERROR;
  }

  TRACE_MSG(TRACE_COMMON1, "zb_tlv_parse_value_fragmentation_parameters, ret %hd", (FMT__H, ret));
  return ret;
}


#ifdef ZB_DIRECT_ENABLED
zb_ret_t zb_tlv_parse_value_device_capability_extension_parameters(
  zb_uint8_t *tlv_ptr,
  zb_uint8_t tlv_data_len,
  zb_uint16_t *capability_extension)
{
  zb_ret_t ret = RET_OK;
  zb_tlv_hdr_t *tlv_hdr_ptr;
  zb_uint8_t *capability_extension_ptr;

  /*
   * Device Capability Extension Global TLV
   *
   * Bits | Name
   * 0    | Zigbee Direct Virtual Device
   *        (0 = Device is IEEE 802.15.4 based device 1 = Device is Zigbee Direct Virtual Device)
   * 1-15 | Reserved.
   */

  tlv_hdr_ptr = zb_tlv_get_tlv_ptr(ZB_TLV_DEVICE_CAPABILITY_EXTENSION, tlv_ptr, tlv_data_len);

  if (tlv_hdr_ptr == NULL)
  {
    ret = RET_NOT_FOUND;
  }

  if ((ret == RET_OK) && (capability_extension != NULL))
  {
    capability_extension_ptr = ZB_TLV_GET_BODY_PTR(tlv_hdr_ptr);
    ZB_LETOH16(capability_extension, capability_extension_ptr);

    TRACE_MSG(TRACE_COMMON1, "  capability_extension = 0x%x", (FMT__D, *capability_extension));
  }
  else
  {
    ret = RET_ERROR;
  }

  TRACE_MSG(TRACE_COMMON1, "zb_tlv_parse_device_capability_extension_parameters, ret %hd", (FMT__H, ret));
  return ret;
}
#endif /* ZB_DIRECT_ENABLED */


zb_ret_t zb_tlv_parse_value_router_information(zb_uint8_t *tlv_ptr,
                                              zb_uint8_t tlv_data_len,
                                              zb_uint16_t *router_info)
{
  zb_ret_t ret = RET_OK;
  zb_tlv_hdr_t *tlv_hdr_ptr;
  zb_uint8_t *tlv_router_info_ptr;

  /*
   * Router Information Global TLV
   *
   * This TLV is 2-bytes in length and is a bitmask indicating data about the local router.
   *
   * Bits | Name
   * 0    | Hub Connectivity
   * 1    | Uptime
   * 2    | Preferred parent
   * 3    | Battery Backup
   * 4    | Enhanced Beacon Request Support
   * 5    | MAC Data Poll Keep alive Support
   * 6    | End Device Keepalive Support
   * 7    | Power Negotiation Support
   * 8-16 | Reserved. These bits SHALL be set to 0.
   */

  tlv_hdr_ptr = zb_tlv_get_tlv_ptr(ZB_TLV_ROUTER_INFORMATION, tlv_ptr, tlv_data_len);

  if ((tlv_hdr_ptr != NULL) && (router_info != NULL))
  {
    zb_uint16_t rinfo;
    tlv_router_info_ptr = ZB_TLV_GET_BODY_PTR(tlv_hdr_ptr);
    ZB_LETOH16(&rinfo, tlv_router_info_ptr);
    /* We can be in Amazon WWAH mode. In such case 2 bits of router information
     * are already set from 2 reserved bits of beacon payload. Merge with that
     * info. */
    *router_info |= rinfo;
  }
  else
  {
    ret = RET_ERROR;
  }

  TRACE_MSG(TRACE_COMMON1, "zb_tlv_parse_value_router_information, ret %hd", (FMT__H, ret));
  return ret;
}

zb_ret_t zb_tlv_parse_value_conf_mode_param(zb_uint8_t *tlv_ptr,
                                            zb_uint8_t tlv_data_len,
                                            zb_uint16_t *bitmask)
{
  zb_ret_t ret = RET_OK;
  zb_tlv_hdr_t *tlv_hdr_ptr;
  zb_uint8_t  *tlv_value_ptr;

  /*
   * Configuration Mode Parameters TLV
   *
   * The Configuration Parameters TLV is 2-bytes in length and indicates
   * various parameters about how the stack SHALL behave
   *
   * Bits | Name
   * 0    | apsZdoConfigurationMode
   * 1    | requireLinkKeyEncryptionForApsTransportKey
   * 2    | nwkLeaveRequestAllowed
   * 3-16 | Reserved. These bits SHALL be set to 0.
   */
  tlv_hdr_ptr = zb_tlv_get_tlv_ptr(ZB_TLV_CONFIGURATION_MODE_PARAMETERS, tlv_ptr, tlv_data_len);

  if ((tlv_hdr_ptr != NULL) && (bitmask != NULL))
  {
    tlv_value_ptr = ZB_TLV_GET_BODY_PTR(tlv_hdr_ptr);
    ZB_LETOH16(bitmask, tlv_value_ptr);
  }
  else
  {
    ret = RET_ERROR;
  }

  return ret;
}

zb_ret_t zb_tlv_parse_value_next_channel_change(zb_uint8_t *tlv_ptr,
                                                zb_uint8_t tlv_data_len,
                                                zb_uint32_t *channel_mask)
{
  zb_ret_t ret = RET_OK;
  zb_tlv_hdr_t *tlv_hdr_ptr;
  zb_uint8_t  *tlv_value_ptr;

  /*
   * Next Channel Change Global TLV
   *
   * This TLV is 4-bytes in length and indicates the next channel
   * that will be used once a start channel change command is received.
   */
  tlv_hdr_ptr = zb_tlv_get_tlv_ptr(ZB_TLV_NEXT_CANNEL_CHANGE, tlv_ptr, tlv_data_len);

  if ((tlv_hdr_ptr != NULL) && (channel_mask != NULL))
  {
    tlv_value_ptr = ZB_TLV_GET_BODY_PTR(tlv_hdr_ptr);
    ZB_LETOH32(channel_mask, tlv_value_ptr);
  }
  else
  {
    ret = RET_ERROR;
  }

  return ret;
}

zb_ret_t zb_tlv_parse_value_next_pan_id(zb_uint8_t *tlv_ptr,
                                        zb_uint8_t tlv_data_len,
                                        zb_uint16_t *pan_id)
{
  zb_ret_t ret = RET_OK;
  zb_tlv_hdr_t *tlv_hdr_ptr;
  zb_uint8_t  *tlv_value_ptr;

  ZB_ASSERT(pan_id);
  /*
   * Next PAN ID Change Global TLV
   *
   */
  tlv_hdr_ptr = zb_tlv_get_tlv_ptr(ZB_TLV_NEXT_PAN_ID, tlv_ptr, tlv_data_len);

  if (tlv_hdr_ptr != NULL)
  {
    tlv_value_ptr = ZB_TLV_GET_BODY_PTR(tlv_hdr_ptr);
    ZB_LETOH16(pan_id, tlv_value_ptr);
  }
  else
  {
    ret = RET_ERROR;
  }

  return ret;
}

#if defined ZB_JOIN_CLIENT

zb_ret_t zb_tlv_parse_value_symmetric_passphrase(zb_uint8_t *tlv_ptr,
                                                 zb_uint8_t tlv_data_len,
                                                 zb_uint8_t *passphrase)
{
  zb_ret_t ret = RET_OK;
  zb_tlv_hdr_t *tlv_hdr_ptr;
  zb_uint8_t *tlv_passphrase_ptr;

  /*
   * 128-bit Symmetric Passphrase Global TLV (ID 69)
   *
   * This TLV is 16-bytes in length and indicates a 128-bit Symmetric Passphrase.
   */

  tlv_hdr_ptr = zb_tlv_get_tlv_ptr(ZB_TLV_SYMMETRIC_PASSPHRASE, tlv_ptr, tlv_data_len);

  if ((tlv_hdr_ptr != NULL) && (passphrase != NULL))
  {
    tlv_passphrase_ptr = ZB_TLV_GET_BODY_PTR(tlv_hdr_ptr);
    ZB_MEMCPY(passphrase, tlv_passphrase_ptr, ZB_CCM_KEY_SIZE);
  }
  else
  {
    ret = RET_ERROR;
  }

  return ret;
}

#endif /* ZB_JOIN_CLIENT */

zb_ret_t prs_vl_st_key_neg_rq_rsp_pb_pt(zb_uint8_t *tlv_ptr,
                                        zb_uint8_t tlv_data_len,
                                        zb_ieee_addr_t ieee_addr,
                                        zb_uint8_t *public_point)
{
  return prs_vl_st_keyn_rq_rsp_pb_pt_cmn(tlv_ptr, tlv_data_len, ieee_addr, public_point, ZB_ECC_CURVE_25519, ZB_TRUE);
}

zb_ret_t prs_vl_st_keyn_rq_rsp_pb_pt_cmn(const zb_uint8_t *tlv_ptr,
                                         zb_uint8_t tlv_data_len,
                                         zb_ieee_addr_t ieee_addr,
                                         zb_uint8_t *public_point,
                                         zb_uint8_t curve_id,
                                         zb_bool_t is_dlk)
{
  zb_ret_t ret = RET_OK;
  zb_tlv_hdr_t *tlv_hdr_ptr = NULL;
  zb_uint8_t *tlv_ieee_addr_ptr;
  zb_uint8_t *tlv_public_point_ptr;
  zb_tlv_tag_t tlv_tag;
  zb_bool_t tag_is_set = ZB_FALSE;
  zb_uint8_t body_len;

  /*
   * Key Negotiation Req/Rsp Curve25519/P-256 Public Point TLV
   *
   * Format of the Key Negotiation Req Curve25519 Public Point TLV
   *
   * Octets: 8    | 32
   * Device EUI64 | Public Point
   *
   *
   * Format of the Key Negotiation Rsp Public Point TLV
   *
   * Octets: 8    | 64
   * Device EUI64 | Public Point
   */


  if (is_dlk)
  {
    tlv_tag = ZB_TLV_KEY_NEG_CURVE25519_PUBLIC_POINT;
    curve_id = ZB_ECC_CURVE_25519;
    tag_is_set = ZB_TRUE;
  }
  else
  {
#ifdef ZB_ECDHE_P256_ENABLED
    if (curve_id == ZB_ECC_CURVE_P256)
    {
      tlv_tag = ZB_TLV_DIRECT_KEY_NEG_P256_PUBLIC_POINT;
      tag_is_set = ZB_TRUE;
    }
#endif
#ifdef ZB_ENABLE_MONTGOMERY_CURVES
    if (curve_id == ZB_ECC_CURVE_25519)
    {
      tlv_tag = ZB_TLV_DIRECT_KEY_NEG_C25519_PUBLIC_POINT;
      tag_is_set = ZB_TRUE;
    }
#endif
  }

  if (tag_is_set)
  {
    tlv_hdr_ptr = zb_tlv_get_tlv_ptr(tlv_tag, tlv_ptr, tlv_data_len);
    body_len = tlv_hdr_ptr->length + 1u;
    if (body_len < (8u + ZB_DLK_PUB_KEY_LEN(curve_id)))
    {
      ret = RET_ERROR;
      return ret;
    }
  }

  if (tlv_hdr_ptr != NULL)
  {
    if (ieee_addr != NULL)
    {
      tlv_ieee_addr_ptr = ZB_TLV_GET_BODY_PTR(tlv_hdr_ptr);
      ZB_IEEE_ADDR_COPY(ieee_addr, tlv_ieee_addr_ptr);
    }

    if (public_point != NULL)
    {
      tlv_public_point_ptr = &ZB_TLV_GET_BODY_PTR(tlv_hdr_ptr)[sizeof(zb_ieee_addr_t)];
      ZB_MEMCPY(public_point, tlv_public_point_ptr, ZB_DLK_PUB_KEY_LEN(curve_id));
    }
  }
  else
  {
    ret = RET_NOT_FOUND;
  }

  return ret;
}

zb_ret_t zb_tlv_parse_value_selected_key_neg_method(zb_uint8_t *tlv_ptr,
                                                    zb_uint8_t tlv_data_len,
                                                    zb_ieee_addr_t ieee_addr,
                                                    zb_uint8_t *selected_key_neg_method,
                                                    zb_uint8_t *selected_psk_secret)
{
  zb_ret_t ret = RET_OK;
  zb_tlv_hdr_t *tlv_hdr_ptr;
  zb_uint8_t *tlv_ieee_addr_ptr;

  /*
   * Key Negotiation Req Selected Key Negotiation Method TLV (ID=01)
   *
   * This indicates the key negotiated method that the sending device would like to negotiate with
   * the receiver.
   *
   *  Octets: 1                 | Octets: 1                              | 8
   *  Selected Key Enumeration  | Selected Pre-shared Secret Enumeration | IEEE Addr
   */

  tlv_hdr_ptr = zb_tlv_get_tlv_ptr(ZB_TLV_KEY_UPD_SELECTED_KEY_NEGOTIATION_METHOD, tlv_ptr, tlv_data_len);

  if (tlv_hdr_ptr != NULL)
  {
    if (selected_key_neg_method != NULL)
    {
      *selected_key_neg_method = *ZB_TLV_GET_BODY_PTR(tlv_hdr_ptr);
    }

    if (selected_key_neg_method != NULL)
    {
      *selected_psk_secret = ZB_TLV_GET_BODY_PTR(tlv_hdr_ptr)[sizeof(zb_uint8_t)];
    }

    if (ieee_addr != NULL)
    {
      tlv_ieee_addr_ptr = &ZB_TLV_GET_BODY_PTR(tlv_hdr_ptr)[sizeof(zb_uint8_t) + sizeof(zb_uint8_t)];
      ZB_IEEE_ADDR_COPY(ieee_addr, tlv_ieee_addr_ptr);
    }
  }
  else
  {
    ret = RET_ERROR;
  }

  return ret;
}

zb_ret_t zb_tlv_direct_parse_value_selected_key_neg_method(const zb_uint8_t *tlv_ptr,
                                                           zb_uint8_t tlv_data_len,
                                                           zb_uint8_t *selected_key_neg_method,
                                                           zb_uint8_t *selected_secret)
{
  zb_ret_t ret = RET_OK;
  zb_tlv_hdr_t *tlv_hdr_ptr;

  /*
   * Key Negotiation Req Selected Key Negotiation Method TLV (ID=0)
   *
   * This indicates the key negotiated method that the sending device would like to negotiate with
   * the receiver.
   *
   * Octets: 1                 | Octets: 1
   * Selected Key Enumeration  | Selected Pre-shared Secret Enumeration
   */

  tlv_hdr_ptr = zb_tlv_get_tlv_ptr(ZB_TLV_DIRECT_KEY_NEG_METHOD, tlv_ptr, tlv_data_len);

  if (tlv_hdr_ptr == NULL)
  {
    ret = RET_ERROR;
  }
  else
  {
    zb_uint8_t* tlv_body = ZB_TLV_GET_BODY_PTR(tlv_hdr_ptr);
    if (selected_key_neg_method != NULL)
    {
      *selected_key_neg_method = tlv_body[0];
    }
    if (selected_secret != NULL)
    {
      *selected_secret = tlv_body[1];
    }
  }

  return ret;
}

/**
 * Parse Key Negotiation Request Network Key Sequence Number.
 *
 * @param tlv_ptr               pointer on the TLV
 * @param tlv_data_len          length of the data with TLVs
 * @param [out] nwk_key_seq_num address to store found network key sequence number in
 *
 * @return RET_OK     TLV is found and parsed successfully
 *         RET_ERROR  some error occurred
 */
zb_ret_t zb_tlv_direct_parse_value_start_key_neg_req_rsp_nwk_key_seq_num(
    const zb_uint8_t *tlv_ptr, zb_uint8_t tlv_data_len, zb_uint8_t *nwk_key_seq_num)
{
  zb_ret_t ret = RET_OK;
  zb_tlv_hdr_t *tlv_hdr_ptr;

  /*
   * Network Key Sequence Number TLV (ID=3)
   *
   * This indicates the network key sequence number,
   * which shall be used for basic key generation
   *
   * Octets: 1
   * Selected Network Key Sequence Number
   */

  ZB_ASSERT(nwk_key_seq_num != NULL);

  tlv_hdr_ptr = zb_tlv_get_tlv_ptr(ZB_TLV_DIRECT_NWK_KEY_SEQ_NUM, tlv_ptr, tlv_data_len);

  TRACE_MSG(TRACE_APP1,
    "zb_tlv_direct_parse_value_start_key_neg_req_rsp_nwk_key_seq_num: tlv_hdr_ptr %p",
    (FMT__P, tlv_hdr_ptr));

  if (tlv_hdr_ptr == NULL)
  {
    ret = RET_NOT_FOUND;
    *nwk_key_seq_num = ZB_TLV_DIRECT_NWK_KEY_SEQ_NUM_DEFAULT_VALUE;
  }
  else
  {
    zb_uint8_t* tlv_body = ZB_TLV_GET_BODY_PTR(tlv_hdr_ptr);
    *nwk_key_seq_num = *tlv_body;
  }

  TRACE_MSG(TRACE_APP1,
    "zb_tlv_direct_parse_value_start_key_neg_req_rsp_nwk_key_seq_num: ret %d",
    (FMT__D, ret));

  return ret;
}

#if defined ZB_COORDINATOR_ROLE || defined ZB_ROUTER_ROLE

zb_ret_t zb_tlv_parse_value_authentication_token(zb_uint8_t *tlv_ptr,
                                                 zb_uint8_t tlv_data_len,
                                                 zb_uint8_t *auth_token_id)
{
  zb_ret_t ret = RET_OK;
  zb_tlv_hdr_t *tlv_hdr_ptr;

  /*
   * Requested Authentication Token ID TLV (ID=0)
   *
   * The Global TLV Type ID being requested for an authentication token.
   *
   * Octets: 1   |
   * TLV Type ID |
   */

  tlv_hdr_ptr = zb_tlv_get_tlv_ptr(ZB_TLV_REQUESTED_AUTHENTICATION_TOKEN_ID, tlv_ptr, tlv_data_len);

  if (tlv_hdr_ptr != NULL && auth_token_id != NULL)
  {
    *auth_token_id = ZB_TLV_GET_BODY_PTR(tlv_hdr_ptr)[0];
  }
  else
  {
    ret = RET_ERROR;
  }

  return ret;
}

#endif /* ZB_COORDINATOR_ROLE || ZB_ROUTER_ROLE*/

void zb_tlv_put_value_conf_mode_param(zb_uint8_t param,
                                      zb_uint16_t *bitmask)
{
  /*
   * Configuration Mode Parameters TLV
   *
   * The Configuration Parameters TLV is 2-bytes in length and indicates
   * various parameters about how the stack SHALL behave
   *
   * Bits | Name
   * 0    | apsZdoConfigurationMode
   * 1    | requireLinkKeyEncryptionForApsTransportKey
   * 2    | nwkLeaveRequestAllowed
   * 3-16 | Reserved. These bits SHALL be set to 0.
   */

  zb_uint8_t *ptr;

  ZB_ASSERT(bitmask);

  ptr = zb_tlv_put_next(param, ZB_TLV_CONFIGURATION_MODE_PARAMETERS);

  ZB_HTOLE16(ptr, bitmask);
}

void zb_tlv_put_value_next_channel_change(zb_uint8_t param,
                                          zb_uint32_t *channel_mask)
{
  /*
   * Next Channel Change Global TLV
   *
   * This TLV is 4-bytes in length and indicates the next channel
   * that will be used once a start channel change command is received.
   */

  zb_uint8_t *ptr;

  ZB_ASSERT(channel_mask);

  ptr = zb_tlv_put_next(param, ZB_TLV_NEXT_CANNEL_CHANGE);

  ZB_HTOLE32(ptr, channel_mask);
}

void zb_tlv_put_value_next_pan_id(zb_uint8_t param,
                                  zb_uint16_t *pan_id)
{
  /*
   * Next PAN ID Change Global TLV
   *
   */

  zb_uint8_t *ptr;

  ZB_ASSERT(pan_id);

  ptr = zb_tlv_put_next(param, ZB_TLV_NEXT_PAN_ID);

  ZB_HTOLE16(ptr, pan_id);
}


void zb_tlv_put_panid_conflict_report(zb_uint8_t param)
{
   /*
   * PAN ID Conflict Report Global TLV (ID 66)
   *
   */

  zb_uint8_t *ptr;

  ptr = zb_tlv_put_next(param, ZB_TLV_PANID_CONFLICT_REPORT);
  if (ptr != NULL)
  {
    ZB_HTOLE16(ptr, &ZB_NIB().nwk_panid_conflict_count);
  }
}


zb_ret_t zb_tlv_parse_panid_conflict_report_tlv(zb_uint8_t *tlv_ptr,
                                                zb_uint8_t tlv_data_len,
                                                zb_uint16_t *panid_conflict_count)
{
  zb_ret_t ret = RET_NOT_FOUND;
  zb_tlv_hdr_t *panid_tlv_hdr = zb_tlv_get_tlv_ptr(ZB_TLV_PANID_CONFLICT_REPORT, tlv_ptr, tlv_data_len);
  if (panid_tlv_hdr != NULL
      && (zb_uint_t)panid_tlv_hdr->length + 1u >= sizeof(*panid_conflict_count))
  {
    zb_uint8_t *ptr = ZB_TLV_GET_BODY_PTR(panid_tlv_hdr);
    ZB_HTOLE16(panid_conflict_count, ptr);
    ret = RET_OK;
  }
  return ret;
}


void zb_tlv_put_potential_parents(zb_uint8_t param,
                                  zb_uint16_t current_parent,
                                  zb_uint8_t potent_parents_cnt,
                                  zb_zcl_wwah_beacon_survey_t *potent_parents_list)
{
  zb_uint8_t *ptr;
  zb_tlv_hdr_t tlv_hdr;

  tlv_hdr.tlv_id = zb_tlv_get_id(ZB_TLV_POTENTIAL_PARENTS);
  tlv_hdr.length =
    (zb_uint8_t)(sizeof(current_parent)
                 + sizeof(zb_uint8_t)
                 + sizeof(potent_parents_cnt)
                 + (sizeof(zb_uint16_t) + sizeof(zb_uint8_t)) * (zb_uint32_t)potent_parents_cnt - 1U);

  ptr = zb_buf_alloc_right(param, sizeof(zb_tlv_hdr_t) + tlv_hdr.length + 1U);

  ZB_ASSERT(ptr);

  /* Put TLV HDR */
  ZB_MEMCPY(ptr, &tlv_hdr, sizeof(tlv_hdr));
  ptr += sizeof(zb_tlv_hdr_t);

  /* Put body */
  {
    zb_uint_t i;

    ZB_HTOLE16(ptr, &current_parent);
    ptr += 2;

    *ptr = 0xff;
    if (ZB_IS_DEVICE_ZED())
    {
      zb_neighbor_tbl_ent_t *nbt = NULL;
      if (zb_nwk_neighbor_get_by_short(current_parent, &nbt) == RET_OK)
      {
        *ptr = nbt->lqa;
      }
    }
    ptr += 1;

    *ptr = potent_parents_cnt;
    ptr += 1;

    if (potent_parents_cnt != 0U)
    {
      ZB_ASSERT(potent_parents_list != NULL);
    }

    for (i = 0; i < potent_parents_cnt; i++)
    {
      zb_neighbor_tbl_ent_t *nbt = NULL;
      zb_uint8_t lqa;

      if (zb_nwk_neighbor_get_by_short(potent_parents_list[i].device_short, &nbt) == RET_OK)
      {
        lqa = nbt->lqa;
      }
      else
      {
        lqa = zb_nwk_calculate_raw_lqa(potent_parents_list[i].lqi, potent_parents_list[i].rssi);
      }

      ZB_HTOLE16(ptr, &potent_parents_list[i].device_short);
      ptr += 2;

      *ptr = lqa;
      ptr += 1;
    }
  }
}

void zb_zdo_beacon_survey_put_configuration_tlv (zb_uint8_t param,
                                                 zb_uint8_t channel_page_cnt,
                                                 zb_uint32_t *channel_page_list,
                                                 zb_uint8_t conf_mask)
{
  zb_uint8_t *ptr;
  zb_tlv_hdr_t tlv_hdr;

  ZB_ASSERT(channel_page_cnt);
  ZB_ASSERT(channel_page_list);

  tlv_hdr.tlv_id = zb_tlv_get_id(ZB_TLV_BEACON_SURVEY_CONFIGURATION);
  tlv_hdr.length = (zb_uint8_t)(sizeof(channel_page_cnt) + sizeof(zb_uint32_t) * (zb_uint32_t)channel_page_cnt + sizeof(conf_mask) - 1U);

  ptr = zb_buf_alloc_right(param, sizeof(zb_tlv_hdr_t) + tlv_hdr.length + 1U);

  ZB_ASSERT(ptr);

  /* Put TLV HDR */
  ZB_MEMCPY(ptr, &tlv_hdr, sizeof(tlv_hdr));
  ptr += sizeof(zb_tlv_hdr_t);

  /* Put body */
  {
    zb_uint_t i;

    *ptr = channel_page_cnt;
    ptr += 1;

    for (i = 0; i < channel_page_cnt; i++)
    {
      ZB_HTOLE32(ptr, &channel_page_list[i]);
      ptr += 4;
    }

    *ptr = conf_mask;
  }
}

void zb_zdo_beacon_survey_put_results_tlv (zb_uint8_t param,
                                           zb_uint8_t total_beacon_surv,
                                           zb_uint8_t num_cur_nwk_beacons,
                                           zb_uint8_t num_potent_parents_cur_zbn,
                                           zb_uint8_t num_other_nwk_beacons)
{
  zb_uint8_t *ptr;

  ptr = zb_tlv_put_next(param, ZB_TLV_BEACON_SURVEY_RESULTS);

  *ptr = total_beacon_surv;
  ptr += 1;

  *ptr = num_cur_nwk_beacons;
  ptr += 1;

  *ptr = num_potent_parents_cur_zbn;
  ptr += 1;

  *ptr = num_other_nwk_beacons;
}


zb_ret_t zb_tlv_parse_beacon_survey_results_tlv(zb_uint8_t *tlv_ptr,
                                                zb_uint8_t tlv_data_len,
                                                zb_zdo_beacon_survey_results_t *results)
{
  zb_ret_t ret = RET_OK;
  zb_tlv_hdr_t *tlv_hdr_ptr;

  tlv_hdr_ptr = zb_tlv_get_tlv_ptr(ZB_TLV_BEACON_SURVEY_RESULTS, tlv_ptr, tlv_data_len);

  if (tlv_hdr_ptr != NULL
      && (zb_uint_t)tlv_hdr_ptr->length + 1u >= sizeof(*results))
  {
    zb_uint8_t *ptr = ZB_TLV_GET_BODY_PTR(tlv_hdr_ptr);
    results->total_beacons_surveyed = ptr[0];
    results->num_cur_nwk_beacons = ptr[1];
    results->num_potential_parents_current_zbn = ptr[2];
    results->num_other_nwk_beacons = ptr[3];
  }
  else
  {
    ret = RET_ERROR;
  }

  TRACE_MSG(TRACE_COMMON1, "zb_tlv_parse_value_router_information, ret %hd", (FMT__H, ret));
  return ret;
}


zb_ret_t zb_tlv_parse_beacon_survey_parents_tlv(zb_uint8_t *tlv_ptr,
                                                zb_uint8_t tlv_data_len,
                                                zb_zdo_beacon_survey_potential_parents_t *parents)
{
  /*

2.4.4.3.13.1.2 Potential Parents TLV(ID 0x02)

Current Parent Short Address
LQA
Count
Potential Parent Short Address
LQA
Additional Potential Parent Short Address
LQA
...
  */
  zb_tlv_hdr_t *tlv_hdr_ptr;

  TRACE_MSG(TRACE_COMMON2, "zb_tlv_parse_beacon_survey_results_tlv tlv_data_len %hd", (FMT__H, tlv_data_len));
  tlv_hdr_ptr = zb_tlv_get_tlv_ptr(ZB_TLV_POTENTIAL_PARENTS, tlv_ptr, tlv_data_len);

  if (tlv_hdr_ptr != NULL)
  {
#define MIN_PARENTS_TLV_SIZE (2u + 1u + 1u)
    if (tlv_hdr_ptr->length + 1u < MIN_PARENTS_TLV_SIZE)
    {
      TRACE_MSG(TRACE_COMMON2, "Too small tlv data len %hd", (FMT__H, tlv_hdr_ptr->length));
      tlv_hdr_ptr = NULL;
    }
  }
  else
  {
    TRACE_MSG(TRACE_COMMON2, "No ZB_TLV_POTENTIAL_PARENTS", (FMT__0));
  }
  if (tlv_hdr_ptr != NULL)
  {
    zb_uint8_t *body_ptr = ZB_TLV_GET_BODY_PTR(tlv_hdr_ptr);
    ZB_LETOH16(&parents->current_parent, body_ptr);
    body_ptr += 2u;
    parents->current_parent_lqa = *body_ptr++;
    parents->count_potential_parents = *body_ptr++;
    if (tlv_hdr_ptr->length + 1u - MIN_PARENTS_TLV_SIZE != parents->count_potential_parents * 3u)
    {
      TRACE_MSG(TRACE_COMMON2, "ZB_TLV_POTENTIAL_PARENTS: mismatch count_potential_parents %hd and TLV data rest %d",
                (FMT__H_D, parents->count_potential_parents, tlv_hdr_ptr->length - MIN_PARENTS_TLV_SIZE));
      tlv_hdr_ptr = NULL;
    }
    else
    {
      zb_uindex_t i;
      for (i = 0 ;
           i < parents->count_potential_parents && i < sizeof(parents->parent_list)/sizeof(parents->parent_list[0])  ;
           ++i)
      {
        ZB_LETOH16(&parents->parent_list[i].device_short, body_ptr);
        body_ptr += 2u;
        parents->parent_list[i].lqi = *body_ptr++;
      }
    }
  }

  return tlv_hdr_ptr != NULL ? RET_OK : RET_ERROR;
}


zb_ret_t zb_zdo_beacon_survey_process_configuration_tlv (zb_uint8_t *tlv_ptr,
                                                         zb_uint8_t tlv_data_len,
                                                         zb_uint8_t *channel_page_cnt,
                                                         zb_uint32_t *channel_page_list,
                                                         zb_uint8_t *conf_mask)
{
  zb_ret_t ret = RET_ERROR;
  zb_tlv_hdr_t *tlv_hdr_ptr;

  tlv_hdr_ptr = zb_tlv_get_tlv_ptr(ZB_TLV_BEACON_SURVEY_CONFIGURATION, tlv_ptr, tlv_data_len);

  if (tlv_hdr_ptr != NULL)
  {
    if (sizeof (zb_tlv_hdr_t) + tlv_hdr_ptr->length < tlv_data_len)
    {
      zb_uint8_t *body_ptr = ZB_TLV_GET_BODY_PTR(tlv_hdr_ptr);
      zb_uint_t i;

      *channel_page_cnt = *body_ptr;
      body_ptr += 1U;

      if (((zb_uint8_t)sizeof(zb_tlv_hdr_t) + (*channel_page_cnt) * 2U + 2U) < tlv_data_len - 1U)
      {
        for (i = 0U; i < *channel_page_cnt; i++)
        {
          ZB_LETOH32(&channel_page_list[i], body_ptr);
          body_ptr += 4U;
        }

        *conf_mask = *body_ptr;

        ret = RET_OK;
      }
    }
  }

  return ret;
}

