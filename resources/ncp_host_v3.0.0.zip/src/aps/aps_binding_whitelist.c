/* ZBOSS Zigbee software protocol stack
 *
 * Copyright (c) 2012-2020 DSR Corporation, Denver CO, USA.
 * www.dsr-zboss.com
 * www.dsr-corporation.com
 * All rights reserved.
 *
 * This is unpublished proprietary source code of DSR Corporation
 * The copyright notice does not evidence any actual or intended
 * publication of such source code.
 *
 * ZBOSS is a registered trademark of Data Storage Research LLC d/b/a DSR
 * Corporation
 *
 * Commercial Usage
 * Licensees holding valid DSR Commercial licenses may use
 * this file in accordance with the DSR Commercial License
 * Agreement provided with the Software or, alternatively, in accordance
 * with the terms contained in a written agreement between you and
 * DSR.
 */
/* PURPOSE: Network confirm routine
*/

#define ZB_TRACE_FILE_ID 2138
#include "zb_common.h"
#include "zb_aps.h"

/*! \addtogroup ZB_APS */
/*! @{ */

static zb_uint8_t find_binding_whitelist_entry(zb_uint8_t ep_id, zb_uint16_t cluster_id, zb_uint8_t cluster_role)
{
  zb_uint8_t i = 0;

  TRACE_MSG(TRACE_APS2, " >>find_binding_whitelist_entry endpoint %hd, cluster %d cluster_role %hd", (FMT__H_D_H, ep_id, cluster_id, cluster_role));

  while (i < ZG->aps.binding.whitelist_n_elements)
  {
    if (ep_id == ZG->aps.binding.whitelist_table[i].ep_id &&
        cluster_id == ZG->aps.binding.whitelist_table[i].cluster_id &&
        cluster_role == ZG->aps.binding.whitelist_table[i].cluster_role)
    {
      TRACE_MSG(TRACE_APS2, "<<zb_aps_find_binding_whitelist_entry entry index %hd found", (FMT__H, i));
      return i;
    }
    i++;
  }
  TRACE_MSG(TRACE_APS2, "<<find_binding_whitelist_entry entry index not found", (FMT__0));
  return (zb_uint8_t)(-1);
}

zb_ret_t zb_aps_add_binding_whitelist_entry(zb_uint8_t ep_id, zb_uint16_t cluster_id, zb_uint8_t cluster_role, zb_ieee_addr_t ieee_addr)
{
  zb_ret_t ret = RET_OK;

  TRACE_MSG(TRACE_APS2, ">>zb_aps_add_binding_whitelist_entry endpoint %hd, cluster %d cluster_role %hd IEEE addr" TRACE_FORMAT_64, (FMT__H_D_H_A, ep_id, cluster_id, cluster_role, TRACE_ARG_64(ieee_addr)));

  if (ZG->aps.binding.whitelist_n_elements >= ZB_APS_BINDING_TABLE_WHITELIST_SIZE)
  {
    TRACE_MSG(TRACE_ERROR, "whitelist elements table is full", (FMT__0));
    ret = RET_TABLE_FULL;
  }
  else
  {
    zb_uint8_t wl = find_binding_whitelist_entry(ep_id, cluster_id, cluster_role);

    wl = (wl == (zb_uint8_t)-1) ? ZG->aps.binding.whitelist_n_elements : wl;

    TRACE_MSG(TRACE_APS2, "add whitelist element index %hd", (FMT__H, wl));

    if (wl == ZG->aps.binding.whitelist_n_elements)
    {
      ZG->aps.binding.whitelist_table[wl].ep_id = ep_id;
      ZG->aps.binding.whitelist_table[wl].cluster_id = cluster_id;
      ZG->aps.binding.whitelist_table[wl].cluster_role = cluster_role;

      ZG->aps.binding.whitelist_n_elements++;
    }

    ZB_MEMCPY(ZG->aps.binding.whitelist_table[wl].addr, ieee_addr, sizeof(zb_ieee_addr_t));
  }

  TRACE_MSG(TRACE_APS2, "<<zb_aps_add_binding_whitelist_entry ret %hu", (FMT__D, ret));
  return ret;
}

zb_ret_t zb_check_binding_table_whitelist(zb_apsme_binding_req_t *apsreq)
{
  zb_ret_t ret;

  zb_uint8_t wl = find_binding_whitelist_entry(apsreq->src_endpoint, apsreq->clusterid, ZB_ZCL_CLUSTER_SERVER_ROLE);

  TRACE_MSG(TRACE_APS2, ">>zb_check_binding_table_whitelist apsreq %p", (FMT__P, apsreq));

  wl = (wl == (zb_uint8_t)-1) ? ZG->aps.binding.whitelist_n_elements : wl;

  TRACE_MSG(TRACE_APS2, "whitelist element index %hd", (FMT__H, wl));

  if (wl == ZG->aps.binding.whitelist_n_elements)
  {
    TRACE_MSG(TRACE_APS2, "No such entry in the whitelist", (FMT__0));
    ret = RET_NO_MATCH;
  }
  else
  {
    /* ZCL 8.2.2.1.3:
     * "Any attempt via the ZDO bind or unbind request to create, modify or remove binding
     * table entry on a device embodying the IAS Zone server SHALL be rejected and responded
     * with the status NOT_AUTHORIZED, if the subjected binding table entry is related to an
     * IAS Zone server cluster and the ZDP request does not come from the paired IAS CIE" */
    if (!ZB_IEEE_ADDR_IS_VALID(ZG->aps.binding.whitelist_table[wl].addr))
    {
      TRACE_MSG(TRACE_APS2, "check binding table. Criterion isn't set", (FMT__0));
      ret = ERROR_CODE(ERROR_CATEGORY_GENERIC, RET_UNAUTHORIZED);
    }
    else
    {
      ret = ERROR_CODE(ERROR_CATEGORY_GENERIC, RET_UNAUTHORIZED);

      if (apsreq->addr_mode == ZB_APS_ADDR_MODE_64_ENDP_PRESENT)
      {
        TRACE_MSG(TRACE_APS3, "check binding table. Put IEEE addr. Whitelist table " TRACE_FORMAT_64 " Apsreq " TRACE_FORMAT_64,
                  (FMT__A_A, TRACE_ARG_64(ZG->aps.binding.whitelist_table[wl].addr), TRACE_ARG_64(apsreq->dst_addr.addr_long)));

        if (ZB_IEEE_ADDR_IS_VALID(apsreq->dst_addr.addr_long) &&
            (ZB_MEMCMP(apsreq->dst_addr.addr_long, ZG->aps.binding.whitelist_table[wl].addr, sizeof(zb_ieee_addr_t)) == 0))
        {
          ret = RET_OK;
        }
      }
    }
  }

  TRACE_MSG(TRACE_APS2, "<<zb_check_binding_table_whitelist", (FMT__0));

  return ret;
}

/*! @} */
