
HOME=../../../

PTY_SLAVE_PREFIX=/tmp/ncp_slave_pty

NSNG=$(realpath ${HOME}/tools/nsng/nsng)
NCPFW=$(realpath ${HOME}/ncp_fw/ncp_fw)

ZC=$(realpath ${HOME}/application/simple_gw/simple_gw)
ZR=$(realpath ${HOME}/application/light_sample/dimmable_light/bulb)

pids=()

function rm_log() 
{
	rm $1/*.log $1/*.pcap $1/*.dump
}

function start()
{
	command="env $3 $2"
	pushd $1 > /dev/null
	echo Starting $2...
	echo $command
	$command &
	pids+=($!)
	popd > /dev/null
	echo
}

function start_ncp()
{
	if [[ -z $3 ]]; then
		env=""
	else
		env="NCP_SLAVE_PTY=${PTY_SLAVE_PREFIX}_$3"
	fi

	start $1 $2 $env

	start $1 $NCPFW $env
}

function kill_all()
{
	echo "kill all"
	for pid in ${pids[@]}; do
		echo Killing $pid...
		kill -9 $pid
	done
}

function handle_keyboard_interrupt()
{
	echo Interrupted!
	kill_all
}

trap handle_keyboard_interrupt TERM INT

start nsng ${NSNG}
sleep 1

start_ncp zc $ZC zc
sleep 2

start_ncp zr $ZR zr

echo "All the devices are started"

sleep 60

kill_all


